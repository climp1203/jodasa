# Jodasa CBC School Management System

> Multi-tenant CBC (Competency-Based Curriculum) platform for Kenyan schools

**Team:** Jovas Mbago, Samuel Wandu, David Wangah, Ian Odhiambo, Jane Waithera, Charity Mukami  
**Stack:** Django + PostgreSQL (backend) · React + TypeScript + Tailwind CSS (frontend)

---

## 📋 Prerequisites — Install These First

| Tool | Download |
|------|---------|
| Python 3.10+ | https://python.org/downloads |
| Node.js 18+ | https://nodejs.org |
| PostgreSQL 14+ | https://postgresql.org/download/windows |

---

## 🗄️ STEP 1 — Database Setup (PostgreSQL)

### A) Install PostgreSQL
- Download and install from https://postgresql.org/download/windows
- Remember the **postgres** password you set during installation
- pgAdmin installs automatically alongside it

### B) Create the Database in pgAdmin
1. Open **pgAdmin** → enter your postgres password
2. Right-click **Databases** → **Create** → **Database**
3. Name it: `jodasa_db` → click **Save**

### C) (Optional) Run the full setup script
Open `backend/database_setup.sql` in pgAdmin Query Tool and run it for:
- Dedicated app user creation
- UUID and text search extensions
- Row-Level Security policies (after migrations)

---

## ⚙️ STEP 2 — Backend Setup

```bash
cd jodasa\backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

Edit `.env` and fill in:
```
SECRET_KEY=any-long-random-string
DEBUG=True
DB_NAME=jodasa_db
DB_USER=postgres
DB_PASSWORD=your-postgres-password
DB_HOST=localhost
DB_PORT=5432
ANTHROPIC_API_KEY=sk-ant-your-key-here
```

Then run:
```bash
python manage.py makemigrations
python manage.py migrate
python manage.py seed_demo
python manage.py runserver
```

Backend: http://localhost:8000  
API Docs: http://localhost:8000/api/docs/

---

## 🖥️ STEP 3 — Frontend Setup (Second Terminal)

```bash
cd jodasa\frontend
npm install
npm run dev
```

Open: http://localhost:5173

---

## 🔑 Demo Login Credentials (after seed_demo)

| Role | Username | Password |
|------|----------|----------|
| Superadmin | superadmin | Admin@1234 |
| School Admin | schooladmin | Admin@1234 |
| Teacher 1 | teacher1 | Admin@1234 |
| Teacher 2 | teacher2 | Admin@1234 |
| Parent | parent1 | Admin@1234 |

---

## 🔧 npm Install Fails (ENOSPC - disk full)?

```bash
npm config set cache D:\npm-cache --global
npm config set prefix D:\npm-global --global
npm cache clean --force
npm install
```

---

## 🚀 Deployment

- **Backend** → Railway.app (connects to GitHub)
- **Frontend** → Vercel.com (set VITE_API_URL to Railway URL)
- **Database** → Neon.tech (free cloud PostgreSQL)

---

MIT License — Jodasa Team, 2026
