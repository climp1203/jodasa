import { useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { feesAPI, studentAPI } from "../../lib/api"
import { CreditCard, CheckCircle, Clock, Loader2, Smartphone } from "lucide-react"
import { useMutation } from "@tanstack/react-query"
import toast from "react-hot-toast"
import { TERMS } from "../../types"
import type { Payment } from "../../types"

export default function FeeStatement() {
  const [mpesaPhone, setMpesaPhone] = useState("")
  const [mpesaAmount, setMpesaAmount] = useState("")
  const [term, setTerm] = useState("1")

  const { data: students } = useQuery({ queryKey:["my-students"], queryFn: () => studentAPI.getAll().then(r=>r.data) })
  const myChild = students?.results?.[0]

  const { data: statement, isLoading } = useQuery({
    queryKey: ["statement", myChild?.id],
    queryFn: () => feesAPI.statement(myChild!.id).then(r => r.data),
    enabled: !!myChild?.id
  })

  const mpesaMutation = useMutation({
    mutationFn: () => feesAPI.mpesaSTK({
      student_id: myChild?.id,
      phone: mpesaPhone,
      amount: mpesaAmount,
      term, year: new Date().getFullYear()
    }),
    onSuccess: () => toast.success("STK push sent! Check your phone for M-Pesa prompt."),
    onError: (e: any) => toast.error(e?.response?.data?.detail || "Payment request failed")
  })

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Fee Statement</h1>
      </div>

      {isLoading && <div className="p-8 text-center"><Loader2 className="animate-spin mx-auto text-gray-400"/></div>}

      {statement && (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
            <div className="stat-card border-l-4 border-green-500">
              <p className="stat-value text-green-700">KES {Number(statement.total_paid).toLocaleString()}</p>
              <p className="stat-label">Total Paid</p>
            </div>
            <div className="stat-card">
              <p className="stat-value">{statement.payments?.length || 0}</p>
              <p className="stat-label">Transactions</p>
            </div>
            <div className="stat-card">
              <p className="stat-value">{statement.payments?.filter((p: Payment) => p.status === "completed").length || 0}</p>
              <p className="stat-label">Completed Payments</p>
            </div>
          </div>

          <div className="card overflow-hidden mb-6">
            <div className="px-4 py-3 border-b border-gray-100 font-semibold">Payment History</div>
            {statement.payments?.length === 0 ? (
              <div className="p-8 text-center text-gray-400">No payments recorded yet.</div>
            ) : (
              <table className="table-auto w-full">
                <thead><tr><th>Date</th><th>Amount</th><th>Method</th><th>Receipt</th><th>Status</th></tr></thead>
                <tbody>
                  {statement.payments?.map((p: Payment) => (
                    <tr key={p.id} className="hover:bg-gray-50">
                      <td className="text-sm">{p.paid_at ? new Date(p.paid_at).toLocaleDateString() : "—"}</td>
                      <td className="font-medium">KES {Number(p.amount).toLocaleString()}</td>
                      <td><span className="badge badge-gray capitalize">{p.method}</span></td>
                      <td className="font-mono text-xs text-green-700">{p.mpesa_receipt || "—"}</td>
                      <td>
                        <span className={`badge flex items-center gap-1 w-fit ${p.status === "completed" ? "badge-green" : p.status === "pending" ? "badge-yellow" : "badge-red"}`}>
                          {p.status === "completed" ? <CheckCircle size={11}/> : <Clock size={11}/>}
                          {p.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        </>
      )}

      {/* Pay via M-Pesa */}
      <div className="card p-6 max-w-md">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
            <Smartphone size={20} className="text-green-700"/>
          </div>
          <div>
            <h2 className="font-semibold">Pay via M-Pesa</h2>
            <p className="text-sm text-gray-500">Lipa Na M-Pesa STK push</p>
          </div>
        </div>
        <div className="space-y-3">
          <div>
            <label className="label">Your Phone Number</label>
            <input className="input" value={mpesaPhone} onChange={e=>setMpesaPhone(e.target.value)} placeholder="07XXXXXXXX"/>
          </div>
          <div>
            <label className="label">Amount (KES)</label>
            <input className="input" type="number" value={mpesaAmount} onChange={e=>setMpesaAmount(e.target.value)} placeholder="5000"/>
          </div>
          <div>
            <label className="label">Term</label>
            <select className="input" value={term} onChange={e=>setTerm(e.target.value)}>
              {TERMS.map(t=><option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </div>
          <button className="btn-success w-full justify-center py-2.5" onClick={()=>mpesaMutation.mutate()} disabled={mpesaMutation.isPending||!mpesaPhone||!mpesaAmount}>
            {mpesaMutation.isPending?<Loader2 size={16} className="animate-spin"/>:<Smartphone size={16}/>}
            Request M-Pesa Payment
          </button>
        </div>
      </div>
    </div>
  )
}
