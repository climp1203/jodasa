import { useQuery } from "@tanstack/react-query"
import { studentAPI, attendanceAPI, portfolioAPI } from "../../lib/api"
import { useAuthStore } from "../../lib/store"
import { CreditCard, TrendingUp, Folder, Loader2 } from "lucide-react"
import { Link } from "react-router-dom"
import { CBC_PERFORMANCE_LABELS } from "../../types"
import type { PortfolioEntry } from "../../types"
import { Spinner } from "../../components/ui"

export default function ParentPortal() {
  const { user } = useAuthStore()

  const { data: students, isLoading } = useQuery({
    queryKey: ["my-students"],
    queryFn: () => studentAPI.getAll().then(r => r.data)
  })

  const myChild = students?.results?.[0]

  const { data: portfolio } = useQuery({
    queryKey: ["portfolio", myChild?.id],
    queryFn: () => portfolioAPI.byStudent(myChild!.id).then(r => r.data),
    enabled: !!myChild?.id
  })

  const { data: attendance } = useQuery({
    queryKey: ["attendance-summary", myChild?.id],
    queryFn: () => attendanceAPI.studentSummary(myChild!.id).then(r => r.data),
    enabled: !!myChild?.id
  })

  const { data: csl } = useQuery({
    queryKey: ["csl-hours", myChild?.id],
    queryFn: () => portfolioAPI.studentHours(myChild!.id).then(r => r.data),
    enabled: !!myChild?.id
  })

  const perfColors: Record<string,string> = { EE:"cbc-ee", ME:"cbc-me", AE:"cbc-ae", BE:"cbc-be" }

  if (isLoading) return <Spinner text="Loading your child's information..."/>

  if (!myChild) return (
    <div className="card p-12 text-center text-gray-400">
      <p className="font-medium">No student linked to your account.</p>
      <p className="text-sm mt-1">Please contact the school administrator.</p>
    </div>
  )

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Parent Portal</h1>
          <p className="text-sm text-gray-500 mt-0.5">Welcome, {user?.full_name}</p>
        </div>
        <span className="badge badge-yellow">Parent</span>
      </div>

      {/* Child card */}
      <div className="card p-5 mb-6 flex items-center gap-4">
        <div className="w-14 h-14 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 text-xl font-bold flex-shrink-0">
          {myChild.first_name?.charAt(0)}
        </div>
        <div className="flex-1">
          <h2 className="text-lg font-bold text-gray-900">{myChild.full_name}</h2>
          <p className="text-sm text-gray-500">Grade {myChild.grade}{myChild.stream} · Adm: {myChild.admission_number}</p>
        </div>
        {myChild.qr_code && (
          <div className="flex-shrink-0 text-center">
            <img src={myChild.qr_code} alt="Student QR" className="w-16 h-16 rounded-lg border border-gray-200"/>
            <p className="text-xs text-gray-400 mt-1">Student QR</p>
          </div>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        <div className="stat-card"><p className="stat-value text-2xl text-green-700">{attendance?.attendance_rate ?? 0}%</p><p className="stat-label">Attendance Rate</p></div>
        <div className="stat-card"><p className="stat-value text-2xl">{attendance?.present ?? 0}/{attendance?.total_sessions ?? 0}</p><p className="stat-label">Days Present</p></div>
        <div className="stat-card"><p className="stat-value text-2xl">{Array.isArray(portfolio) ? portfolio.length : 0}</p><p className="stat-label">Portfolio Entries</p></div>
        <div className="stat-card"><p className="stat-value text-2xl text-green-700">{csl?.total_csl_hours ?? 0}h</p><p className="stat-label">CSL Hours</p></div>
      </div>

      {/* Quick links */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <Link to="/parent/fees" className="card p-5 hover:shadow-md transition-shadow flex items-center gap-4 group">
          <div className="w-11 h-11 rounded-xl bg-green-100 text-green-700 flex items-center justify-center group-hover:scale-110 transition-transform">
            <CreditCard size={22}/>
          </div>
          <div><p className="font-semibold">Fee Statement</p><p className="text-sm text-gray-500">View payments & pay via M-Pesa</p></div>
        </Link>
        <div className="card p-5 flex items-center gap-4">
          <div className="w-11 h-11 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
            <TrendingUp size={22}/>
          </div>
          <div><p className="font-semibold">Academic Progress</p><p className="text-sm text-gray-500">CBC performance levels</p></div>
        </div>
      </div>

      {/* Recent portfolio */}
      {Array.isArray(portfolio) && portfolio.length > 0 && (
        <div className="card p-5">
          <h2 className="font-semibold mb-4 flex items-center gap-2"><Folder size={16} className="text-blue-500"/>Recent Portfolio</h2>
          <div className="space-y-3">
            {portfolio.slice(0,5).map((e: PortfolioEntry) => (
              <div key={e.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium">{e.title}</p>
                  <p className="text-xs text-gray-400">{e.subject} · {e.date}</p>
                </div>
                {e.performance_level && (
                  <span className={`badge ${perfColors[e.performance_level]}`}>
                    {e.performance_level} — {CBC_PERFORMANCE_LABELS[e.performance_level]}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {Array.isArray(portfolio) && portfolio.length === 0 && (
        <div className="card p-8 text-center text-gray-400">
          <Folder size={32} className="mx-auto mb-2 opacity-30"/>
          <p className="text-sm">No portfolio entries yet. Check back after assessments.</p>
        </div>
      )}
    </div>
  )
}
