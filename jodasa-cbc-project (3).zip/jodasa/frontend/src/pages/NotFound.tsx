import { useNavigate } from 'react-router-dom'
import { Home, ArrowLeft } from 'lucide-react'

export default function NotFound() {
  const navigate = useNavigate()
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 p-4">
      <div className="text-center">
        <div className="text-8xl font-black text-blue-100 mb-2">404</div>
        <h1 className="text-2xl font-bold text-gray-900 mb-2">Page Not Found</h1>
        <p className="text-gray-500 mb-8">The page you are looking for does not exist or has been moved.</p>
        <div className="flex gap-3 justify-center">
          <button className="btn-secondary" onClick={() => navigate(-1)}><ArrowLeft size={16}/>Go Back</button>
          <button className="btn-primary" onClick={() => navigate('/')}><Home size={16}/>Home</button>
        </div>
      </div>
    </div>
  )
}
