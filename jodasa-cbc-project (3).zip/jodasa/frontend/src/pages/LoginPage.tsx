import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuthStore } from '../lib/store'
import { authAPI } from '../lib/api'
import toast from 'react-hot-toast'
import { Eye, EyeOff, Loader2 } from 'lucide-react'

export default function LoginPage() {
  const [username, setUsername] = useState("")
  const [password, setPassword] = useState("")
  const [showPw, setShowPw] = useState(false)
  const [loading, setLoading] = useState(false)
  const { setAuth } = useAuthStore()
  const navigate = useNavigate()

  const roleRedirect: Record<string,string> = {
    superadmin: "/superadmin", school_admin: "/admin",
    teacher: "/teacher", parent: "/parent", student: "/student"
  }

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    try {
      const { data } = await authAPI.login(username, password)
      setAuth(data.user, data.access, data.refresh)
      toast.success(`Welcome, ${data.user.full_name}!`)
      navigate(roleRedirect[data.user.role] || "/")
    } catch (err: any) {
      toast.error(err?.response?.data?.detail || "Invalid credentials")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-600 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/20 backdrop-blur mb-4">
            <span className="text-white font-bold text-2xl">JDS</span>
          </div>
          <h1 className="text-3xl font-bold text-white">Jodasa CBC</h1>
          <p className="text-blue-200 mt-1">Kenya Competency-Based Curriculum</p>
        </div>

        {/* Card */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Sign in to your portal</h2>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="label">Username or Email</label>
              <input className="input" type="text" value={username}
                onChange={e => setUsername(e.target.value)} placeholder="Enter username" required />
            </div>
            <div>
              <label className="label">Password</label>
              <div className="relative">
                <input className="input pr-10" type={showPw ? "text" : "password"}
                  value={password} onChange={e => setPassword(e.target.value)}
                  placeholder="Enter password" required />
                <button type="button" onClick={() => setShowPw(!showPw)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                  {showPw ? <EyeOff size={16}/> : <Eye size={16}/>}
                </button>
              </div>
            </div>
            <button type="submit" disabled={loading}
              className="btn-primary w-full justify-center py-2.5 mt-2">
              {loading ? <><Loader2 size={16} className="animate-spin"/>Signing in...</> : "Sign In"}
            </button>
          </form>
          <p className="text-center text-xs text-gray-400 mt-6">
            Jodasa CBC · Empowering Kenyan Schools · {new Date().getFullYear()}
          </p>
        </div>
      </div>
    </div>
  )
}
