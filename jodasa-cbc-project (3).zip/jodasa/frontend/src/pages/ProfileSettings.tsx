import { useState } from "react"
import { useMutation } from "@tanstack/react-query"
import { userAPI } from "../lib/api"
import { useAuthStore } from "../lib/store"
import { User, Lock, Save, Loader2 } from "lucide-react"
import toast from "react-hot-toast"
import FormField from "../components/ui/FormField"

export default function ProfileSettings() {
  const { user, setAuth, accessToken, refreshToken } = useAuthStore()
  const [form, setForm] = useState({
    first_name: user?.full_name?.split(" ")[0] || "",
    last_name: user?.full_name?.split(" ").slice(1).join(" ") || "",
    email: user?.email || "",
    phone: "",
  })
  const [pwForm, setPwForm] = useState({ old_password:"", new_password:"", confirm:"" })
  const [tab, setTab] = useState<"profile"|"password">("profile")

  const updateMutation = useMutation({
    mutationFn: () => userAPI.update(user!.id, form),
    onSuccess: (r) => {
      toast.success("Profile updated!")
      if (accessToken && refreshToken) {
        setAuth({ ...user!, full_name: `${form.first_name} ${form.last_name}`, email: form.email }, accessToken, refreshToken)
      }
    },
    onError: () => toast.error("Update failed")
  })

  const pwMutation = useMutation({
    mutationFn: () => {
      if (pwForm.new_password !== pwForm.confirm) throw new Error("Passwords do not match")
      return userAPI.update(user!.id, { old_password: pwForm.old_password, password: pwForm.new_password })
    },
    onSuccess: () => { toast.success("Password changed!"); setPwForm({ old_password:"", new_password:"", confirm:"" }) },
    onError: (e:any) => toast.error(e?.message || e?.response?.data?.detail || "Password change failed")
  })

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Profile & Settings</h1>
      </div>

      {/* Avatar */}
      <div className="card p-6 mb-6 flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-blue-600 flex items-center justify-center text-white text-2xl font-bold flex-shrink-0">
          {user?.full_name?.charAt(0) || "U"}
        </div>
        <div>
          <p className="text-lg font-bold">{user?.full_name}</p>
          <p className="text-sm text-gray-500 capitalize">{user?.role?.replace("_"," ")} · {user?.email}</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-gray-100 rounded-lg w-fit mb-6">
        {[["profile","Profile"],["password","Change Password"]].map(([k,l]) => (
          <button key={k} onClick={()=>setTab(k as any)}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${tab===k?"bg-white shadow text-gray-900":"text-gray-500"}`}>
            {l}
          </button>
        ))}
      </div>

      {tab === "profile" && (
        <div className="card p-6 max-w-lg">
          <div className="flex items-center gap-2 mb-5"><User size={18} className="text-blue-500"/><h2 className="font-semibold">Personal Information</h2></div>
          <div className="grid grid-cols-2 gap-4">
            <FormField label="First Name">
              <input className="input" value={form.first_name} onChange={e=>setForm(f=>({...f,first_name:e.target.value}))}/>
            </FormField>
            <FormField label="Last Name">
              <input className="input" value={form.last_name} onChange={e=>setForm(f=>({...f,last_name:e.target.value}))}/>
            </FormField>
            <FormField label="Email" required={false}>
              <input className="input" type="email" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))}/>
            </FormField>
            <FormField label="Phone">
              <input className="input" value={form.phone} onChange={e=>setForm(f=>({...f,phone:e.target.value}))} placeholder="07XXXXXXXX"/>
            </FormField>
          </div>
          <button className="btn-primary mt-5" onClick={()=>updateMutation.mutate()} disabled={updateMutation.isPending}>
            {updateMutation.isPending?<Loader2 size={14} className="animate-spin"/>:<Save size={14}/>} Save Changes
          </button>
        </div>
      )}

      {tab === "password" && (
        <div className="card p-6 max-w-md">
          <div className="flex items-center gap-2 mb-5"><Lock size={18} className="text-blue-500"/><h2 className="font-semibold">Change Password</h2></div>
          <div className="space-y-4">
            <FormField label="Current Password">
              <input className="input" type="password" value={pwForm.old_password} onChange={e=>setPwForm(f=>({...f,old_password:e.target.value}))}/>
            </FormField>
            <FormField label="New Password" hint="Minimum 8 characters">
              <input className="input" type="password" value={pwForm.new_password} onChange={e=>setPwForm(f=>({...f,new_password:e.target.value}))}/>
            </FormField>
            <FormField label="Confirm New Password" error={pwForm.confirm && pwForm.new_password !== pwForm.confirm ? "Passwords do not match" : undefined}>
              <input className="input" type="password" value={pwForm.confirm} onChange={e=>setPwForm(f=>({...f,confirm:e.target.value}))}/>
            </FormField>
            <button className="btn-primary w-full justify-center" onClick={()=>pwMutation.mutate()} disabled={pwMutation.isPending||!pwForm.old_password||!pwForm.new_password}>
              {pwMutation.isPending?<Loader2 size={14} className="animate-spin"/>:<Lock size={14}/>} Change Password
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
