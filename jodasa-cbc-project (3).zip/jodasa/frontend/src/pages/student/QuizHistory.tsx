import { useQuery } from "@tanstack/react-query"
import { assessmentAPI } from "../../lib/api"
import { Brain, CheckCircle, BarChart2 } from "lucide-react"
import { CBC_PERFORMANCE_LABELS } from "../../types"
import Spinner from "../../components/ui/Spinner"
import EmptyState from "../../components/ui/EmptyState"

export default function QuizHistory() {
  const { data: assessments, isLoading } = useQuery({
    queryKey: ["assessments-quiz"],
    queryFn: () => assessmentAPI.getAll({ assessment_type:"quiz" }).then(r=>r.data)
  })

  const perfColors: Record<string,string> = { EE:"cbc-ee", ME:"cbc-me", AE:"cbc-ae", BE:"cbc-be" }

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">My Quiz History</h1>
        <span className="badge badge-purple">Student</span>
      </div>

      {isLoading ? <Spinner/> : assessments?.results?.length === 0 ? (
        <EmptyState icon={Brain} title="No quizzes taken yet" description="Complete your first AI quiz to see your history here."/>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {assessments?.results?.map((a:any) => (
            <div key={a.id} className="card p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center">
                  <Brain size={20}/>
                </div>
                {a.result_count > 0 && <CheckCircle size={18} className="text-green-500"/>}
              </div>
              <p className="font-semibold">{a.title}</p>
              <p className="text-xs text-gray-500 mt-1">{a.subject} · Grade {a.grade} · Term {a.term}</p>
              <div className="mt-3 flex gap-2">
                <span className="badge badge-blue">{a.questions?.length || 0} questions</span>
                {a.result_count > 0 && <span className="badge badge-green">Completed</span>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
