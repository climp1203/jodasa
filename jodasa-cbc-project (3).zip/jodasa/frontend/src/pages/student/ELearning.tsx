import { useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { lessonAPI } from "../../lib/api"
import { Loader2, BookOpen, Clock, ChevronLeft } from "lucide-react"
import type { Lesson } from "../../types"

export default function StudentELearning() {
  const [selected, setSelected] = useState<Lesson|null>(null)
  const [search, setSearch] = useState("")

  const { data, isLoading } = useQuery({
    queryKey: ["student-lessons"],
    queryFn: () => lessonAPI.getAll({ status: "published" }).then(r => r.data)
  })

  const filtered = data?.results?.filter((l: Lesson) =>
    l.title.toLowerCase().includes(search.toLowerCase()) ||
    l.subject.toLowerCase().includes(search.toLowerCase())
  )

  if (selected) {
    return (
      <div>
        <button className="btn-ghost mb-4" onClick={() => setSelected(null)}>
          <ChevronLeft size={16}/> Back to Lessons
        </button>
        <div className="card p-6 max-w-3xl">
          <h1 className="text-2xl font-bold mb-2">{selected.title}</h1>
          <div className="flex flex-wrap gap-2 mb-4">
            <span className="badge badge-blue">{selected.grade}</span>
            <span className="badge badge-gray">{selected.subject}</span>
            <span className="badge badge-gray flex items-center gap-1"><Clock size={11}/>{selected.estimated_duration} min</span>
          </div>
          {selected.objectives && (
            <div className="mb-4 p-4 bg-blue-50 rounded-xl">
              <p className="text-xs font-semibold text-blue-600 mb-1 uppercase tracking-wide">Learning Objectives</p>
              <p className="text-sm text-blue-800">{selected.objectives}</p>
            </div>
          )}
          <div className="prose prose-sm max-w-none">
            <div className="text-gray-700 whitespace-pre-wrap leading-relaxed">{selected.content}</div>
          </div>
          {selected.resources?.length > 0 && (
            <div className="mt-6">
              <p className="font-semibold mb-2 text-sm">Resources</p>
              <div className="space-y-2">
                {selected.resources.map((r: any, i: number) => (
                  <a key={i} href={r.url} target="_blank" rel="noreferrer"
                    className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800 underline">
                    <BookOpen size={14}/>{r.label}
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    )
  }

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">eLearning</h1>
        <span className="badge badge-blue">{data?.count ?? 0} lessons</span>
      </div>

      <div className="mb-4">
        <input className="input max-w-sm" placeholder="Search lessons..." value={search} onChange={e=>setSearch(e.target.value)}/>
      </div>

      {isLoading ? <div className="p-8 text-center"><Loader2 className="animate-spin mx-auto text-gray-400"/></div> : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered?.map((l: Lesson) => (
            <button key={l.id} onClick={() => setSelected(l)}
              className="card p-5 text-left hover:shadow-md transition-shadow group cursor-pointer">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-100 text-indigo-700 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <BookOpen size={20}/>
                </div>
                <div className="flex items-center gap-1 text-xs text-gray-400">
                  <Clock size={12}/>{l.estimated_duration} min
                </div>
              </div>
              <p className="font-semibold mb-1">{l.title}</p>
              <p className="text-xs text-gray-500">{l.subject} · Grade {l.grade} · Term {l.term}</p>
              <p className="text-sm text-gray-600 mt-2 line-clamp-2">{l.description||l.content.substring(0,100)}</p>
            </button>
          ))}
          {filtered?.length === 0 && (
            <div className="col-span-full text-center py-12 text-gray-400">
              <BookOpen size={48} className="mx-auto mb-3 opacity-30"/>
              <p>No lessons found.</p>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
