import { useQuery } from "@tanstack/react-query"
import { lessonAPI, assessmentAPI } from "../../lib/api"
import { useAuthStore } from "../../lib/store"
import { Brain, Library, BookOpen, BarChart2 } from "lucide-react"
import { Link } from "react-router-dom"

export default function StudentDashboard() {
  const { user } = useAuthStore()

  const { data: lessons } = useQuery({
    queryKey: ["student-lessons"],
    queryFn: () => lessonAPI.getAll({ status: "published" }).then(r => r.data)
  })

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Student Dashboard</h1>
          <p className="text-sm text-gray-500 mt-0.5">Welcome back, {user?.full_name}!</p>
        </div>
        <span className="badge badge-blue">Student</span>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8">
        <div className="stat-card">
          <p className="stat-value">{lessons?.count ?? 0}</p>
          <p className="stat-label">Available Lessons</p>
        </div>
        <div className="stat-card">
          <p className="stat-value">Term 1</p>
          <p className="stat-label">Current Term</p>
        </div>
        <div className="stat-card">
          <p className="stat-value">2025</p>
          <p className="stat-label">Academic Year</p>
        </div>
      </div>

      {/* Quick links */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
        <Link to="/student/quiz" className="card p-6 hover:shadow-md transition-shadow group flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-purple-100 text-purple-700 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Brain size={28}/>
          </div>
          <div>
            <p className="font-bold text-lg">AI Quiz</p>
            <p className="text-sm text-gray-500">Take auto-graded quizzes, get instant results</p>
          </div>
        </Link>
        <Link to="/student/elearning" className="card p-6 hover:shadow-md transition-shadow group flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Library size={28}/>
          </div>
          <div>
            <p className="font-bold text-lg">eLearning</p>
            <p className="text-sm text-gray-500">Access lessons published by your teachers</p>
          </div>
        </Link>
      </div>

      {/* Recent lessons preview */}
      {lessons?.results?.slice(0, 4).length > 0 && (
        <div>
          <h2 className="font-semibold text-gray-700 mb-3">Recent Lessons</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {lessons.results.slice(0, 4).map((l: any) => (
              <Link to="/student/elearning" key={l.id} className="card p-4 hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3">
                  <BookOpen size={18} className="text-indigo-500 flex-shrink-0"/>
                  <div className="min-w-0">
                    <p className="font-medium text-sm truncate">{l.title}</p>
                    <p className="text-xs text-gray-400">{l.subject} · {l.estimated_duration} min</p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
