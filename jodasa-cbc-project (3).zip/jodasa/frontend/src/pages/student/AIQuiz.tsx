import { useState } from "react"
import { useQuery, useMutation } from "@tanstack/react-query"
import { assessmentAPI, studentAPI } from "../../lib/api"
import { useAuthStore } from "../../lib/store"
import { Brain, CheckCircle, XCircle, Loader2, BarChart2, ArrowRight } from "lucide-react"
import toast from "react-hot-toast"
import type { Assessment, QuizQuestion } from "../../types"
import { CBC_PERFORMANCE_LABELS } from "../../types"

export default function AIQuiz() {
  const { user } = useAuthStore()
  const [selectedAssessment, setSelectedAssessment] = useState<Assessment|null>(null)
  const [answers, setAnswers] = useState<Record<string,string>>({})
  const [submitted, setSubmitted] = useState(false)
  const [quizResult, setQuizResult] = useState<any>(null)

  const { data: assessments } = useQuery({
    queryKey: ["assessments-quiz"],
    queryFn: () => assessmentAPI.getAll({ assessment_type: "quiz" }).then(r => r.data)
  })

  const { data: students } = useQuery({
    queryKey: ["my-student"],
    queryFn: () => studentAPI.getAll().then(r => r.data)
  })

  const myStudent = students?.results?.[0]

  const submitMutation = useMutation({
    mutationFn: () => assessmentAPI.submitQuiz(selectedAssessment!.id, {
      student_id: myStudent?.id,
      answers
    }),
    onSuccess: (r) => { setQuizResult(r.data); setSubmitted(true); toast.success("Quiz submitted!") },
    onError: () => toast.error("Submission failed. Try again.")
  })

  const selectAnswer = (qId: string, option: string) => {
    if (submitted) return
    setAnswers(a => ({ ...a, [qId]: option }))
  }

  const perfColors: Record<string,string> = { EE:"text-green-700 bg-green-100", ME:"text-blue-700 bg-blue-100", AE:"text-yellow-700 bg-yellow-100", BE:"text-red-700 bg-red-100" }

  const resetQuiz = () => {
    setSelectedAssessment(null); setAnswers({}); setSubmitted(false); setQuizResult(null)
  }

  if (submitted && quizResult) {
    return (
      <div>
        <div className="page-header">
          <h1 className="page-title">Quiz Results</h1>
        </div>
        <div className="max-w-2xl">
          {/* Score card */}
          <div className="card p-8 text-center mb-6">
            <div className={`inline-flex items-center justify-center w-24 h-24 rounded-full text-3xl font-bold mb-4 ${perfColors[quizResult.cbc_performance]}`}>
              {quizResult.percentage}%
            </div>
            <h2 className="text-2xl font-bold mb-1">{quizResult.score} / {quizResult.total} Correct</h2>
            <div className={`inline-block px-4 py-2 rounded-full font-semibold mb-2 ${perfColors[quizResult.cbc_performance]}`}>
              {quizResult.cbc_performance} — {CBC_PERFORMANCE_LABELS[quizResult.cbc_performance]}
            </div>
          </div>

          {/* Answers breakdown */}
          <div className="card overflow-hidden mb-4">
            <div className="px-4 py-3 border-b border-gray-100 font-semibold">Question-by-Question Review</div>
            <div className="divide-y divide-gray-100">
              {quizResult.results?.map((r: any, i: number) => (
                <div key={r.question_id} className="px-4 py-3">
                  <div className="flex items-start gap-3">
                    <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${r.is_correct?"bg-green-100":"bg-red-100"}`}>
                      {r.is_correct ? <CheckCircle size={14} className="text-green-600"/> : <XCircle size={14} className="text-red-600"/>}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium mb-1">Q{i+1}: {r.question_text}</p>
                      <p className={`text-xs ${r.is_correct?"text-green-700":"text-red-600"}`}>
                        Your answer: <strong>{r.chosen || "Not answered"}</strong>
                        {!r.is_correct && <span className="text-green-700 ml-2">Correct: <strong>{r.correct_answer}</strong></span>}
                      </p>
                      {r.explanation && <p className="text-xs text-gray-500 mt-1 italic">{r.explanation}</p>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <button className="btn-primary" onClick={resetQuiz}><ArrowRight size={16}/>Take Another Quiz</button>
        </div>
      </div>
    )
  }

  if (selectedAssessment) {
    const questions = selectedAssessment.questions || []
    const answered = Object.keys(answers).length
    const progress = questions.length ? Math.round(answered / questions.length * 100) : 0

    return (
      <div>
        <div className="page-header">
          <h1 className="page-title">{selectedAssessment.title}</h1>
          <span className="text-sm text-gray-500">{answered}/{questions.length} answered</span>
        </div>

        {/* Progress bar */}
        <div className="w-full bg-gray-200 rounded-full h-2 mb-6">
          <div className="bg-blue-600 h-2 rounded-full transition-all" style={{width:`${progress}%`}}/>
        </div>

        {questions.length === 0 ? (
          <div className="card p-8 text-center text-gray-400">
            <Brain size={48} className="mx-auto mb-3 opacity-30"/>
            <p>No questions have been added to this quiz yet.</p>
            <button className="btn-secondary mt-4" onClick={resetQuiz}>Go Back</button>
          </div>
        ) : (
          <div className="space-y-4">
            {questions.map((q: QuizQuestion, i: number) => (
              <div key={q.id} className="card p-5">
                <p className="font-semibold mb-3">Q{i+1}: {q.question_text}</p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {(["A","B","C","D"] as const).map(opt => {
                    const val = q[`option_${opt.toLowerCase()}` as keyof QuizQuestion] as string
                    const isSelected = answers[q.id] === opt
                    return (
                      <button key={opt} onClick={() => selectAnswer(q.id, opt)}
                        className={`text-left px-4 py-3 rounded-lg border-2 text-sm transition-all ${
                          isSelected ? "border-blue-500 bg-blue-50 text-blue-800 font-medium" : "border-gray-200 hover:border-gray-300 hover:bg-gray-50"
                        }`}>
                        <span className="font-bold mr-2">{opt}.</span>{val}
                      </button>
                    )
                  })}
                </div>
              </div>
            ))}

            <div className="flex gap-3 pt-2">
              <button className="btn-primary py-3 px-6" onClick={() => submitMutation.mutate()}
                disabled={submitMutation.isPending || answered < questions.length}>
                {submitMutation.isPending ? <Loader2 size={16} className="animate-spin"/> : <CheckCircle size={16}/>}
                Submit Quiz ({answered}/{questions.length} answered)
              </button>
              <button className="btn-secondary" onClick={resetQuiz}>Cancel</button>
            </div>
          </div>
        )}
      </div>
    )
  }

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">AI Quiz</h1>
        <span className="badge badge-purple">Student Portal</span>
      </div>

      <div className="mb-6 p-4 bg-purple-50 rounded-xl flex items-center gap-3">
        <Brain size={24} className="text-purple-600 flex-shrink-0"/>
        <p className="text-sm text-purple-800">Choose a quiz below. Questions are CBC-aligned and auto-graded instantly.</p>
      </div>

      {!assessments?.results?.length ? (
        <div className="card p-12 text-center text-gray-400">
          <Brain size={48} className="mx-auto mb-3 opacity-30"/>
          <p>No quizzes available yet. Check back soon!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {assessments.results.map((a: Assessment) => (
            <button key={a.id} onClick={() => setSelectedAssessment(a)}
              className="card p-5 text-left hover:shadow-md transition-shadow group cursor-pointer">
              <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                <Brain size={20}/>
              </div>
              <p className="font-semibold">{a.title}</p>
              <p className="text-sm text-gray-500 mt-0.5">{a.subject} · Grade {a.grade}</p>
              <div className="flex gap-2 mt-3">
                <span className="badge badge-blue">{a.questions?.length ?? 0} questions</span>
                <span className="badge badge-gray">Term {a.term}</span>
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}
