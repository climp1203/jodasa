import { useState } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { tenantAPI } from "../../lib/api"
import { Plus, Edit2, Trash2, Loader2 } from "lucide-react"
import toast from "react-hot-toast"
import type { Tenant } from "../../types"

const blank = { name:"", slug:"", county:"", email:"", phone:"", subscription_plan:"standard" }

export default function SuperadminSchools() {
  const qc = useQueryClient()
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState<Tenant|null>(null)
  const [form, setForm] = useState<any>(blank)

  const { data, isLoading } = useQuery({ queryKey:["tenants"], queryFn: () => tenantAPI.getAll().then(r=>r.data) })

  const saveMutation = useMutation({
    mutationFn: (f: any) => editing ? tenantAPI.update(editing.id, f) : tenantAPI.create(f),
    onSuccess: () => { qc.invalidateQueries({queryKey:["tenants"]}); toast.success("Saved!"); setShowForm(false); setEditing(null); setForm(blank) },
    onError: (e: any) => toast.error(e?.response?.data?.slug?.[0] || "Error saving school")
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string) => tenantAPI.delete(id),
    onSuccess: () => { qc.invalidateQueries({queryKey:["tenants"]}); toast.success("Deleted") }
  })

  const openEdit = (t: Tenant) => { setEditing(t); setForm({...t}); setShowForm(true) }
  const field = (k: string, v: string) => setForm((f:any) => ({...f, [k]:v}))

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Schools</h1>
        <button className="btn-primary" onClick={() => { setEditing(null); setForm(blank); setShowForm(true) }}>
          <Plus size={16}/>Add School
        </button>
      </div>

      {showForm && (
        <div className="card p-6 mb-6">
          <h2 className="font-semibold mb-4">{editing ? "Edit School" : "New School"}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {[["name","School Name"],["slug","Slug (subdomain)"],["county","County"],["email","Email"],["phone","Phone"]].map(([k,l]) => (
              <div key={k}>
                <label className="label">{l}</label>
                <input className="input" value={form[k]||""} onChange={e=>field(k,e.target.value)} placeholder={l as string}/>
              </div>
            ))}
            <div>
              <label className="label">Plan</label>
              <select className="input" value={form.subscription_plan} onChange={e=>field("subscription_plan",e.target.value)}>
                <option value="basic">Basic</option>
                <option value="standard">Standard</option>
                <option value="premium">Premium</option>
              </select>
            </div>
          </div>
          <div className="flex gap-3 mt-4">
            <button className="btn-primary" onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending}>
              {saveMutation.isPending ? <Loader2 size={14} className="animate-spin"/> : null} Save
            </button>
            <button className="btn-secondary" onClick={() => setShowForm(false)}>Cancel</button>
          </div>
        </div>
      )}

      <div className="card overflow-hidden">
        {isLoading ? <div className="p-8 text-center text-gray-400"><Loader2 className="animate-spin mx-auto"/></div> : (
          <table className="table-auto w-full">
            <thead><tr><th>School</th><th>Slug</th><th>County</th><th>Plan</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>
              {data?.results?.map((t: Tenant) => (
                <tr key={t.id} className="hover:bg-gray-50">
                  <td className="font-medium">{t.name}</td>
                  <td className="text-blue-600">{t.slug}</td>
                  <td>{t.county}</td>
                  <td><span className="badge badge-blue capitalize">{t.subscription_plan}</span></td>
                  <td><span className={t.is_active ? "badge-green badge" : "badge-red badge"}>{t.is_active?"Active":"Inactive"}</span></td>
                  <td>
                    <div className="flex gap-2">
                      <button className="btn-ghost p-1" onClick={() => openEdit(t)}><Edit2 size={14}/></button>
                      <button className="btn-ghost p-1 text-red-500" onClick={() => { if(confirm("Delete?")) deleteMutation.mutate(t.id) }}><Trash2 size={14}/></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
