import { useQuery } from "@tanstack/react-query"
import { tenantAPI, userAPI } from "../../lib/api"
import { School, Users, Activity, TrendingUp, CheckCircle, XCircle } from "lucide-react"
import { Spinner } from "../../components/ui"
import type { Tenant } from "../../types"

export default function SuperadminDashboard() {
  const { data: tenants, isLoading: loadingTenants } = useQuery({
    queryKey: ["tenants"],
    queryFn: () => tenantAPI.getAll().then(r => r.data)
  })
  const { data: users, isLoading: loadingUsers } = useQuery({
    queryKey: ["users"],
    queryFn: () => userAPI.getAll().then(r => r.data)
  })

  const isLoading = loadingTenants || loadingUsers

  const activeSchools = tenants?.results?.filter((t: Tenant) => t.is_active).length ?? 0
  const totalSchools = tenants?.count ?? 0
  const totalUsers = users?.count ?? 0

  const stats = [
    { label: "Total Schools", value: isLoading ? "—" : totalSchools, icon: School, color: "bg-blue-100 text-blue-700" },
    { label: "Active Schools", value: isLoading ? "—" : activeSchools, icon: Activity, color: "bg-green-100 text-green-700" },
    { label: "Total Users", value: isLoading ? "—" : totalUsers, icon: Users, color: "bg-purple-100 text-purple-700" },
    { label: "Platform Health", value: "Good", icon: TrendingUp, color: "bg-orange-100 text-orange-700" },
  ]

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Platform Overview</h1>
        <span className="badge badge-blue">Superadmin</span>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {stats.map(s => (
          <div key={s.label} className="stat-card">
            <div className={`w-10 h-10 rounded-xl ${s.color} flex items-center justify-center mb-2`}>
              <s.icon size={20}/>
            </div>
            <p className="stat-value">{s.value}</p>
            <p className="stat-label">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Plan distribution */}
      {!isLoading && tenants?.results && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
          {["basic","standard","premium"].map(plan => {
            const count = tenants.results.filter((t: Tenant) => t.subscription_plan === plan).length
            const colors: Record<string,string> = { basic:"bg-gray-100 text-gray-700", standard:"bg-blue-100 text-blue-700", premium:"bg-purple-100 text-purple-700" }
            return (
              <div key={plan} className="card p-4 flex items-center gap-4">
                <div className={`px-3 py-1.5 rounded-lg font-semibold text-sm capitalize ${colors[plan]}`}>{plan}</div>
                <div>
                  <p className="text-2xl font-bold">{count}</p>
                  <p className="text-xs text-gray-400">schools</p>
                </div>
              </div>
            )
          })}
        </div>
      )}

      {/* Schools table */}
      <div className="card overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
          <h2 className="font-semibold text-gray-900">All Schools</h2>
          <span className="text-sm text-gray-400">{totalSchools} total</span>
        </div>
        {isLoading ? <Spinner text="Loading schools..."/> : (
          tenants?.results?.length === 0 ? (
            <div className="p-8 text-center text-gray-400">No schools registered yet.</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="table-auto w-full">
                <thead><tr><th>School</th><th>Slug</th><th>County</th><th>Plan</th><th>Status</th></tr></thead>
                <tbody>
                  {tenants?.results?.map((t: Tenant) => (
                    <tr key={t.id} className="hover:bg-gray-50">
                      <td className="font-medium">{t.name}</td>
                      <td className="text-blue-600 font-mono text-xs">{t.slug}</td>
                      <td className="text-gray-500">{t.county || "—"}</td>
                      <td><span className="badge badge-blue capitalize">{t.subscription_plan}</span></td>
                      <td>
                        <span className={`flex items-center gap-1 w-fit badge ${t.is_active ? "badge-green" : "badge-red"}`}>
                          {t.is_active ? <CheckCircle size={11}/> : <XCircle size={11}/>}
                          {t.is_active ? "Active" : "Inactive"}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )
        )}
      </div>
    </div>
  )
}
