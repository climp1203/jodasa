import { useQuery } from "@tanstack/react-query"
import { userAPI } from "../../lib/api"
import { Spinner } from "../../components/ui"
import { Users } from "lucide-react"
import type { User } from "../../types"

const roleColors: Record<string,string> = {
  superadmin:"badge-red badge", school_admin:"badge-blue badge",
  teacher:"badge-green badge", parent:"badge-yellow badge", student:"badge-gray badge"
}

export default function SuperadminUsers() {
  const { data, isLoading } = useQuery({
    queryKey: ["all-users"],
    queryFn: () => userAPI.getAll().then(r => r.data)
  })

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">All Users</h1>
        <span className="text-sm text-gray-500">{data?.count ?? 0} users</span>
      </div>
      <div className="card overflow-hidden">
        {isLoading ? <Spinner text="Loading users..."/> :
         data?.results?.length === 0 ? (
          <div className="p-12 text-center text-gray-400">
            <Users size={48} className="mx-auto mb-3 opacity-30"/>
            <p>No users registered yet.</p>
          </div>
         ) : (
          <div className="overflow-x-auto">
            <table className="table-auto w-full">
              <thead><tr><th>Name</th><th>Username</th><th>Email</th><th>Role</th><th>Status</th></tr></thead>
              <tbody>
                {data?.results?.map((u: User) => (
                  <tr key={u.id} className="hover:bg-gray-50">
                    <td className="font-medium">{u.full_name}</td>
                    <td className="text-gray-500 font-mono text-xs">{u.username}</td>
                    <td className="text-gray-500">{u.email}</td>
                    <td><span className={roleColors[u.role]||"badge-gray badge"} style={{textTransform:"capitalize"}}>{u.role.replace("_"," ")}</span></td>
                    <td><span className={u.is_active?"badge-green badge":"badge-red badge"}>{u.is_active?"Active":"Inactive"}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  )
}
