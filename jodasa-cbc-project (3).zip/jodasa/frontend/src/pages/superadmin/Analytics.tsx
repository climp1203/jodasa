import { useQuery } from "@tanstack/react-query"
import { tenantAPI, userAPI } from "../../lib/api"
import { BarChartCard, PieChartCard } from "../../components/ui/Charts"
import Spinner from "../../components/ui/Spinner"

export default function SuperadminAnalytics() {
  const { data: tenants, isLoading } = useQuery({ queryKey:["tenants"], queryFn: () => tenantAPI.getAll().then(r=>r.data) })
  const { data: users } = useQuery({ queryKey:["all-users"], queryFn: () => userAPI.getAll().then(r=>r.data) })

  if (isLoading) return <Spinner text="Loading analytics..."/>

  const planData = [
    { name:"Basic", value: tenants?.results?.filter((t:any)=>t.subscription_plan==="basic").length || 0 },
    { name:"Standard", value: tenants?.results?.filter((t:any)=>t.subscription_plan==="standard").length || 0 },
    { name:"Premium", value: tenants?.results?.filter((t:any)=>t.subscription_plan==="premium").length || 0 },
  ]

  const roleData = ["superadmin","school_admin","teacher","parent","student"].map(role => ({
    name: role.replace("_"," "),
    value: users?.results?.filter((u:any)=>u.role===role).length || 0
  }))

  const statusData = [
    { name:"Active", value: tenants?.results?.filter((t:any)=>t.is_active).length || 0 },
    { name:"Inactive", value: tenants?.results?.filter((t:any)=>!t.is_active).length || 0 },
  ]

  const countyData = tenants?.results?.reduce((acc:any, t:any) => {
    if (t.county) acc[t.county] = (acc[t.county]||0) + 1
    return acc
  }, {}) || {}
  const countyChartData = Object.entries(countyData).map(([name,value]) => ({name, value: value as number}))

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Platform Analytics</h1>
        <span className="badge badge-blue">Superadmin</span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
        {[
          {label:"Total Schools", value: tenants?.count || 0},
          {label:"Active Schools", value: tenants?.results?.filter((t:any)=>t.is_active).length || 0},
          {label:"Total Users", value: users?.count || 0},
          {label:"Teachers", value: users?.results?.filter((u:any)=>u.role==="teacher").length || 0},
        ].map(s=>(
          <div key={s.label} className="stat-card">
            <p className="stat-value">{s.value}</p>
            <p className="stat-label">{s.label}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-4">
        <BarChartCard data={roleData} title="Users by Role" color="#3b82f6"/>
        <PieChartCard data={planData} title="Schools by Subscription Plan"/>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <BarChartCard data={countyChartData} title="Schools by County" color="#10b981"/>
        <PieChartCard data={statusData} title="School Status"/>
      </div>
    </div>
  )
}
