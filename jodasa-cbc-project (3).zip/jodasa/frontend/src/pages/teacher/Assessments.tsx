import { useState } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { assessmentAPI } from "../../lib/api"
import { Plus, Sparkles, Loader2, ChevronRight, Save } from "lucide-react"
import toast from "react-hot-toast"
import { GRADES, TERMS } from "../../types"
import type { Assessment, QuizQuestion } from "../../types"

const blankAssessment = { title:"", subject:"Mathematics", grade:"G4", stream:"", assessment_type:"formative", description:"", max_score:100, date:new Date().toISOString().split("T")[0], term:"1", year:new Date().getFullYear() }

export default function AssessmentPage() {
  const qc = useQueryClient()
  const [tab, setTab] = useState<"list"|"create"|"quiz">("list")
  const [form, setForm] = useState<any>(blankAssessment)
  const [quizGen, setQuizGen] = useState({ topic:"", num_questions:10 })
  const [generatedQuestions, setGeneratedQuestions] = useState<QuizQuestion[]>([])
  const [selectedAssessment, setSelectedAssessment] = useState<Assessment|null>(null)

  const { data, isLoading } = useQuery({ queryKey:["assessments"], queryFn: () => assessmentAPI.getAll().then(r=>r.data) })

  const createMutation = useMutation({
    mutationFn: (f:any) => assessmentAPI.create(f),
    onSuccess: (r) => { qc.invalidateQueries({queryKey:["assessments"]}); toast.success("Assessment created!"); setSelectedAssessment(r.data); setTab("quiz") }
  })

  const generateMutation = useMutation({
    mutationFn: () => assessmentAPI.generateQuiz({ ...quizGen, subject: form.subject, grade: form.grade }),
    onSuccess: (r) => { setGeneratedQuestions(r.data.questions); toast.success(`${r.data.count} questions generated!`) },
    onError: () => toast.error("AI generation failed. Check your API key.")
  })

  const saveQuestionsMutation = useMutation({
    mutationFn: () => assessmentAPI.saveQuestions(selectedAssessment!.id, { questions: generatedQuestions }),
    onSuccess: () => { toast.success("Questions saved!"); setTab("list"); qc.invalidateQueries({queryKey:["assessments"]}) }
  })

  const typeColors: Record<string,string> = { formative:"badge-blue", summative:"badge-purple", project:"badge-green", quiz:"badge-orange" }

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Assessments</h1>
        <button className="btn-primary" onClick={()=>setTab("create")}><Plus size={16}/>New Assessment</button>
      </div>

      <div className="flex gap-1 p-1 bg-gray-100 rounded-lg w-fit mb-6">
        {[["list","All Assessments"],["create","Create"],["quiz","AI Quiz Builder"]].map(([k,l]) => (
          <button key={k} onClick={()=>setTab(k as any)}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${tab===k?"bg-white shadow text-gray-900":"text-gray-500 hover:text-gray-700"}`}>
            {l}
          </button>
        ))}
      </div>

      {tab==="list" && (
        <div className="card overflow-hidden">
          {isLoading ? <div className="p-8 text-center"><Loader2 className="animate-spin mx-auto text-gray-400"/></div> : (
            <table className="table-auto w-full">
              <thead><tr><th>Title</th><th>Subject</th><th>Grade</th><th>Type</th><th>Date</th><th>Results</th><th></th></tr></thead>
              <tbody>
                {data?.results?.map((a:Assessment) => (
                  <tr key={a.id} className="hover:bg-gray-50">
                    <td className="font-medium">{a.title}</td>
                    <td>{a.subject}</td>
                    <td><span className="badge badge-blue">{a.grade}</span></td>
                    <td><span className={`badge ${typeColors[a.assessment_type]||"badge-gray"} capitalize`}>{a.assessment_type}</span></td>
                    <td className="text-sm text-gray-500">{a.date}</td>
                    <td>{a.result_count} results</td>
                    <td>
                      <button className="btn-ghost p-1" onClick={()=>{setSelectedAssessment(a);setTab("quiz")}}>
                        <ChevronRight size={16}/>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {tab==="create" && (
        <div className="card p-6 max-w-2xl">
          <h2 className="font-semibold mb-4">New Assessment</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="col-span-2"><label className="label">Title</label>
              <input className="input" value={form.title} onChange={e=>setForm((f:any)=>({...f,title:e.target.value}))} placeholder="e.g. End of Term 1 Mathematics"/></div>
            <div><label className="label">Subject</label>
              <input className="input" value={form.subject} onChange={e=>setForm((f:any)=>({...f,subject:e.target.value}))}/></div>
            <div><label className="label">Grade</label>
              <select className="input" value={form.grade} onChange={e=>setForm((f:any)=>({...f,grade:e.target.value}))}>
                {GRADES.map(g=><option key={g} value={g}>{g}</option>)}
              </select></div>
            <div><label className="label">Type</label>
              <select className="input" value={form.assessment_type} onChange={e=>setForm((f:any)=>({...f,assessment_type:e.target.value}))}>
                {["formative","summative","project","quiz"].map(t=><option key={t} value={t}>{t}</option>)}
              </select></div>
            <div><label className="label">Term</label>
              <select className="input" value={form.term} onChange={e=>setForm((f:any)=>({...f,term:e.target.value}))}>
                {TERMS.map(t=><option key={t.value} value={t.value}>{t.label}</option>)}
              </select></div>
            <div><label className="label">Date</label>
              <input className="input" type="date" value={form.date} onChange={e=>setForm((f:any)=>({...f,date:e.target.value}))}/></div>
            <div><label className="label">Max Score</label>
              <input className="input" type="number" value={form.max_score} onChange={e=>setForm((f:any)=>({...f,max_score:e.target.value}))}/></div>
          </div>
          <div className="flex gap-3 mt-4">
            <button className="btn-primary" onClick={()=>createMutation.mutate(form)} disabled={createMutation.isPending}>
              {createMutation.isPending?<Loader2 size={14} className="animate-spin"/>:null} Create & Add Questions
            </button>
            <button className="btn-secondary" onClick={()=>setTab("list")}>Cancel</button>
          </div>
        </div>
      )}

      {tab==="quiz" && selectedAssessment && (
        <div>
          <div className="flex items-center gap-3 mb-4 p-3 bg-blue-50 rounded-lg">
            <Sparkles size={18} className="text-blue-600"/>
            <p className="text-sm text-blue-800">Building quiz for: <strong>{selectedAssessment.title}</strong> · {selectedAssessment.grade} · {selectedAssessment.subject}</p>
          </div>

          {/* AI Generator */}
          <div className="card p-6 mb-6">
            <h3 className="font-semibold mb-4 flex items-center gap-2"><Sparkles size={18} className="text-purple-500"/>AI Question Generator</h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="col-span-2"><label className="label">Topic / Learning Objective</label>
                <input className="input" value={quizGen.topic} onChange={e=>setQuizGen(q=>({...q,topic:e.target.value}))} placeholder="e.g. Fractions and decimals"/></div>
              <div><label className="label">Number of Questions</label>
                <input className="input" type="number" min={1} max={20} value={quizGen.num_questions} onChange={e=>setQuizGen(q=>({...q,num_questions:+e.target.value}))}/></div>
            </div>
            <button className="btn-primary mt-4" onClick={()=>generateMutation.mutate()} disabled={generateMutation.isPending||!quizGen.topic}>
              {generateMutation.isPending?<><Loader2 size={14} className="animate-spin"/>Generating with AI...</>:<><Sparkles size={14}/>Generate Questions</>}
            </button>
          </div>

          {/* Generated questions preview */}
          {generatedQuestions.length > 0 && (
            <div className="card overflow-hidden mb-4">
              <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
                <p className="font-semibold">{generatedQuestions.length} Questions Generated</p>
                <button className="btn-primary" onClick={()=>saveQuestionsMutation.mutate()} disabled={saveQuestionsMutation.isPending}>
                  {saveQuestionsMutation.isPending?<Loader2 size={14} className="animate-spin"/>:<Save size={14}/>} Save Questions
                </button>
              </div>
              <div className="divide-y divide-gray-100 max-h-96 overflow-y-auto">
                {generatedQuestions.map((q:any, i:number) => (
                  <div key={i} className="px-4 py-3">
                    <p className="text-sm font-medium mb-2">Q{i+1}: {q.question_text}</p>
                    <div className="grid grid-cols-2 gap-1">
                      {["a","b","c","d"].map(opt => (
                        <p key={opt} className={`text-xs px-2 py-1 rounded ${q.correct_answer.toLowerCase()===opt?"bg-green-100 text-green-800 font-medium":"text-gray-600"}`}>
                          {opt.toUpperCase()}. {q[`option_${opt}`]}
                        </p>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
