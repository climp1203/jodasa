import { useState } from "react"
import { useQuery } from "@tanstack/react-query"
import { assessmentAPI } from "../../lib/api"
import { Loader2, BarChart2 } from "lucide-react"
import type { Assessment, AssessmentResult } from "../../types"
import { CBC_PERFORMANCE_LABELS } from "../../types"

export default function StudentTestResults() {
  const [selectedId, setSelectedId] = useState<string>("")

  const { data: assessments } = useQuery({ queryKey:["assessments"], queryFn: () => assessmentAPI.getAll().then(r=>r.data) })
  const { data: results, isLoading } = useQuery({
    queryKey:["results", selectedId],
    queryFn: () => assessmentAPI.results(selectedId).then(r=>r.data),
    enabled: !!selectedId
  })

  const perfColors: Record<string,string> = { EE:"cbc-ee", ME:"cbc-me", AE:"cbc-ae", BE:"cbc-be" }
  const summary = results ? {
    EE: results.filter((r:AssessmentResult)=>r.cbc_performance==="EE").length,
    ME: results.filter((r:AssessmentResult)=>r.cbc_performance==="ME").length,
    AE: results.filter((r:AssessmentResult)=>r.cbc_performance==="AE").length,
    BE: results.filter((r:AssessmentResult)=>r.cbc_performance==="BE").length,
  } : null

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Test Results</h1>
      </div>

      <div className="mb-6 max-w-sm">
        <label className="label">Select Assessment</label>
        <select className="input" value={selectedId} onChange={e=>setSelectedId(e.target.value)}>
          <option value="">Choose assessment...</option>
          {assessments?.results?.map((a:Assessment)=><option key={a.id} value={a.id}>{a.title} — {a.grade} — {a.date}</option>)}
        </select>
      </div>

      {summary && (
        <div className="grid grid-cols-4 gap-4 mb-6">
          {Object.entries(summary).map(([k,v]) => (
            <div key={k} className="stat-card">
              <span className={`badge ${perfColors[k]} mb-2`}>{k}</span>
              <p className="stat-value text-2xl">{v as number}</p>
              <p className="stat-label text-xs">{CBC_PERFORMANCE_LABELS[k]}</p>
            </div>
          ))}
        </div>
      )}

      {selectedId && (
        <div className="card overflow-hidden">
          {isLoading ? <div className="p-8 text-center"><Loader2 className="animate-spin mx-auto text-gray-400"/></div> : (
            <table className="table-auto w-full">
              <thead><tr><th>Adm No.</th><th>Student</th><th>Score</th><th>CBC Performance</th><th>Remarks</th><th>Date</th></tr></thead>
              <tbody>
                {results?.map((r:AssessmentResult) => (
                  <tr key={r.id} className="hover:bg-gray-50">
                    <td className="font-mono text-xs">{r.admission_number}</td>
                    <td className="font-medium">{r.student_name}</td>
                    <td>{r.score != null ? `${r.score}%` : "—"}</td>
                    <td>{r.cbc_performance ? <span className={`badge ${perfColors[r.cbc_performance]}`}>{r.cbc_performance} — {CBC_PERFORMANCE_LABELS[r.cbc_performance]}</span> : "—"}</td>
                    <td className="text-sm text-gray-500">{r.teacher_remarks||"—"}</td>
                    <td className="text-xs text-gray-400">{new Date(r.submitted_at).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {!selectedId && (
        <div className="card p-12 text-center text-gray-400">
          <BarChart2 size={48} className="mx-auto mb-3 opacity-30"/>
          <p>Select an assessment above to view student results</p>
        </div>
      )}
    </div>
  )
}
