import { useQuery } from "@tanstack/react-query"
import { attendanceAPI, assessmentAPI, studentAPI } from "../../lib/api"
import { useAuthStore } from "../../lib/store"
import { QrCode, ClipboardList, Folder, BookOpen, BarChart2, Leaf, Loader2 } from "lucide-react"
import { Link } from "react-router-dom"

export default function TeacherDashboard() {
  const { user } = useAuthStore()
  const { data: sessions, isLoading: l1 } = useQuery({ queryKey:["sessions"], queryFn: () => attendanceAPI.getSessions().then(r=>r.data) })
  const { data: assessments, isLoading: l2 } = useQuery({ queryKey:["assessments"], queryFn: () => assessmentAPI.getAll().then(r=>r.data) })
  const { data: students, isLoading: l3 } = useQuery({ queryKey:["students"], queryFn: () => studentAPI.getAll().then(r=>r.data) })
  const isLoading = l1 || l2 || l3

  const todayStr = new Date().toISOString().split("T")[0]
  const todaySessions = sessions?.results?.filter((s:any) => s.date === todayStr).length ?? 0

  const links = [
    {to:"/teacher/attendance", icon:QrCode, label:"Mark Attendance", desc:"QR camera + manual marking", color:"bg-blue-100 text-blue-700"},
    {to:"/teacher/assessments", icon:ClipboardList, label:"Assessments", desc:"CBC rubrics & AI quizzes", color:"bg-purple-100 text-purple-700"},
    {to:"/teacher/portfolio", icon:Folder, label:"Portfolio", desc:"Student evidence entries", color:"bg-green-100 text-green-700"},
    {to:"/teacher/csl", icon:Leaf, label:"CSL Tracker", desc:"Community service hours", color:"bg-orange-100 text-orange-700"},
    {to:"/teacher/lessons", icon:BookOpen, label:"Lesson Planner", desc:"Create & publish lessons", color:"bg-indigo-100 text-indigo-700"},
    {to:"/teacher/results", icon:BarChart2, label:"Test Results", desc:"View class performance", color:"bg-pink-100 text-pink-700"},
  ]

  return (
    <div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Teacher Dashboard</h1>
          <p className="text-sm text-gray-500 mt-0.5">Welcome, {user?.full_name}</p>
        </div>
        <span className="badge badge-green">Teacher</span>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          {label:"My Students", value: isLoading ? <Loader2 size={16} className="animate-spin"/> : students?.count ?? 0},
          {label:"Sessions Today", value: isLoading ? <Loader2 size={16} className="animate-spin"/> : todaySessions},
          {label:"Assessments", value: isLoading ? <Loader2 size={16} className="animate-spin"/> : assessments?.count ?? 0},
          {label:"Current Term", value:"Term 1"},
        ].map(s => (
          <div key={s.label} className="stat-card">
            <p className="stat-value text-2xl flex items-center">{s.value}</p>
            <p className="stat-label">{s.label}</p>
          </div>
        ))}
      </div>

      <h2 className="font-semibold text-gray-700 mb-3">Quick Actions</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {links.map(l => (
          <Link key={l.to} to={l.to} className="card p-5 hover:shadow-md transition-shadow group">
            <div className={`w-11 h-11 rounded-xl ${l.color} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
              <l.icon size={22}/>
            </div>
            <p className="font-semibold text-gray-900">{l.label}</p>
            <p className="text-sm text-gray-500 mt-0.5">{l.desc}</p>
          </Link>
        ))}
      </div>
    </div>
  )
}
