import { useState } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { portfolioAPI, studentAPI } from "../../lib/api"
import { Plus, Loader2, Folder, Trash2 } from "lucide-react"
import toast from "react-hot-toast"
import { TERMS, CBC_PERFORMANCE_LABELS } from "../../types"
import type { PortfolioEntry } from "../../types"
import Modal from "../../components/ui/Modal"
import EmptyState from "../../components/ui/EmptyState"
import FormField from "../../components/ui/FormField"
import Spinner from "../../components/ui/Spinner"
import CBCBadge from "../../components/ui/CBCBadge"

const blank = { student:"", title:"", description:"", subject:"", performance_level:"ME", term:"1", year:new Date().getFullYear(), date:new Date().toISOString().split("T")[0], teacher_remarks:"" }

export default function PortfolioPage() {
  const qc = useQueryClient()
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState<any>(blank)
  const [studentFilter, setStudentFilter] = useState("")

  const { data: entries, isLoading } = useQuery({ queryKey:["portfolio"], queryFn: () => portfolioAPI.getEntries().then(r=>r.data) })
  const { data: students } = useQuery({ queryKey:["students"], queryFn: () => studentAPI.getAll().then(r=>r.data) })

  const createMutation = useMutation({
    mutationFn: (f:any) => portfolioAPI.createEntry(f),
    onSuccess: () => { qc.invalidateQueries({queryKey:["portfolio"]}); toast.success("Portfolio entry added!"); setOpen(false); setForm(blank) },
    onError: (e:any) => toast.error(e?.response?.data?.detail || "Failed to add entry")
  })

  const deleteMutation = useMutation({
    mutationFn: (id:string) => portfolioAPI.updateEntry(id, {}),
    onSuccess: () => { qc.invalidateQueries({queryKey:["portfolio"]}); toast.success("Entry deleted") },
    onError: () => toast.error("Could not delete entry")
  })

  const field = (k:string, v:string) => setForm((f:any) => ({...f,[k]:v}))
  const filtered = entries?.results?.filter((e:PortfolioEntry) => !studentFilter || e.student === studentFilter)

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Portfolio</h1>
        <button className="btn-primary" onClick={()=>setOpen(true)}><Plus size={16}/>Add Entry</button>
      </div>

      <div className="flex gap-3 mb-4">
        <select className="input w-48" value={studentFilter} onChange={e=>setStudentFilter(e.target.value)}>
          <option value="">All Students</option>
          {students?.results?.map((s:any)=><option key={s.id} value={s.id}>{s.full_name}</option>)}
        </select>
        <span className="text-sm text-gray-500 self-center">{filtered?.length || 0} entries</span>
      </div>

      {isLoading ? <Spinner text="Loading portfolio..."/> : filtered?.length === 0 ? (
        <EmptyState icon={Folder} title="No portfolio entries" description="Start by adding your first student portfolio entry."
          action={<button className="btn-primary" onClick={()=>setOpen(true)}><Plus size={16}/>Add Entry</button>}/>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered?.map((e:PortfolioEntry) => (
            <div key={e.id} className="card p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Folder size={16} className="text-blue-500"/>
                  <p className="font-semibold text-sm">{e.title}</p>
                </div>
                <div className="flex items-center gap-1">
                  {e.performance_level && <CBCBadge level={e.performance_level as any}/>}
                  <button className="btn-ghost p-1 text-red-400 hover:text-red-600" onClick={()=>{if(confirm("Delete entry?")) deleteMutation.mutate(e.id)}}>
                    <Trash2 size={13}/>
                  </button>
                </div>
              </div>
              <p className="text-xs text-gray-500 mb-1">{e.student_name} · {e.subject} · Term {e.term}</p>
              <p className="text-sm text-gray-600 line-clamp-2">{e.description}</p>
              {e.teacher_remarks && <p className="text-xs text-gray-400 mt-2 italic">"{e.teacher_remarks}"</p>}
              <p className="text-xs text-gray-300 mt-2">{e.date}</p>
            </div>
          ))}
        </div>
      )}

      <Modal open={open} onClose={()=>setOpen(false)} title="New Portfolio Entry" size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField label="Student" required>
            <select className="input" value={form.student} onChange={e=>field("student",e.target.value)}>
              <option value="">Select student...</option>
              {students?.results?.map((s:any)=><option key={s.id} value={s.id}>{s.full_name} ({s.grade})</option>)}
            </select>
          </FormField>
          <FormField label="Title" required>
            <input className="input" value={form.title} onChange={e=>field("title",e.target.value)} placeholder="Entry title"/>
          </FormField>
          <FormField label="Subject / Strand">
            <input className="input" value={form.subject} onChange={e=>field("subject",e.target.value)}/>
          </FormField>
          <FormField label="CBC Performance Level">
            <select className="input" value={form.performance_level} onChange={e=>field("performance_level",e.target.value)}>
              {Object.entries(CBC_PERFORMANCE_LABELS).map(([k,v])=><option key={k} value={k}>{k} – {v}</option>)}
            </select>
          </FormField>
          <FormField label="Term">
            <select className="input" value={form.term} onChange={e=>field("term",e.target.value)}>
              {TERMS.map(t=><option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </FormField>
          <FormField label="Date">
            <input className="input" type="date" value={form.date} onChange={e=>field("date",e.target.value)}/>
          </FormField>
          <div className="col-span-2">
            <FormField label="Description / Evidence" required>
              <textarea className="input h-20 resize-none" value={form.description} onChange={e=>field("description",e.target.value)}/>
            </FormField>
          </div>
          <div className="col-span-2">
            <FormField label="Teacher Remarks">
              <textarea className="input h-16 resize-none" value={form.teacher_remarks} onChange={e=>field("teacher_remarks",e.target.value)}/>
            </FormField>
          </div>
        </div>
        <div className="flex gap-3 mt-4">
          <button className="btn-primary" onClick={()=>createMutation.mutate(form)} disabled={createMutation.isPending||!form.student||!form.title}>
            {createMutation.isPending?<Loader2 size={14} className="animate-spin"/>:null} Save Entry
          </button>
          <button className="btn-secondary" onClick={()=>setOpen(false)}>Cancel</button>
        </div>
      </Modal>
    </div>
  )
}
