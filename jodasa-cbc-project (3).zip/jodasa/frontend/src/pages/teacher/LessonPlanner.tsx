import { useState } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { lessonAPI } from "../../lib/api"
import { Plus, Loader2, BookOpen, Eye, Trash2, Globe, Archive } from "lucide-react"
import toast from "react-hot-toast"
import { GRADES, TERMS } from "../../types"
import type { Lesson } from "../../types"
import Modal from "../../components/ui/Modal"
import EmptyState from "../../components/ui/EmptyState"
import FormField from "../../components/ui/FormField"
import Spinner from "../../components/ui/Spinner"

const blank: Partial<Lesson> = { title:"", subject:"", grade:"G4", description:"", content:"", objectives:"", status:"draft", term:"1", year:new Date().getFullYear(), estimated_duration:40 }

export default function LessonPlanner() {
  const qc = useQueryClient()
  const [openForm, setOpenForm] = useState(false)
  const [viewLesson, setViewLesson] = useState<Lesson|null>(null)
  const [editing, setEditing] = useState<Lesson|null>(null)
  const [form, setForm] = useState<any>(blank)

  const { data, isLoading } = useQuery({ queryKey:["lessons"], queryFn: () => lessonAPI.getAll().then(r=>r.data) })

  const saveMutation = useMutation({
    mutationFn: (f:any) => editing ? lessonAPI.update(editing.id, f) : lessonAPI.create(f),
    onSuccess: () => { qc.invalidateQueries({queryKey:["lessons"]}); toast.success("Lesson saved!"); setOpenForm(false); setEditing(null); setForm(blank) },
    onError: (e:any) => toast.error(e?.response?.data?.title?.[0] || "Failed to save lesson")
  })

  const deleteMutation = useMutation({
    mutationFn: (id:string) => lessonAPI.delete(id),
    onSuccess: () => { qc.invalidateQueries({queryKey:["lessons"]}); toast.success("Lesson deleted") },
    onError: () => toast.error("Could not delete lesson")
  })

  const publishMutation = useMutation({
    mutationFn: ({id, status}:{id:string,status:string}) => lessonAPI.update(id, {status}),
    onSuccess: (_, {status}) => { qc.invalidateQueries({queryKey:["lessons"]}); toast.success(status==="published"?"Lesson published!":"Lesson unpublished") },
    onError: () => toast.error("Could not update status")
  })

  const field = (k:string, v:any) => setForm((f:any) => ({...f,[k]:v}))
  const openEdit = (l:Lesson) => { setEditing(l); setForm({...l}); setOpenForm(true); setViewLesson(null) }

  const statusBadge: Record<string,string> = { draft:"badge-gray", published:"badge-green", archived:"badge-red" }

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Lesson Planner</h1>
        <button className="btn-primary" onClick={()=>{setEditing(null);setForm(blank);setOpenForm(true)}}><Plus size={16}/>New Lesson</button>
      </div>

      {isLoading ? <Spinner text="Loading lessons..."/> : data?.results?.length === 0 ? (
        <EmptyState icon={BookOpen} title="No lessons yet" description="Create your first CBC lesson plan."
          action={<button className="btn-primary" onClick={()=>setOpenForm(true)}><Plus size={16}/>New Lesson</button>}/>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {data?.results?.map((l:Lesson) => (
            <div key={l.id} className="card p-4">
              <div className="flex items-start justify-between mb-2">
                <BookOpen size={16} className="text-indigo-500 mt-0.5"/>
                <span className={`badge ${statusBadge[l.status]}`}>{l.status}</span>
              </div>
              <p className="font-semibold mb-1">{l.title}</p>
              <p className="text-xs text-gray-500">{l.grade} · {l.subject} · Term {l.term} · {l.estimated_duration}min</p>
              <p className="text-sm text-gray-600 mt-2 line-clamp-2">{l.description||l.content?.substring(0,80)}</p>
              <div className="flex gap-1 mt-3 flex-wrap">
                <button className="btn-ghost py-1 px-2 text-xs" onClick={()=>setViewLesson(l)}><Eye size={12}/>View</button>
                <button className="btn-ghost py-1 px-2 text-xs" onClick={()=>openEdit(l)}>Edit</button>
                <button className="btn-ghost py-1 px-2 text-xs text-green-600"
                  onClick={()=>publishMutation.mutate({id:l.id, status: l.status==="published"?"draft":"published"})}>
                  {l.status==="published"?<><Archive size={12}/>Unpublish</>:<><Globe size={12}/>Publish</>}
                </button>
                <button className="btn-ghost py-1 px-2 text-xs text-red-500"
                  onClick={()=>{if(confirm("Delete lesson?")) deleteMutation.mutate(l.id)}}><Trash2 size={12}/></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* View Modal */}
      <Modal open={!!viewLesson} onClose={()=>setViewLesson(null)} title={viewLesson?.title||""} size="lg">
        {viewLesson && (
          <div>
            <div className="flex gap-2 mb-4">
              <span className="badge badge-blue">{viewLesson.grade}</span>
              <span className="badge badge-gray">{viewLesson.subject}</span>
              <span className={`badge ${statusBadge[viewLesson.status]}`}>{viewLesson.status}</span>
            </div>
            {viewLesson.objectives && (
              <div className="mb-4 p-3 bg-blue-50 rounded-lg">
                <p className="text-xs font-semibold text-blue-600 mb-1 uppercase">Objectives</p>
                <p className="text-sm text-blue-800">{viewLesson.objectives}</p>
              </div>
            )}
            <div className="text-sm text-gray-700 whitespace-pre-wrap leading-relaxed">{viewLesson.content}</div>
          </div>
        )}
      </Modal>

      {/* Create/Edit Modal */}
      <Modal open={openForm} onClose={()=>setOpenForm(false)} title={editing?"Edit Lesson":"New Lesson"} size="lg">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <div className="col-span-full">
            <FormField label="Title" required>
              <input className="input" value={form.title} onChange={e=>field("title",e.target.value)} placeholder="Lesson title"/>
            </FormField>
          </div>
          <FormField label="Subject"><input className="input" value={form.subject} onChange={e=>field("subject",e.target.value)}/></FormField>
          <FormField label="Grade">
            <select className="input" value={form.grade} onChange={e=>field("grade",e.target.value)}>
              {GRADES.map(g=><option key={g} value={g}>{g}</option>)}
            </select>
          </FormField>
          <FormField label="Status">
            <select className="input" value={form.status} onChange={e=>field("status",e.target.value)}>
              <option value="draft">Draft</option><option value="published">Published</option><option value="archived">Archived</option>
            </select>
          </FormField>
          <FormField label="Term">
            <select className="input" value={form.term} onChange={e=>field("term",e.target.value)}>
              {TERMS.map(t=><option key={t.value} value={t.value}>{t.label}</option>)}
            </select>
          </FormField>
          <FormField label="Year"><input className="input" type="number" value={form.year} onChange={e=>field("year",+e.target.value)}/></FormField>
          <FormField label="Duration (min)"><input className="input" type="number" value={form.estimated_duration} onChange={e=>field("estimated_duration",+e.target.value)}/></FormField>
          <div className="col-span-full">
            <FormField label="Learning Objectives">
              <textarea className="input h-16 resize-none" value={form.objectives} onChange={e=>field("objectives",e.target.value)} placeholder="By the end of this lesson students will..."/>
            </FormField>
          </div>
          <div className="col-span-full">
            <FormField label="Lesson Content" required>
              <textarea className="input h-32 resize-none" value={form.content} onChange={e=>field("content",e.target.value)} placeholder="Detailed lesson content, activities, examples..."/>
            </FormField>
          </div>
        </div>
        <div className="flex gap-3 mt-4">
          <button className="btn-primary" onClick={()=>saveMutation.mutate(form)} disabled={saveMutation.isPending||!form.title||!form.content}>
            {saveMutation.isPending?<Loader2 size={14} className="animate-spin"/>:null} Save Lesson
          </button>
          <button className="btn-secondary" onClick={()=>setOpenForm(false)}>Cancel</button>
        </div>
      </Modal>
    </div>
  )
}
