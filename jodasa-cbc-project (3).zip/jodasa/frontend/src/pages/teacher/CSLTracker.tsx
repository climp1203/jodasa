import { useState } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { portfolioAPI, studentAPI } from "../../lib/api"
import { Plus, Loader2, Leaf, Clock } from "lucide-react"
import toast from "react-hot-toast"
import { TERMS } from "../../types"
import type { CSLActivity } from "../../types"

const blank = { student:"", activity_name:"", description:"", location:"", hours_spent:1, date:new Date().toISOString().split("T")[0], impact:"", verified_by:"", term:"1", year:new Date().getFullYear() }

export default function CSLTracker() {
  const qc = useQueryClient()
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState<any>(blank)
  const [studentFilter, setStudentFilter] = useState("")

  const { data: activities, isLoading } = useQuery({ queryKey:["csl"], queryFn: () => portfolioAPI.getCSL().then(r=>r.data) })
  const { data: students } = useQuery({ queryKey:["students"], queryFn: () => studentAPI.getAll().then(r=>r.data) })

  const createMutation = useMutation({
    mutationFn: (f:any) => portfolioAPI.createCSL(f),
    onSuccess: () => { qc.invalidateQueries({queryKey:["csl"]}); toast.success("CSL activity logged!"); setShowForm(false); setForm(blank) }
  })

  const field = (k:string,v:any) => setForm((f:any)=>({...f,[k]:v}))
  const totalHours = activities?.results?.reduce((s:number,a:CSLActivity)=>s+Number(a.hours_spent),0)||0

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">CSL Tracker</h1>
        <button className="btn-primary" onClick={()=>setShowForm(true)}><Plus size={16}/>Log Activity</button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-6">
        <div className="stat-card"><p className="stat-value">{activities?.count||0}</p><p className="stat-label">Total Activities</p></div>
        <div className="stat-card"><p className="stat-value">{totalHours.toFixed(1)}</p><p className="stat-label">Total CSL Hours</p></div>
        <div className="stat-card"><p className="stat-value">{students?.count||0}</p><p className="stat-label">Students Tracked</p></div>
      </div>

      <div className="flex gap-3 mb-4">
        <select className="input w-48" value={studentFilter} onChange={e=>setStudentFilter(e.target.value)}>
          <option value="">All Students</option>
          {students?.results?.map((s:any)=><option key={s.id} value={s.id}>{s.full_name}</option>)}
        </select>
      </div>

      {showForm && (
        <div className="card p-6 mb-6">
          <h2 className="font-semibold mb-4">Log CSL Activity</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div><label className="label">Student</label>
              <select className="input" value={form.student} onChange={e=>field("student",e.target.value)}>
                <option value="">Select student...</option>
                {students?.results?.map((s:any)=><option key={s.id} value={s.id}>{s.full_name}</option>)}
              </select></div>
            <div><label className="label">Activity Name</label>
              <input className="input" value={form.activity_name} onChange={e=>field("activity_name",e.target.value)} placeholder="e.g. Tree Planting Drive"/></div>
            <div><label className="label">Location</label>
              <input className="input" value={form.location} onChange={e=>field("location",e.target.value)}/></div>
            <div><label className="label">Hours Spent</label>
              <input className="input" type="number" step="0.5" value={form.hours_spent} onChange={e=>field("hours_spent",e.target.value)}/></div>
            <div><label className="label">Date</label>
              <input className="input" type="date" value={form.date} onChange={e=>field("date",e.target.value)}/></div>
            <div><label className="label">Verified By</label>
              <input className="input" value={form.verified_by} onChange={e=>field("verified_by",e.target.value)} placeholder="Community leader / teacher"/></div>
            <div className="col-span-2"><label className="label">Description</label>
              <textarea className="input h-16 resize-none" value={form.description} onChange={e=>field("description",e.target.value)}/></div>
            <div className="col-span-2"><label className="label">Community Impact / Reflection</label>
              <textarea className="input h-16 resize-none" value={form.impact} onChange={e=>field("impact",e.target.value)}/></div>
          </div>
          <div className="flex gap-3 mt-4">
            <button className="btn-primary" onClick={()=>createMutation.mutate(form)} disabled={createMutation.isPending}>
              {createMutation.isPending?<Loader2 size={14} className="animate-spin"/>:null} Log Activity
            </button>
            <button className="btn-secondary" onClick={()=>setShowForm(false)}>Cancel</button>
          </div>
        </div>
      )}

      {isLoading ? <div className="p-8 text-center"><Loader2 className="animate-spin mx-auto text-gray-400"/></div> : (
        <div className="space-y-3">
          {activities?.results?.filter((a:CSLActivity)=>!studentFilter||a.student===studentFilter).map((a:CSLActivity) => (
            <div key={a.id} className="card p-4 flex items-start gap-4">
              <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center flex-shrink-0">
                <Leaf size={20} className="text-green-700"/>
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className="font-semibold">{a.activity_name}</p>
                  <div className="flex items-center gap-1 text-sm text-green-700 font-medium">
                    <Clock size={13}/>{a.hours_spent}h
                  </div>
                </div>
                <p className="text-xs text-gray-500">{a.student_name} · {a.location||"School"} · {a.date}</p>
                <p className="text-sm text-gray-600 mt-1 line-clamp-2">{a.description}</p>
                {a.impact && <p className="text-xs text-green-600 mt-1">Impact: {a.impact}</p>}
                {a.verified_by && <p className="text-xs text-gray-400 mt-0.5">Verified by: {a.verified_by}</p>}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
