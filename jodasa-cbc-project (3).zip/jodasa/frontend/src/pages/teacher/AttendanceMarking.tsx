import { useState, useEffect, useRef } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { attendanceAPI, studentAPI } from "../../lib/api"
import { QrCode, Users, CheckCircle, XCircle, Clock, Loader2, Camera, CameraOff } from "lucide-react"
import toast from "react-hot-toast"
import { GRADES, STREAMS } from "../../types"
import { Html5QrcodeScanner } from "html5-qrcode"

export default function AttendanceMarking() {
  const qc = useQueryClient()
  const [mode, setMode] = useState<"qr"|"manual">("manual")
  const [scannerActive, setScannerActive] = useState(false)
  const [sessionForm, setSessionForm] = useState({ grade:"G1", stream:"A", subject:"Mathematics", date: new Date().toISOString().split("T")[0] })
  const [activeSession, setActiveSession] = useState<any>(null)
  const [manualRecords, setManualRecords] = useState<Record<string,string>>({})
  const scannerRef = useRef<Html5QrcodeScanner|null>(null)

  const { data: students } = useQuery({
    queryKey:["students", sessionForm.grade, sessionForm.stream],
    queryFn: () => studentAPI.getAll({ grade: sessionForm.grade, stream: sessionForm.stream }).then(r=>r.data),
    enabled: !!sessionForm.grade
  })

  const createSession = useMutation({
    mutationFn: (f:any) => attendanceAPI.createSession(f),
    onSuccess: (r) => { setActiveSession(r.data); toast.success("Session started!"); initManualRecords() }
  })

  const qrScanMutation = useMutation({
    mutationFn: (studentId:string) => attendanceAPI.qrScan(activeSession.id, { student_id: studentId, session_id: activeSession.id }),
    onSuccess: (r) => toast.success(`✓ ${r.data.student} marked present`),
    onError: () => toast.error("Student not found in this session")
  })

  const bulkMarkMutation = useMutation({
    mutationFn: () => attendanceAPI.bulkMark(activeSession.id, {
      records: Object.entries(manualRecords).map(([student_id, status]) => ({ student_id, status }))
    }),
    onSuccess: () => { toast.success("Attendance saved!"); qc.invalidateQueries({queryKey:["sessions"]}) }
  })

  const initManualRecords = () => {
    const records: Record<string,string> = {}
    students?.results?.forEach((s:any) => { records[s.id] = "present" })
    setManualRecords(records)
  }

  useEffect(() => {
    if (students?.results && activeSession) initManualRecords()
  }, [students, activeSession])

  useEffect(() => {
    if (mode === "qr" && activeSession && scannerActive) {
      setTimeout(() => {
        const scanner = new Html5QrcodeScanner("qr-reader", { fps: 10, qrbox: { width: 250, height: 250 } }, false)
        scanner.render(
          (decodedText) => { qrScanMutation.mutate(decodedText) },
          (err) => {}
        )
        scannerRef.current = scanner
      }, 300)
    }
    return () => { if (scannerRef.current) { scannerRef.current.clear().catch(()=>{}) } }
  }, [mode, activeSession, scannerActive])

  const statusColors: Record<string,string> = {
    present: "bg-green-100 border-green-300 text-green-700",
    absent: "bg-red-100 border-red-300 text-red-700",
    late: "bg-yellow-100 border-yellow-300 text-yellow-700",
    excused: "bg-blue-100 border-blue-300 text-blue-700",
  }

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Attendance Marking</h1>
        <div className="flex gap-2">
          <button onClick={()=>setMode("manual")} className={`btn ${mode==="manual"?"btn-primary":"btn-secondary"}`}><Users size={15}/>Manual</button>
          <button onClick={()=>setMode("qr")} className={`btn ${mode==="qr"?"btn-primary":"btn-secondary"}`}><QrCode size={15}/>QR Scan</button>
        </div>
      </div>

      {/* Session setup */}
      {!activeSession && (
        <div className="card p-6 max-w-lg mb-6">
          <h2 className="font-semibold mb-4">Start Attendance Session</h2>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="label">Grade</label>
              <select className="input" value={sessionForm.grade} onChange={e=>setSessionForm(f=>({...f,grade:e.target.value}))}>
                {GRADES.map(g=><option key={g} value={g}>{g}</option>)}
              </select></div>
            <div><label className="label">Stream</label>
              <select className="input" value={sessionForm.stream} onChange={e=>setSessionForm(f=>({...f,stream:e.target.value}))}>
                {STREAMS.map(s=><option key={s} value={s}>{s}</option>)}
              </select></div>
            <div><label className="label">Subject</label>
              <input className="input" value={sessionForm.subject} onChange={e=>setSessionForm(f=>({...f,subject:e.target.value}))}/></div>
            <div><label className="label">Date</label>
              <input className="input" type="date" value={sessionForm.date} onChange={e=>setSessionForm(f=>({...f,date:e.target.value}))}/></div>
          </div>
          <button className="btn-primary mt-4" onClick={()=>createSession.mutate(sessionForm)} disabled={createSession.isPending}>
            {createSession.isPending?<Loader2 size={14} className="animate-spin"/>:null} Start Session
          </button>
        </div>
      )}

      {activeSession && (
        <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-3">
          <CheckCircle size={18} className="text-green-600"/>
          <span className="text-sm text-green-800 font-medium">
            Session active: Grade {activeSession.grade}{activeSession.stream} · {activeSession.subject} · {activeSession.date}
          </span>
        </div>
      )}

      {/* QR Mode */}
      {mode === "qr" && activeSession && (
        <div className="card p-6 max-w-md">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">QR Scanner</h2>
            <button onClick={()=>setScannerActive(!scannerActive)}
              className={scannerActive?"btn-danger":"btn-primary"}>
              {scannerActive?<CameraOff size={15}/>:<Camera size={15}/>}
              {scannerActive?"Stop":"Start Camera"}
            </button>
          </div>
          {scannerActive && <div id="qr-reader" className="w-full rounded-xl overflow-hidden"/>}
          {!scannerActive && (
            <div className="w-full h-48 bg-gray-100 rounded-xl flex items-center justify-center text-gray-400">
              <div className="text-center"><QrCode size={48} className="mx-auto mb-2 opacity-30"/><p className="text-sm">Press Start Camera to scan QR codes</p></div>
            </div>
          )}
        </div>
      )}

      {/* Manual Mode */}
      {mode === "manual" && activeSession && students?.results?.length > 0 && (
        <div className="card overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-100 flex items-center justify-between">
            <p className="font-semibold">{students.results.length} Students — Grade {sessionForm.grade}{sessionForm.stream}</p>
            <div className="flex gap-2 text-sm">
              <span className="text-green-600">{Object.values(manualRecords).filter(v=>v==="present").length} present</span>
              <span className="text-red-500">{Object.values(manualRecords).filter(v=>v==="absent").length} absent</span>
            </div>
          </div>
          <div className="divide-y divide-gray-100">
            {students.results.map((s: any) => (
              <div key={s.id} className="flex items-center justify-between px-4 py-3">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 text-xs font-bold">
                    {s.first_name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{s.full_name}</p>
                    <p className="text-xs text-gray-400">{s.admission_number}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  {["present","absent","late","excused"].map(status => (
                    <button key={status} onClick={()=>setManualRecords(r=>({...r,[s.id]:status}))}
                      className={`text-xs px-2.5 py-1 rounded-full border font-medium capitalize transition-colors ${manualRecords[s.id]===status ? statusColors[status] : "bg-white border-gray-200 text-gray-400 hover:border-gray-300"}`}>
                      {status}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>
          <div className="px-4 py-3 border-t border-gray-100">
            <button className="btn-primary" onClick={()=>bulkMarkMutation.mutate()} disabled={bulkMarkMutation.isPending}>
              {bulkMarkMutation.isPending?<Loader2 size={14} className="animate-spin"/>:<CheckCircle size={14}/>} Save Attendance
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
