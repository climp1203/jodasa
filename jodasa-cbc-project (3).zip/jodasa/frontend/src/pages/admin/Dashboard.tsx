import { useQuery } from "@tanstack/react-query"
import { studentAPI, attendanceAPI, feesAPI } from "../../lib/api"
import { GraduationCap, CreditCard, QrCode, Megaphone, TrendingUp, Users } from "lucide-react"
import { Link } from "react-router-dom"

export default function AdminDashboard() {
  const { data: students } = useQuery({ queryKey:["students"], queryFn: () => studentAPI.getAll().then(r=>r.data) })
  const { data: payments } = useQuery({ queryKey:["payments"], queryFn: () => feesAPI.getPayments().then(r=>r.data) })

  const totalRevenue = payments?.results?.filter((p:any)=>p.status==="completed").reduce((s:number,p:any)=>s+Number(p.amount),0) || 0

  const quickLinks = [
    {to:"/admin/students", icon:GraduationCap, label:"Manage Students", desc:"Add, edit, view all students", color:"blue"},
    {to:"/admin/fees", icon:CreditCard, label:"Fee Management", desc:"Structures, payments, M-Pesa", color:"green"},
    {to:"/admin/notifications", icon:Megaphone, label:"Notifications", desc:"Bulk SMS & email to parents", color:"purple"},
    {to:"/teacher/attendance", icon:QrCode, label:"Attendance", desc:"QR code attendance marking", color:"orange"},
  ]

  const colorMap: Record<string,string> = {
    blue:"bg-blue-100 text-blue-700", green:"bg-green-100 text-green-700",
    purple:"bg-purple-100 text-purple-700", orange:"bg-orange-100 text-orange-700"
  }

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">School Dashboard</h1>
        <span className="badge badge-blue">School Admin</span>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {[
          {label:"Total Students", value:students?.count??0, icon:GraduationCap, color:"blue"},
          {label:"Active Students", value:students?.results?.filter((s:any)=>s.is_active).length??0, icon:Users, color:"green"},
          {label:"Revenue (KES)", value:`${totalRevenue.toLocaleString()}`, icon:CreditCard, color:"purple"},
          {label:"Fee Collection", value:`${payments?.results?.filter((p:any)=>p.status==="completed").length??0} payments`, icon:TrendingUp, color:"orange"},
        ].map(s => (
          <div key={s.label} className="stat-card">
            <div className={`w-10 h-10 rounded-xl ${colorMap[s.color]} flex items-center justify-center mb-2`}>
              <s.icon size={20}/>
            </div>
            <p className="stat-value text-2xl">{s.value}</p>
            <p className="stat-label">{s.label}</p>
          </div>
        ))}
      </div>

      {/* Quick links */}
      <h2 className="font-semibold text-gray-700 mb-3">Quick Actions</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {quickLinks.map(q => (
          <Link key={q.to} to={q.to}
            className="card p-5 hover:shadow-md transition-shadow group cursor-pointer">
            <div className={`w-11 h-11 rounded-xl ${colorMap[q.color]} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
              <q.icon size={22}/>
            </div>
            <p className="font-semibold text-gray-900">{q.label}</p>
            <p className="text-sm text-gray-500 mt-0.5">{q.desc}</p>
          </Link>
        ))}
      </div>

      {/* Recent payments */}
      <div className="card p-6 mt-6">
        <h2 className="font-semibold text-gray-900 mb-4">Recent Payments</h2>
        <div className="overflow-x-auto">
          <table className="table-auto w-full">
            <thead><tr><th>Student</th><th>Amount (KES)</th><th>Method</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
              {payments?.results?.slice(0,8).map((p:any) => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="font-medium">{p.student_name}</td>
                  <td>KES {Number(p.amount).toLocaleString()}</td>
                  <td><span className="badge badge-gray capitalize">{p.method}</span></td>
                  <td><span className={p.status==="completed"?"badge-green badge":p.status==="pending"?"badge-yellow badge":"badge-red badge"}>{p.status}</span></td>
                  <td className="text-gray-400 text-xs">{new Date(p.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
