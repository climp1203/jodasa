import { useState, useRef } from "react"
import { useQuery } from "@tanstack/react-query"
import { studentAPI } from "../../lib/api"
import { QrCode, Printer, Download } from "lucide-react"
import { GRADES, STREAMS } from "../../types"
import type { Student } from "../../types"
import Spinner from "../../components/ui/Spinner"

export default function BulkQR() {
  const [grade, setGrade] = useState("G1")
  const [stream, setStream] = useState("")
  const printRef = useRef<HTMLDivElement>(null)

  const { data, isLoading } = useQuery({
    queryKey: ["students-qr", grade, stream],
    queryFn: () => studentAPI.getAll({ grade, stream: stream||undefined, page_size: 100 }).then(r=>r.data)
  })

  const handlePrint = () => {
    const content = printRef.current?.innerHTML
    if (!content) return
    const win = window.open("", "_blank")
    if (!win) return
    win.document.write(`
      <html><head><title>QR Codes - Grade ${grade}${stream}</title>
      <style>
        body { margin: 0; padding: 10px; font-family: Arial, sans-serif; }
        .grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; }
        .card { border: 1px solid #ddd; padding: 10px; text-align: center; border-radius: 8px; page-break-inside: avoid; }
        .card img { width: 100px; height: 100px; }
        .name { font-size: 11px; font-weight: bold; margin-top: 4px; }
        .adm { font-size: 10px; color: #666; }
        @media print { .card { border: 1px solid #999; } }
      </style></head>
      <body><div class="grid">${content}</div></body></html>
    `)
    win.document.close()
    win.print()
  }

  const students: Student[] = data?.results || []

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Bulk QR Codes</h1>
        <button className="btn-primary" onClick={handlePrint} disabled={students.length===0}>
          <Printer size={16}/>Print QR Sheets
        </button>
      </div>

      <div className="flex gap-3 mb-6">
        <div>
          <label className="label">Grade</label>
          <select className="input w-32" value={grade} onChange={e=>setGrade(e.target.value)}>
            {GRADES.map(g=><option key={g} value={g}>{g}</option>)}
          </select>
        </div>
        <div>
          <label className="label">Stream</label>
          <select className="input w-24" value={stream} onChange={e=>setStream(e.target.value)}>
            <option value="">All</option>
            {STREAMS.map(s=><option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      {isLoading ? <Spinner text="Loading students..."/> : (
        <>
          <p className="text-sm text-gray-500 mb-4">{students.length} students · Grade {grade}{stream}</p>
          <div ref={printRef} className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
            {students.map((s: Student) => (
              <div key={s.id} className="card p-3 text-center">
                {s.qr_code
                  ? <img src={s.qr_code} alt={`QR ${s.admission_number}`} className="w-24 h-24 mx-auto rounded-lg"/>
                  : <div className="w-24 h-24 mx-auto bg-gray-100 rounded-lg flex items-center justify-center"><QrCode size={32} className="text-gray-300"/></div>
                }
                <p className="text-xs font-bold mt-2 truncate">{s.full_name}</p>
                <p className="text-xs text-gray-400">{s.admission_number}</p>
                <span className="badge badge-blue mt-1">{s.grade}{s.stream}</span>
              </div>
            ))}
          </div>
          {students.length === 0 && (
            <div className="card p-12 text-center text-gray-400">
              <QrCode size={48} className="mx-auto mb-3 opacity-30"/>
              <p>No students found for the selected grade.</p>
            </div>
          )}
        </>
      )}
    </div>
  )
}
