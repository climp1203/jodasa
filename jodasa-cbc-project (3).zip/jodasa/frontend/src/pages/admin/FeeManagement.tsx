import { useState } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { feesAPI, studentAPI } from "../../lib/api"
import { Plus, Loader2, Smartphone, CheckCircle } from "lucide-react"
import toast from "react-hot-toast"
import { GRADES, TERMS } from "../../types"

export default function AdminFeeManagement() {
  const qc = useQueryClient()
  const [tab, setTab] = useState<"structures"|"payments"|"mpesa">("structures")
  const [showForm, setShowForm] = useState(false)
  const [structureForm, setStructureForm] = useState<any>({ name:"", grade:"", term:"1", year:2024, tuition:0, boarding:0, activity:0, exam:0, other:0 })
  const [mpesaForm, setMpesaForm] = useState<any>({ student_id:"", phone:"", amount:"", term:"1", year:2024 })

  const { data: structures } = useQuery({ queryKey:["fee-structures"], queryFn: () => feesAPI.getStructures().then(r=>r.data) })
  const { data: payments } = useQuery({ queryKey:["payments"], queryFn: () => feesAPI.getPayments().then(r=>r.data) })
  const { data: students } = useQuery({ queryKey:["students"], queryFn: () => studentAPI.getAll().then(r=>r.data) })

  const createStructure = useMutation({
    mutationFn: (f:any) => feesAPI.createStructure(f),
    onSuccess: () => { qc.invalidateQueries({queryKey:["fee-structures"]}); toast.success("Fee structure created!"); setShowForm(false) }
  })

  const mpesaMutation = useMutation({
    mutationFn: (f:any) => feesAPI.mpesaSTK(f),
    onSuccess: () => toast.success("STK push sent! Ask parent to enter M-Pesa PIN."),
    onError: (e:any) => toast.error(e?.response?.data?.detail || "M-Pesa error")
  })

  const sf = (k:string,v:any) => setStructureForm((f:any)=>({...f,[k]:v}))
  const mf = (k:string,v:any) => setMpesaForm((f:any)=>({...f,[k]:v}))

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Fee Management</h1>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-gray-100 rounded-lg w-fit mb-6">
        {[["structures","Fee Structures"],["payments","Payments"],["mpesa","M-Pesa STK"]].map(([k,l]) => (
          <button key={k} onClick={()=>setTab(k as any)}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${tab===k?"bg-white shadow text-gray-900":"text-gray-500 hover:text-gray-700"}`}>
            {l}
          </button>
        ))}
      </div>

      {tab==="structures" && (
        <div>
          <div className="flex justify-end mb-4">
            <button className="btn-primary" onClick={()=>setShowForm(true)}><Plus size={16}/>New Structure</button>
          </div>
          {showForm && (
            <div className="card p-6 mb-4">
              <h3 className="font-semibold mb-4">New Fee Structure</h3>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="col-span-2"><label className="label">Structure Name</label>
                  <input className="input" value={structureForm.name} onChange={e=>sf("name",e.target.value)} placeholder="e.g. Grade 1 Term 1 2024"/></div>
                <div><label className="label">Grade</label>
                  <select className="input" value={structureForm.grade} onChange={e=>sf("grade",e.target.value)}>
                    <option value="">All</option>{GRADES.map(g=><option key={g} value={g}>{g}</option>)}
                  </select></div>
                <div><label className="label">Term</label>
                  <select className="input" value={structureForm.term} onChange={e=>sf("term",e.target.value)}>
                    {TERMS.map(t=><option key={t.value} value={t.value}>{t.label}</option>)}
                  </select></div>
                {[["tuition","Tuition"],["boarding","Boarding"],["activity","Activity"],["exam","Exam"],["other","Other"]].map(([k,l]) => (
                  <div key={k}><label className="label">{l} (KES)</label>
                    <input className="input" type="number" value={structureForm[k]} onChange={e=>sf(k,e.target.value)}/></div>
                ))}
                <div><label className="label">Year</label>
                  <input className="input" type="number" value={structureForm.year} onChange={e=>sf("year",e.target.value)}/></div>
              </div>
              <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-700 font-medium">
                  Total: KES {(+structureForm.tuition + +structureForm.boarding + +structureForm.activity + +structureForm.exam + +structureForm.other).toLocaleString()}
                </p>
              </div>
              <div className="flex gap-3 mt-4">
                <button className="btn-primary" onClick={()=>createStructure.mutate(structureForm)} disabled={createStructure.isPending}>
                  {createStructure.isPending?<Loader2 size={14} className="animate-spin"/>:null} Save Structure
                </button>
                <button className="btn-secondary" onClick={()=>setShowForm(false)}>Cancel</button>
              </div>
            </div>
          )}
          <div className="card overflow-hidden">
            <table className="table-auto w-full">
              <thead><tr><th>Name</th><th>Grade</th><th>Term</th><th>Tuition</th><th>Boarding</th><th>Total</th></tr></thead>
              <tbody>
                {structures?.results?.map((s:any) => (
                  <tr key={s.id} className="hover:bg-gray-50">
                    <td className="font-medium">{s.name}</td>
                    <td>{s.grade||"All"}</td>
                    <td>Term {s.term}</td>
                    <td>KES {Number(s.tuition).toLocaleString()}</td>
                    <td>KES {Number(s.boarding).toLocaleString()}</td>
                    <td className="font-semibold text-green-700">KES {Number(s.total).toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab==="payments" && (
        <div className="card overflow-hidden">
          <table className="table-auto w-full">
            <thead><tr><th>Student</th><th>Amount</th><th>Method</th><th>Receipt</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
              {payments?.results?.map((p:any) => (
                <tr key={p.id} className="hover:bg-gray-50">
                  <td className="font-medium">{p.student_name}</td>
                  <td>KES {Number(p.amount).toLocaleString()}</td>
                  <td><span className="badge badge-gray capitalize">{p.method}</span></td>
                  <td className="font-mono text-xs">{p.mpesa_receipt||"—"}</td>
                  <td><span className={p.status==="completed"?"badge-green badge":p.status==="pending"?"badge-yellow badge":"badge-red badge"}>{p.status}</span></td>
                  <td className="text-xs text-gray-400">{new Date(p.created_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {tab==="mpesa" && (
        <div className="max-w-lg">
          <div className="card p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-green-100 flex items-center justify-center">
                <Smartphone size={20} className="text-green-700"/>
              </div>
              <div>
                <h2 className="font-semibold">M-Pesa STK Push</h2>
                <p className="text-sm text-gray-500">Send payment prompt to parent phone</p>
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <label className="label">Student</label>
                <select className="input" value={mpesaForm.student_id} onChange={e=>mf("student_id",e.target.value)}>
                  <option value="">Select student...</option>
                  {students?.results?.map((s:any) => <option key={s.id} value={s.id}>{s.full_name} ({s.admission_number})</option>)}
                </select>
              </div>
              <div>
                <label className="label">Parent Phone (07XXXXXXXX)</label>
                <input className="input" value={mpesaForm.phone} onChange={e=>mf("phone",e.target.value)} placeholder="0712345678"/>
              </div>
              <div>
                <label className="label">Amount (KES)</label>
                <input className="input" type="number" value={mpesaForm.amount} onChange={e=>mf("amount",e.target.value)} placeholder="5000"/>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="label">Term</label>
                  <select className="input" value={mpesaForm.term} onChange={e=>mf("term",e.target.value)}>
                    {TERMS.map(t=><option key={t.value} value={t.value}>{t.label}</option>)}
                  </select></div>
                <div><label className="label">Year</label>
                  <input className="input" type="number" value={mpesaForm.year} onChange={e=>mf("year",e.target.value)}/></div>
              </div>
              <button className="btn-success w-full justify-center py-3" onClick={()=>mpesaMutation.mutate(mpesaForm)} disabled={mpesaMutation.isPending}>
                {mpesaMutation.isPending ? <Loader2 size={16} className="animate-spin"/> : <Smartphone size={16}/>}
                Send STK Push
              </button>
              {mpesaMutation.isSuccess && (
                <div className="flex items-center gap-2 text-green-700 bg-green-50 rounded-lg p-3">
                  <CheckCircle size={16}/><span className="text-sm">STK push sent! Parent should see M-Pesa prompt.</span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
