import { useState } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { userAPI } from "../../lib/api"
import { Plus, Edit2, Trash2, Loader2 } from "lucide-react"
import toast from "react-hot-toast"
import Modal from "../../components/ui/Modal"
import FormField from "../../components/ui/FormField"
import DataTable from "../../components/ui/DataTable"
import EmptyState from "../../components/ui/EmptyState"
import { Users } from "lucide-react"
import type { User } from "../../types"

const blank = { username:"", email:"", first_name:"", last_name:"", role:"teacher", phone:"", password:"" }

export default function UserManagement() {
  const qc = useQueryClient()
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<User|null>(null)
  const [form, setForm] = useState<any>(blank)
  const [roleFilter, setRoleFilter] = useState("")

  const { data, isLoading } = useQuery({ queryKey:["users"], queryFn: () => userAPI.getAll().then(r=>r.data) })

  const saveMutation = useMutation({
    mutationFn: (f:any) => editing ? userAPI.update(editing.id, f) : userAPI.create(f),
    onSuccess: () => { qc.invalidateQueries({queryKey:["users"]}); toast.success("User saved!"); setOpen(false); setForm(blank); setEditing(null) },
    onError: (e:any) => toast.error(e?.response?.data?.username?.[0] || e?.response?.data?.email?.[0] || "Error saving user")
  })

  const deleteMutation = useMutation({
    mutationFn: (id:string) => userAPI.delete(id),
    onSuccess: () => { qc.invalidateQueries({queryKey:["users"]}); toast.success("User deleted") },
    onError: () => toast.error("Could not delete user")
  })

  const field = (k:string, v:string) => setForm((f:any) => ({...f,[k]:v}))
  const openEdit = (u: User) => { setEditing(u); setForm({...u, password:""}); setOpen(true) }
  const openNew = () => { setEditing(null); setForm(blank); setOpen(true) }

  const roleColors: Record<string,string> = {
    superadmin:"badge-red badge", school_admin:"badge-blue badge",
    teacher:"badge-green badge", parent:"badge-yellow badge", student:"badge-gray badge"
  }

  const users = data?.results?.filter((u:User) => !roleFilter || u.role === roleFilter) || []

  const columns = [
    { key:"full_name", label:"Name", render:(u:User) => <span className="font-medium">{u.full_name}</span> },
    { key:"email", label:"Email", render:(u:User) => <span className="text-gray-500">{u.email}</span> },
    { key:"phone", label:"Phone", render:(u:User) => <span>{u.phone||"—"}</span> },
    { key:"role", label:"Role", render:(u:User) => <span className={roleColors[u.role]||"badge-gray badge"} style={{textTransform:"capitalize"}}>{u.role.replace("_"," ")}</span> },
    { key:"is_active", label:"Status", render:(u:User) => <span className={u.is_active?"badge-green badge":"badge-red badge"}>{u.is_active?"Active":"Inactive"}</span> },
    { key:"actions", label:"", render:(u:User) => (
      <div className="flex gap-1">
        <button className="btn-ghost p-1" onClick={()=>openEdit(u)}><Edit2 size={14}/></button>
        <button className="btn-ghost p-1 text-red-500" onClick={()=>{if(confirm("Delete user?")) deleteMutation.mutate(u.id)}}><Trash2 size={14}/></button>
      </div>
    )}
  ]

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">User Management</h1>
        <button className="btn-primary" onClick={openNew}><Plus size={16}/>Add User</button>
      </div>

      <div className="flex gap-3 mb-4">
        <select className="input w-40" value={roleFilter} onChange={e=>setRoleFilter(e.target.value)}>
          <option value="">All Roles</option>
          {["school_admin","teacher","parent","student"].map(r=><option key={r} value={r}>{r.replace("_"," ")}</option>)}
        </select>
        <span className="text-sm text-gray-500 self-center">{users.length} users</span>
      </div>

      <div className="card overflow-hidden">
        {isLoading ? <div className="p-8 text-center"><Loader2 className="animate-spin mx-auto text-gray-400"/></div>
          : users.length === 0
          ? <EmptyState icon={Users} title="No users found" description="Add your first user to get started."/>
          : <DataTable columns={columns} data={users} rowKey={u=>u.id}/>
        }
      </div>

      <Modal open={open} onClose={()=>setOpen(false)} title={editing?"Edit User":"New User"}>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <FormField label="First Name" required>
            <input className="input" value={form.first_name} onChange={e=>field("first_name",e.target.value)} placeholder="First name"/>
          </FormField>
          <FormField label="Last Name" required>
            <input className="input" value={form.last_name} onChange={e=>field("last_name",e.target.value)} placeholder="Last name"/>
          </FormField>
          <FormField label="Username" required>
            <input className="input" value={form.username} onChange={e=>field("username",e.target.value)} placeholder="username"/>
          </FormField>
          <FormField label="Email">
            <input className="input" type="email" value={form.email} onChange={e=>field("email",e.target.value)} placeholder="email@school.ke"/>
          </FormField>
          <FormField label="Phone">
            <input className="input" value={form.phone} onChange={e=>field("phone",e.target.value)} placeholder="07XXXXXXXX"/>
          </FormField>
          <FormField label="Role" required>
            <select className="input" value={form.role} onChange={e=>field("role",e.target.value)}>
              {["school_admin","teacher","parent","student"].map(r=><option key={r} value={r}>{r.replace("_"," ")}</option>)}
            </select>
          </FormField>
          {!editing && (
            <FormField label="Password" required hint="Minimum 8 characters">
              <input className="input" type="password" value={form.password} onChange={e=>field("password",e.target.value)} placeholder="Password"/>
            </FormField>
          )}
        </div>
        <div className="flex gap-3 mt-6">
          <button className="btn-primary" onClick={()=>saveMutation.mutate(form)} disabled={saveMutation.isPending}>
            {saveMutation.isPending?<Loader2 size={14} className="animate-spin"/>:null} Save User
          </button>
          <button className="btn-secondary" onClick={()=>setOpen(false)}>Cancel</button>
        </div>
      </Modal>
    </div>
  )
}
