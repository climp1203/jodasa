import { useState } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { studentAPI } from "../../lib/api"
import { Plus, Edit2, Trash2, Loader2, QrCode, GraduationCap } from "lucide-react"
import toast from "react-hot-toast"
import type { Student } from "../../types"
import { GRADES, STREAMS } from "../../types"
import { SearchInput, ConfirmDialog, Spinner } from "../../components/ui"

const blank: Partial<Student> = {
  admission_number:"", first_name:"", last_name:"", grade:"G1", stream:"A",
  gender:"M", parent_name:"", parent_phone:"", parent_email:""
}

export default function AdminStudents() {
  const qc = useQueryClient()
  const [showForm, setShowForm] = useState(false)
  const [editing, setEditing] = useState<Student|null>(null)
  const [form, setForm] = useState<any>(blank)
  const [search, setSearch] = useState("")
  const [gradeFilter, setGradeFilter] = useState("")
  const [deleteTarget, setDeleteTarget] = useState<Student|null>(null)

  const { data, isLoading } = useQuery({
    queryKey: ["students", search, gradeFilter],
    queryFn: () => studentAPI.getAll({ search, grade: gradeFilter||undefined }).then(r=>r.data)
  })

  const saveMutation = useMutation({
    mutationFn: (f: any) => editing ? studentAPI.update(editing.id, f) : studentAPI.create(f),
    onSuccess: () => { qc.invalidateQueries({queryKey:["students"]}); toast.success("Student saved!"); resetForm() },
    onError: (e:any) => toast.error(e?.response?.data?.admission_number?.[0] || "Error saving student")
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string) => studentAPI.delete(id),
    onSuccess: () => { qc.invalidateQueries({queryKey:["students"]}); toast.success("Student deleted") }
  })

  const resetForm = () => { setShowForm(false); setEditing(null); setForm(blank) }
  const openEdit = (s: Student) => { setEditing(s); setForm({...s}); setShowForm(true) }
  const field = (k: string, v: string) => setForm((f:any) => ({...f,[k]:v}))

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Students</h1>
        <button className="btn-primary" onClick={() => { resetForm(); setShowForm(true) }}>
          <Plus size={16}/>Add Student
        </button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 mb-4">
        <SearchInput value={search} onChange={setSearch} placeholder="Search by name or admission no..." className="flex-1 min-w-48"/>
        <select className="input w-36" value={gradeFilter} onChange={e=>setGradeFilter(e.target.value)}>
          <option value="">All Grades</option>
          {GRADES.map(g => <option key={g} value={g}>{g}</option>)}
        </select>
      </div>

      {/* Form */}
      {showForm && (
        <div className="card p-6 mb-6">
          <h2 className="font-semibold mb-4">{editing?"Edit Student":"New Student"}</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[["admission_number","Admission No."],["first_name","First Name"],["last_name","Last Name"],
              ["parent_name","Parent Name"],["parent_phone","Parent Phone"],["parent_email","Parent Email"]
            ].map(([k,l]) => (
              <div key={k}>
                <label className="label">{l}</label>
                <input className="input" value={form[k]||""} onChange={e=>field(k,e.target.value)} placeholder={l as string}/>
              </div>
            ))}
            <div><label className="label">Grade</label>
              <select className="input" value={form.grade} onChange={e=>field("grade",e.target.value)}>
                {GRADES.map(g=><option key={g} value={g}>{g}</option>)}
              </select></div>
            <div><label className="label">Stream</label>
              <select className="input" value={form.stream||"A"} onChange={e=>field("stream",e.target.value)}>
                {STREAMS.map(s=><option key={s} value={s}>{s}</option>)}
              </select></div>
            <div><label className="label">Gender</label>
              <select className="input" value={form.gender||"M"} onChange={e=>field("gender",e.target.value)}>
                <option value="M">Male</option><option value="F">Female</option>
              </select></div>
            <div><label className="label">Date of Birth</label>
              <input className="input" type="date" value={form.date_of_birth||""} onChange={e=>field("date_of_birth",e.target.value)}/></div>
          </div>
          <div className="flex gap-3 mt-4">
            <button className="btn-primary" onClick={() => saveMutation.mutate(form)} disabled={saveMutation.isPending}>
              {saveMutation.isPending ? <Loader2 size={14} className="animate-spin"/> : null} Save
            </button>
            <button className="btn-secondary" onClick={resetForm}>Cancel</button>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="px-4 py-3 border-b border-gray-100">
          <p className="text-sm text-gray-500">{data?.count ?? 0} students</p>
        </div>
        {isLoading ? <Spinner text="Loading students..."/> :
         data?.results?.length === 0 ? (
          <div className="p-12 text-center text-gray-400">
            <GraduationCap size={48} className="mx-auto mb-3 opacity-30"/>
            <p className="font-medium">No students found</p>
            <p className="text-sm mt-1">{search ? "Try a different search term" : "Click 'Add Student' to get started"}</p>
          </div>
         ) : (
          <div className="overflow-x-auto">
            <table className="table-auto w-full">
              <thead><tr><th>Adm No.</th><th>Name</th><th>Grade</th><th>Stream</th><th>Parent</th><th>Phone</th><th>QR</th><th>Actions</th></tr></thead>
              <tbody>
                {data?.results?.map((s: Student) => (
                  <tr key={s.id} className="hover:bg-gray-50">
                    <td className="font-mono text-xs">{s.admission_number}</td>
                    <td className="font-medium">{s.full_name}</td>
                    <td><span className="badge badge-blue">{s.grade}</span></td>
                    <td>{s.stream}</td>
                    <td>{s.parent_name}</td>
                    <td>{s.parent_phone}</td>
                    <td>
                      {s.qr_code && (
                        <a href={s.qr_code} target="_blank" rel="noreferrer" title="View QR Code">
                          <QrCode size={16} className="text-blue-500 hover:text-blue-700"/>
                        </a>
                      )}
                    </td>
                    <td>
                      <div className="flex gap-1">
                        <button className="btn-ghost p-1" title="Edit" onClick={() => openEdit(s)}><Edit2 size={14}/></button>
                        <button className="btn-ghost p-1 text-red-400 hover:text-red-600" title="Delete" onClick={() => setDeleteTarget(s)}><Trash2 size={14}/></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Confirm delete dialog */}
      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
        title="Delete Student"
        message={`Are you sure you want to delete ${deleteTarget?.full_name}? This cannot be undone.`}
        confirmLabel="Delete Student"
        danger
      />
    </div>
  )
}
