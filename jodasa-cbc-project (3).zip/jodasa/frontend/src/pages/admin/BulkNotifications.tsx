import { useState } from "react"
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { notificationAPI } from "../../lib/api"
import { Plus, Send, Loader2, CheckCircle } from "lucide-react"
import toast from "react-hot-toast"
import { GRADES } from "../../types"
import type { NotificationTemplate } from "../../types"

export default function AdminBulkNotifications() {
  const qc = useQueryClient()
  const [tab, setTab] = useState<"send"|"templates"|"logs">("send")
  const [selectedTemplate, setSelectedTemplate] = useState<NotificationTemplate|null>(null)
  const [gradeFilter, setGradeFilter] = useState("")
  const [sendResult, setSendResult] = useState<any>(null)
  const [showTemplateForm, setShowTemplateForm] = useState(false)
  const [tForm, setTForm] = useState<any>({ name:"", category:"general", subject:"", body:"", channel:"sms" })

  const { data: templates } = useQuery({ queryKey:["templates"], queryFn: () => notificationAPI.getTemplates().then(r=>r.data) })
  const { data: logs } = useQuery({ queryKey:["notif-logs"], queryFn: () => notificationAPI.getLogs().then(r=>r.data) })

  const sendMutation = useMutation({
    mutationFn: () => notificationAPI.sendBulk(selectedTemplate!.id, { grade: gradeFilter }),
    onSuccess: (r) => { setSendResult(r.data); toast.success(`Sent to ${r.data.sent} recipients`) },
    onError: () => toast.error("Send failed")
  })

  const createTemplate = useMutation({
    mutationFn: (f:any) => notificationAPI.createTemplate(f),
    onSuccess: () => { qc.invalidateQueries({queryKey:["templates"]}); toast.success("Template created"); setShowTemplateForm(false) }
  })

  return (
    <div>
      <div className="page-header">
        <h1 className="page-title">Bulk Notifications</h1>
      </div>

      <div className="flex gap-1 p-1 bg-gray-100 rounded-lg w-fit mb-6">
        {[["send","Send"],["templates","Templates"],["logs","Logs"]].map(([k,l]) => (
          <button key={k} onClick={()=>setTab(k as any)}
            className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors ${tab===k?"bg-white shadow text-gray-900":"text-gray-500 hover:text-gray-700"}`}>
            {l}
          </button>
        ))}
      </div>

      {tab==="send" && (
        <div className="max-w-2xl">
          <div className="card p-6">
            <h2 className="font-semibold mb-4">Send Bulk Message</h2>
            <div className="space-y-4">
              <div>
                <label className="label">Select Template</label>
                <select className="input" value={selectedTemplate?.id||""} onChange={e=>{
                  const t = templates?.results?.find((t:NotificationTemplate)=>t.id===e.target.value)
                  setSelectedTemplate(t||null)
                }}>
                  <option value="">Choose a template...</option>
                  {templates?.results?.map((t:NotificationTemplate) => (
                    <option key={t.id} value={t.id}>{t.name} ({t.channel})</option>
                  ))}
                </select>
              </div>
              {selectedTemplate && (
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs font-medium text-gray-500 mb-1">Preview:</p>
                  <p className="text-sm text-gray-700">{selectedTemplate.body}</p>
                  <span className={`badge mt-2 ${selectedTemplate.channel==="sms"?"badge-green":"badge-blue"}`}>{selectedTemplate.channel.toUpperCase()}</span>
                </div>
              )}
              <div>
                <label className="label">Target Grade (leave empty for all)</label>
                <select className="input" value={gradeFilter} onChange={e=>setGradeFilter(e.target.value)}>
                  <option value="">All Grades</option>
                  {GRADES.map(g=><option key={g} value={g}>{g}</option>)}
                </select>
              </div>
              <button className="btn-primary w-full justify-center py-2.5" onClick={()=>sendMutation.mutate()}
                disabled={!selectedTemplate || sendMutation.isPending}>
                {sendMutation.isPending?<Loader2 size={16} className="animate-spin"/>:<Send size={16}/>}
                Send Notification
              </button>
              {sendResult && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-2"><CheckCircle size={18} className="text-green-600"/><span className="font-semibold text-green-800">Sent Successfully</span></div>
                  <div className="grid grid-cols-3 gap-3 text-center">
                    <div><p className="text-2xl font-bold text-green-700">{sendResult.sent}</p><p className="text-xs text-gray-500">Sent</p></div>
                    <div><p className="text-2xl font-bold text-red-600">{sendResult.failed}</p><p className="text-xs text-gray-500">Failed</p></div>
                    <div><p className="text-2xl font-bold text-gray-700">{sendResult.total}</p><p className="text-xs text-gray-500">Total</p></div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {tab==="templates" && (
        <div>
          <div className="flex justify-end mb-4">
            <button className="btn-primary" onClick={()=>setShowTemplateForm(true)}><Plus size={16}/>New Template</button>
          </div>
          {showTemplateForm && (
            <div className="card p-6 mb-4">
              <h3 className="font-semibold mb-4">New Template</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div><label className="label">Template Name</label>
                  <input className="input" value={tForm.name} onChange={e=>setTForm((f:any)=>({...f,name:e.target.value}))}/></div>
                <div><label className="label">Category</label>
                  <select className="input" value={tForm.category} onChange={e=>setTForm((f:any)=>({...f,category:e.target.value}))}>
                    {["fees","attendance","results","general","event"].map(c=><option key={c} value={c}>{c}</option>)}
                  </select></div>
                <div><label className="label">Channel</label>
                  <select className="input" value={tForm.channel} onChange={e=>setTForm((f:any)=>({...f,channel:e.target.value}))}>
                    <option value="sms">SMS</option><option value="email">Email</option><option value="both">Both</option>
                  </select></div>
                <div><label className="label">Email Subject (if email)</label>
                  <input className="input" value={tForm.subject} onChange={e=>setTForm((f:any)=>({...f,subject:e.target.value}))}/></div>
                <div className="col-span-2"><label className="label">Message Body (use {"{student_name}"}, {"{grade}"}, {"{school_name}"})</label>
                  <textarea className="input h-24 resize-none" value={tForm.body} onChange={e=>setTForm((f:any)=>({...f,body:e.target.value}))}/></div>
              </div>
              <div className="flex gap-3 mt-4">
                <button className="btn-primary" onClick={()=>createTemplate.mutate(tForm)} disabled={createTemplate.isPending}>Save</button>
                <button className="btn-secondary" onClick={()=>setShowTemplateForm(false)}>Cancel</button>
              </div>
            </div>
          )}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {templates?.results?.map((t:NotificationTemplate) => (
              <div key={t.id} className="card p-4">
                <div className="flex items-center justify-between mb-2">
                  <p className="font-semibold">{t.name}</p>
                  <span className={`badge ${t.channel==="sms"?"badge-green":t.channel==="email"?"badge-blue":"badge-purple"}`}>{t.channel}</span>
                </div>
                <p className="text-xs text-gray-500 capitalize mb-2">{t.category}</p>
                <p className="text-sm text-gray-600 line-clamp-2">{t.body}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab==="logs" && (
        <div className="card overflow-hidden">
          <table className="table-auto w-full">
            <thead><tr><th>Recipient</th><th>Channel</th><th>Status</th><th>Message</th><th>Sent At</th></tr></thead>
            <tbody>
              {logs?.results?.map((l:any) => (
                <tr key={l.id} className="hover:bg-gray-50">
                  <td className="font-medium">{l.recipient_name}</td>
                  <td><span className={`badge ${l.channel==="sms"?"badge-green":"badge-blue"}`}>{l.channel}</span></td>
                  <td><span className={l.status==="sent"?"badge-green badge":"badge-red badge"}>{l.status}</span></td>
                  <td className="text-xs text-gray-500 max-w-xs truncate">{l.message}</td>
                  <td className="text-xs text-gray-400">{new Date(l.sent_at).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
