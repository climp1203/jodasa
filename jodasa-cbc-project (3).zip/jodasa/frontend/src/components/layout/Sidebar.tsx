import { NavLink, useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../lib/store'
import {
  LayoutDashboard, Users, School, BookOpen, ClipboardList,
  QrCode, BarChart2, Folder, Leaf, Megaphone, CreditCard,
  GraduationCap, Brain, X, LogOut, Library, Settings,
  PieChart, History, UserCog
} from 'lucide-react'

const LINKS: Record<string, {to:string;icon:any;label:string}[]> = {
  superadmin: [
    {to:'/superadmin', icon:LayoutDashboard, label:'Dashboard'},
    {to:'/superadmin/schools', icon:School, label:'Schools'},
    {to:'/superadmin/users', icon:Users, label:'All Users'},
    {to:'/superadmin/analytics', icon:PieChart, label:'Analytics'},
    {to:'/superadmin/profile', icon:Settings, label:'Profile'},
  ],
  school_admin: [
    {to:'/admin', icon:LayoutDashboard, label:'Dashboard'},
    {to:'/admin/students', icon:GraduationCap, label:'Students'},
    {to:'/admin/users', icon:UserCog, label:'Staff & Users'},
    {to:'/admin/fees', icon:CreditCard, label:'Fee Management'},
    {to:'/admin/notifications', icon:Megaphone, label:'Notifications'},
    {to:'/admin/qr', icon:QrCode, label:'Bulk QR Print'},
    {to:'/admin/profile', icon:Settings, label:'Profile'},
  ],
  teacher: [
    {to:'/teacher', icon:LayoutDashboard, label:'Dashboard'},
    {to:'/teacher/attendance', icon:QrCode, label:'Attendance (QR)'},
    {to:'/teacher/assessments', icon:ClipboardList, label:'Assessments'},
    {to:'/teacher/results', icon:BarChart2, label:'Test Results'},
    {to:'/teacher/portfolio', icon:Folder, label:'Portfolio'},
    {to:'/teacher/csl', icon:Leaf, label:'CSL Tracker'},
    {to:'/teacher/lessons', icon:BookOpen, label:'Lesson Planner'},
    {to:'/teacher/profile', icon:Settings, label:'Profile'},
  ],
  parent: [
    {to:'/parent', icon:LayoutDashboard, label:'My Child'},
    {to:'/parent/fees', icon:CreditCard, label:'Fee Statement'},
    {to:'/parent/profile', icon:Settings, label:'Profile'},
  ],
  student: [
    {to:'/student', icon:LayoutDashboard, label:'Dashboard'},
    {to:'/student/quiz', icon:Brain, label:'AI Quiz'},
    {to:'/student/quiz-history', icon:History, label:'Quiz History'},
    {to:'/student/elearning', icon:Library, label:'eLearning'},
    {to:'/student/profile', icon:Settings, label:'Profile'},
  ],
}

export default function Sidebar({ onClose }: { onClose: () => void }) {
  const { user, logout } = useAuthStore()
  const navigate = useNavigate()
  const links = (user?.role && LINKS[user.role]) ? LINKS[user.role] : []

  return (
    <div className="flex flex-col h-full bg-white border-r border-gray-200">
      <div className="flex items-center justify-between px-4 py-4 border-b border-gray-100">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-sm">JDS</div>
          <div>
            <p className="font-bold text-gray-900 text-sm">Jodasa CBC</p>
            <p className="text-xs text-gray-400 capitalize">{user?.role?.replace("_"," ")}</p>
          </div>
        </div>
        <button onClick={onClose} className="lg:hidden p-1 rounded text-gray-400"><X size={18}/></button>
      </div>
      {user?.tenant_slug && (
        <div className="px-4 py-2 bg-blue-50 border-b border-blue-100">
          <p className="text-xs text-blue-600 font-medium truncate">{user.tenant_slug}.jodasa.co.ke</p>
        </div>
      )}
      <nav className="flex-1 p-3 space-y-0.5 overflow-y-auto">
        {links.map(({ to, icon: Icon, label }) => (
          <NavLink key={to} to={to} end={to.split("/").length <= 2} onClick={onClose}
            className={({ isActive }) => isActive ? "sidebar-link-active" : "sidebar-link-inactive"}>
            <Icon size={18}/><span>{label}</span>
          </NavLink>
        ))}
      </nav>
      <div className="p-3 border-t border-gray-100">
        <div className="flex items-center gap-3 px-2 py-2 mb-1">
          <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 text-xs font-bold">
            {user?.full_name?.charAt(0) || "U"}
          </div>
          <div className="min-w-0">
            <p className="text-sm font-medium text-gray-900 truncate">{user?.full_name}</p>
            <p className="text-xs text-gray-400 truncate">{user?.email}</p>
          </div>
        </div>
        <button onClick={() => { logout(); navigate("/login") }}
          className="sidebar-link-inactive w-full text-red-500 hover:bg-red-50 hover:text-red-600">
          <LogOut size={16}/><span>Sign out</span>
        </button>
      </div>
    </div>
  )
}
