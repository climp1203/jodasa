import { Menu, Bell, Sun, Moon } from 'lucide-react'
import { useState } from 'react'
import { useAuthStore } from '../../lib/store'

export default function Topbar({ onMenuClick }: { onMenuClick: () => void }) {
  const { user } = useAuthStore()
  const [dark, setDark] = useState(false)

  const toggleDark = () => {
    setDark(!dark)
    document.documentElement.classList.toggle("dark")
  }

  return (
    <header className="flex items-center justify-between px-4 py-3 bg-white border-b border-gray-200 flex-shrink-0">
      <div className="flex items-center gap-3">
        <button onClick={onMenuClick} className="lg:hidden p-2 rounded-lg hover:bg-gray-100 text-gray-500">
          <Menu size={20}/>
        </button>
        <div className="hidden sm:block">
          <p className="text-sm font-semibold text-gray-900">Welcome back, {user?.full_name?.split(" ")[0]} 👋</p>
          <p className="text-xs text-gray-400">{new Date().toLocaleDateString("en-KE",{weekday:"long",year:"numeric",month:"long",day:"numeric"})}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <button onClick={toggleDark} className="p-2 rounded-lg hover:bg-gray-100 text-gray-500">
          {dark ? <Sun size={18}/> : <Moon size={18}/>}
        </button>
        <button className="p-2 rounded-lg hover:bg-gray-100 text-gray-500 relative">
          <Bell size={18}/>
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"/>
        </button>
        <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center text-white text-sm font-bold ml-1">
          {user?.full_name?.charAt(0) || "U"}
        </div>
      </div>
    </header>
  )
}
