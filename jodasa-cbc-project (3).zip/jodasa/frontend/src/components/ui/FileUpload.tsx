import { useState, useRef } from 'react'
import { Upload, X, FileText, Image } from 'lucide-react'

interface FileUploadProps {
  accept?: string
  onFile: (file: File) => void
  label?: string
  maxMB?: number
}

export default function FileUpload({ accept = '*', onFile, label = 'Upload File', maxMB = 5 }: FileUploadProps) {
  const [dragging, setDragging] = useState(false)
  const [selected, setSelected] = useState<File | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const handle = (file: File) => {
    if (file.size > maxMB * 1024 * 1024) {
      alert(`File too large. Max ${maxMB}MB allowed.`); return
    }
    setSelected(file)
    onFile(file)
  }

  return (
    <div
      className={`border-2 border-dashed rounded-xl p-4 text-center cursor-pointer transition-colors
        ${dragging ? 'border-blue-400 bg-blue-50' : 'border-gray-200 hover:border-gray-300'}`}
      onClick={() => inputRef.current?.click()}
      onDragOver={e => { e.preventDefault(); setDragging(true) }}
      onDragLeave={() => setDragging(false)}
      onDrop={e => { e.preventDefault(); setDragging(false); const f = e.dataTransfer.files[0]; if(f) handle(f) }}
    >
      <input ref={inputRef} type="file" accept={accept} className="hidden"
        onChange={e => { const f = e.target.files?.[0]; if(f) handle(f) }}/>
      {selected ? (
        <div className="flex items-center gap-2 justify-center text-sm text-gray-700">
          {selected.type.startsWith('image') ? <Image size={18} className="text-blue-500"/> : <FileText size={18} className="text-blue-500"/>}
          <span className="truncate max-w-xs">{selected.name}</span>
          <button onClick={e => { e.stopPropagation(); setSelected(null) }} className="text-gray-400 hover:text-red-500">
            <X size={14}/>
          </button>
        </div>
      ) : (
        <div className="flex flex-col items-center gap-1 text-gray-400 py-2">
          <Upload size={24}/>
          <p className="text-sm font-medium">{label}</p>
          <p className="text-xs">Drag & drop or click · Max {maxMB}MB</p>
        </div>
      )}
    </div>
  )
}
