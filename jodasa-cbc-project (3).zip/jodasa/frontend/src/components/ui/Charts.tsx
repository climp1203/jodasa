import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, LineChart, Line, ResponsiveContainer, Legend
} from 'recharts'

const COLORS = ['#3b82f6','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4']

interface BarChartCardProps {
  data: { name: string; value: number }[]
  title: string
  color?: string
  height?: number
}

export function BarChartCard({ data, title, color = '#3b82f6', height = 200 }: BarChartCardProps) {
  return (
    <div className="card p-4">
      <h3 className="text-sm font-semibold text-gray-700 mb-3">{title}</h3>
      <ResponsiveContainer width="100%" height={height}>
        <BarChart data={data} margin={{top:0,right:0,bottom:0,left:-20}}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
          <XAxis dataKey="name" tick={{fontSize:11}} axisLine={false} tickLine={false}/>
          <YAxis tick={{fontSize:11}} axisLine={false} tickLine={false}/>
          <Tooltip contentStyle={{borderRadius:'8px',border:'1px solid #e5e7eb',fontSize:12}}/>
          <Bar dataKey="value" fill={color} radius={[4,4,0,0]}/>
        </BarChart>
      </ResponsiveContainer>
    </div>
  )
}

interface PieChartCardProps {
  data: { name: string; value: number }[]
  title: string
  height?: number
}

export function PieChartCard({ data, title, height = 200 }: PieChartCardProps) {
  return (
    <div className="card p-4">
      <h3 className="text-sm font-semibold text-gray-700 mb-3">{title}</h3>
      <ResponsiveContainer width="100%" height={height}>
        <PieChart>
          <Pie data={data} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={70} label={({name,percent}) => `${name} ${(percent*100).toFixed(0)}%`} labelLine={false}>
            {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]}/>)}
          </Pie>
          <Tooltip contentStyle={{borderRadius:'8px',border:'1px solid #e5e7eb',fontSize:12}}/>
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}

interface LineChartCardProps {
  data: { name: string; [key: string]: any }[]
  lines: { key: string; label: string; color?: string }[]
  title: string
  height?: number
}

export function LineChartCard({ data, lines, title, height = 200 }: LineChartCardProps) {
  return (
    <div className="card p-4">
      <h3 className="text-sm font-semibold text-gray-700 mb-3">{title}</h3>
      <ResponsiveContainer width="100%" height={height}>
        <LineChart data={data} margin={{top:0,right:0,bottom:0,left:-20}}>
          <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0"/>
          <XAxis dataKey="name" tick={{fontSize:11}} axisLine={false} tickLine={false}/>
          <YAxis tick={{fontSize:11}} axisLine={false} tickLine={false}/>
          <Tooltip contentStyle={{borderRadius:'8px',border:'1px solid #e5e7eb',fontSize:12}}/>
          <Legend wrapperStyle={{fontSize:12}}/>
          {lines.map((l, i) => (
            <Line key={l.key} type="monotone" dataKey={l.key} name={l.label}
              stroke={l.color || COLORS[i]} strokeWidth={2} dot={false}/>
          ))}
        </LineChart>
      </ResponsiveContainer>
    </div>
  )
}
