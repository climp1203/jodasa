interface StatCardProps {
  label: string
  value: string | number
  icon: React.ElementType
  color: 'blue' | 'green' | 'purple' | 'orange' | 'red' | 'yellow'
  trend?: string
}

const colorMap: Record<string, string> = {
  blue:   'bg-blue-100 text-blue-700',
  green:  'bg-green-100 text-green-700',
  purple: 'bg-purple-100 text-purple-700',
  orange: 'bg-orange-100 text-orange-700',
  red:    'bg-red-100 text-red-700',
  yellow: 'bg-yellow-100 text-yellow-700',
}

export default function StatCard({ label, value, icon: Icon, color, trend }: StatCardProps) {
  return (
    <div className="stat-card">
      <div className={`w-10 h-10 rounded-xl ${colorMap[color]} flex items-center justify-center mb-3`}>
        <Icon size={20}/>
      </div>
      <p className="stat-value">{value}</p>
      <p className="stat-label">{label}</p>
      {trend && <p className="text-xs text-green-600 mt-1 font-medium">{trend}</p>}
    </div>
  )
}
