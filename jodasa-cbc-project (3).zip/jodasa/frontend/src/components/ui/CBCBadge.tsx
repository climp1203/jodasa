import type { CBCPerformance } from '../../types'

const config: Record<CBCPerformance, { label: string; className: string }> = {
  EE: { label: 'Exceeds Expectation', className: 'cbc-ee' },
  ME: { label: 'Meets Expectation',   className: 'cbc-me' },
  AE: { label: 'Approaches Expectation', className: 'cbc-ae' },
  BE: { label: 'Below Expectation',   className: 'cbc-be' },
}

interface CBCBadgeProps {
  level: CBCPerformance
  showLabel?: boolean
}

export default function CBCBadge({ level, showLabel = false }: CBCBadgeProps) {
  const { label, className } = config[level]
  return (
    <span className={className}>
      {level}{showLabel ? ` — ${label}` : ''}
    </span>
  )
}
