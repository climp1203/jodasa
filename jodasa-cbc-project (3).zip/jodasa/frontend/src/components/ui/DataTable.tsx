import { useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'

interface Column<T> {
  key: string
  label: string
  render?: (row: T) => React.ReactNode
  width?: string
}

interface DataTableProps<T> {
  columns: Column<T>[]
  data: T[]
  rowKey: (row: T) => string
  pageSize?: number
  emptyMessage?: string
}

export default function DataTable<T>({ columns, data, rowKey, pageSize = 15, emptyMessage = 'No records found.' }: DataTableProps<T>) {
  const [page, setPage] = useState(1)
  const totalPages = Math.max(1, Math.ceil(data.length / pageSize))
  const paginated = data.slice((page - 1) * pageSize, page * pageSize)

  return (
    <div>
      <div className="overflow-x-auto">
        <table className="table-auto w-full">
          <thead>
            <tr>{columns.map(c => <th key={c.key} style={c.width ? {width:c.width} : {}}>{c.label}</th>)}</tr>
          </thead>
          <tbody>
            {paginated.length === 0 ? (
              <tr><td colSpan={columns.length} className="py-12 text-center text-gray-400">{emptyMessage}</td></tr>
            ) : paginated.map(row => (
              <tr key={rowKey(row)} className="hover:bg-gray-50">
                {columns.map(c => (
                  <td key={c.key}>{c.render ? c.render(row) : String((row as any)[c.key] ?? '—')}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
          <p className="text-sm text-gray-500">
            {(page-1)*pageSize+1}–{Math.min(page*pageSize, data.length)} of {data.length}
          </p>
          <div className="flex gap-1">
            <button className="btn-ghost p-1.5" onClick={() => setPage(p => Math.max(1, p-1))} disabled={page===1}>
              <ChevronLeft size={16}/>
            </button>
            {Array.from({length: totalPages}, (_, i) => i+1).filter(p => Math.abs(p-page) <= 2).map(p => (
              <button key={p} onClick={() => setPage(p)}
                className={`w-8 h-8 rounded-lg text-sm font-medium ${p===page ? 'bg-blue-600 text-white' : 'hover:bg-gray-100 text-gray-600'}`}>
                {p}
              </button>
            ))}
            <button className="btn-ghost p-1.5" onClick={() => setPage(p => Math.min(totalPages, p+1))} disabled={page===totalPages}>
              <ChevronRight size={16}/>
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
