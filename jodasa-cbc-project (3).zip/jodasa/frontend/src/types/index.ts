export type UserRole = 'superadmin' | 'school_admin' | 'teacher' | 'parent' | 'student'

export interface Tenant {
  id: string
  name: string
  slug: string
  logo?: string
  address?: string
  phone?: string
  email?: string
  county?: string
  is_active: boolean
  subscription_plan: 'basic' | 'standard' | 'premium'
  subscription_expires?: string
  created_at: string
}

export interface User {
  id: string
  username: string
  email: string
  first_name: string
  last_name: string
  full_name: string
  role: UserRole
  phone?: string
  avatar?: string
  tenant?: string
  is_active: boolean
}

export interface Student {
  id: string
  tenant: string
  admission_number: string
  first_name: string
  last_name: string
  full_name: string
  date_of_birth?: string
  gender?: 'M' | 'F'
  grade: string
  stream?: string
  photo?: string
  qr_code?: string
  parent_name?: string
  parent_phone?: string
  parent_email?: string
  is_active: boolean
  admission_date?: string
  created_at: string
}

export interface AttendanceSession {
  id: string
  tenant: string
  teacher: string
  teacher_name: string
  grade: string
  stream?: string
  date: string
  subject?: string
  records: AttendanceRecord[]
  total_present: number
  total_absent: number
  created_at: string
}

export interface AttendanceRecord {
  id: string
  session: string
  student: string
  student_name: string
  admission_number: string
  status: 'present' | 'absent' | 'late' | 'excused'
  scan_method: 'qr' | 'manual'
  scanned_at?: string
  notes?: string
}

export type CBCPerformance = 'EE' | 'ME' | 'AE' | 'BE'

export interface Assessment {
  id: string
  tenant: string
  teacher: string
  teacher_name: string
  title: string
  subject: string
  grade: string
  stream?: string
  assessment_type: 'formative' | 'summative' | 'project' | 'quiz'
  description?: string
  max_score: number
  date: string
  term: '1' | '2' | '3'
  year: number
  questions: QuizQuestion[]
  result_count: number
  created_at: string
}

export interface QuizQuestion {
  id: string
  assessment: string
  question_text: string
  option_a: string
  option_b: string
  option_c: string
  option_d: string
  correct_answer?: string
  explanation?: string
  order: number
}

export interface AssessmentResult {
  id: string
  assessment: string
  student: string
  student_name: string
  admission_number: string
  score?: number
  cbc_performance?: CBCPerformance
  teacher_remarks?: string
  submitted_at: string
}

export interface PortfolioEntry {
  id: string
  student: string
  student_name: string
  teacher: string
  teacher_name: string
  competency?: string
  competency_name?: string
  title: string
  description: string
  evidence?: string
  performance_level?: CBCPerformance
  subject?: string
  term: '1' | '2' | '3'
  year: number
  date: string
  teacher_remarks?: string
  created_at: string
}

export interface CSLActivity {
  id: string
  student: string
  student_name: string
  teacher: string
  teacher_name: string
  activity_name: string
  description: string
  location?: string
  hours_spent: number
  date: string
  impact?: string
  verified_by?: string
  evidence_photo?: string
  term: '1' | '2' | '3'
  year: number
  created_at: string
}

export interface Lesson {
  id: string
  teacher: string
  teacher_name: string
  title: string
  subject: string
  grade: string
  stream?: string
  description?: string
  content: string
  objectives?: string
  resources: { label: string; url: string }[]
  status: 'draft' | 'published' | 'archived'
  term: '1' | '2' | '3'
  year: number
  estimated_duration: number
  created_at: string
  updated_at: string
}

export interface FeeStructure {
  id: string
  tenant: string
  name: string
  grade?: string
  term: '1' | '2' | '3'
  year: number
  tuition: number
  boarding: number
  activity: number
  exam: number
  other: number
  total: number
  created_at: string
}

export interface Payment {
  id: string
  tenant: string
  student: string
  student_name: string
  admission_number: string
  fee_structure?: string
  amount: number
  method: 'mpesa' | 'bank' | 'cash' | 'cheque'
  status: 'pending' | 'completed' | 'failed' | 'reversed'
  mpesa_receipt?: string
  phone_number?: string
  term: '1' | '2' | '3'
  year: number
  notes?: string
  paid_at?: string
  created_at: string
}

export interface NotificationTemplate {
  id: string
  tenant: string
  name: string
  category: 'fees' | 'attendance' | 'results' | 'general' | 'event'
  subject?: string
  body: string
  channel: 'sms' | 'email' | 'both'
  created_at: string
}

export interface NotificationLog {
  id: string
  template?: string
  recipient_name: string
  recipient_phone?: string
  recipient_email?: string
  message: string
  channel: 'sms' | 'email'
  status: 'sent' | 'failed' | 'pending'
  sent_at: string
}

export const GRADES = ['PP1','PP2','G1','G2','G3','G4','G5','G6','G7','G8','G9']
export const STREAMS = ['A','B','C','D','E']
export const TERMS = [{ value: '1', label: 'Term 1' }, { value: '2', label: 'Term 2' }, { value: '3', label: 'Term 3' }]
export const CBC_PERFORMANCE_LABELS: Record<string, string> = {
  EE: 'Exceeds Expectation',
  ME: 'Meets Expectation',
  AE: 'Approaches Expectation',
  BE: 'Below Expectation',
}
