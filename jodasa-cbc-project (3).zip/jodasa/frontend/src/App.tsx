import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useAuthStore } from './lib/store'
import Layout from './components/layout/Layout'
import ErrorBoundary from './components/ui/ErrorBoundary'

// Auth
import LoginPage from './pages/LoginPage'
import NotFound from './pages/NotFound'
import ProfileSettings from './pages/ProfileSettings'

// Superadmin
import SuperadminDashboard from './pages/superadmin/Dashboard'
import SuperadminSchools from './pages/superadmin/Schools'
import SuperadminUsers from './pages/superadmin/Users'
import SuperadminAnalytics from './pages/superadmin/Analytics'

// Admin
import AdminDashboard from './pages/admin/Dashboard'
import AdminStudents from './pages/admin/Students'
import AdminFeeManagement from './pages/admin/FeeManagement'
import AdminBulkNotifications from './pages/admin/BulkNotifications'
import AdminUserManagement from './pages/admin/UserManagement'
import AdminBulkQR from './pages/admin/BulkQR'

// Teacher
import TeacherDashboard from './pages/teacher/Dashboard'
import AttendanceMarking from './pages/teacher/AttendanceMarking'
import AssessmentPage from './pages/teacher/Assessments'
import PortfolioPage from './pages/teacher/Portfolio'
import CSLTracker from './pages/teacher/CSLTracker'
import LessonPlanner from './pages/teacher/LessonPlanner'
import StudentTestResults from './pages/teacher/StudentTestResults'

// Parent
import ParentPortal from './pages/parent/ParentPortal'
import FeeStatement from './pages/parent/FeeStatement'

// Student
import StudentDashboard from './pages/student/Dashboard'
import AIQuiz from './pages/student/AIQuiz'
import StudentELearning from './pages/student/ELearning'
import QuizHistory from './pages/student/QuizHistory'

function RequireAuth({ children, roles }: { children: React.ReactNode; roles?: string[] }) {
  const { isAuthenticated, user } = useAuthStore()
  if (!isAuthenticated) return <Navigate to="/login" replace />
  if (roles && user && !roles.includes(user.role)) return <Navigate to="/" replace />
  return <>{children}</>
}

function RoleRedirect() {
  const { user } = useAuthStore()
  if (!user) return <Navigate to="/login" replace />
  const map: Record<string, string> = {
    superadmin: '/superadmin', school_admin: '/admin',
    teacher: '/teacher', parent: '/parent', student: '/student',
  }
  return <Navigate to={map[user.role] || '/login'} replace />
}

export default function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route path="/" element={<RequireAuth><RoleRedirect /></RequireAuth>} />

          {/* Superadmin */}
          <Route path="/superadmin" element={<RequireAuth roles={['superadmin']}><Layout /></RequireAuth>}>
            <Route index element={<SuperadminDashboard />} />
            <Route path="schools" element={<SuperadminSchools />} />
            <Route path="users" element={<SuperadminUsers />} />
            <Route path="analytics" element={<SuperadminAnalytics />} />
            <Route path="profile" element={<ProfileSettings />} />
          </Route>

          {/* Admin */}
          <Route path="/admin" element={<RequireAuth roles={['school_admin','superadmin']}><Layout /></RequireAuth>}>
            <Route index element={<AdminDashboard />} />
            <Route path="students" element={<AdminStudents />} />
            <Route path="fees" element={<AdminFeeManagement />} />
            <Route path="notifications" element={<AdminBulkNotifications />} />
            <Route path="users" element={<AdminUserManagement />} />
            <Route path="qr" element={<AdminBulkQR />} />
            <Route path="profile" element={<ProfileSettings />} />
          </Route>

          {/* Teacher */}
          <Route path="/teacher" element={<RequireAuth roles={['teacher','school_admin','superadmin']}><Layout /></RequireAuth>}>
            <Route index element={<TeacherDashboard />} />
            <Route path="attendance" element={<AttendanceMarking />} />
            <Route path="assessments" element={<AssessmentPage />} />
            <Route path="portfolio" element={<PortfolioPage />} />
            <Route path="csl" element={<CSLTracker />} />
            <Route path="lessons" element={<LessonPlanner />} />
            <Route path="results" element={<StudentTestResults />} />
            <Route path="profile" element={<ProfileSettings />} />
          </Route>

          {/* Parent */}
          <Route path="/parent" element={<RequireAuth roles={['parent']}><Layout /></RequireAuth>}>
            <Route index element={<ParentPortal />} />
            <Route path="fees" element={<FeeStatement />} />
            <Route path="profile" element={<ProfileSettings />} />
          </Route>

          {/* Student */}
          <Route path="/student" element={<RequireAuth roles={['student']}><Layout /></RequireAuth>}>
            <Route index element={<StudentDashboard />} />
            <Route path="quiz" element={<AIQuiz />} />
            <Route path="quiz-history" element={<QuizHistory />} />
            <Route path="elearning" element={<StudentELearning />} />
            <Route path="profile" element={<ProfileSettings />} />
          </Route>

          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </ErrorBoundary>
  )
}
