import axios from 'axios'
import { useAuthStore } from './store'

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  headers: { 'Content-Type': 'application/json' },
})

// Attach JWT + tenant slug on every request
api.interceptors.request.use((config) => {
  const { accessToken, user } = useAuthStore.getState()
  if (accessToken) {
    config.headers.Authorization = `Bearer ${accessToken}`
  }
  if (user?.tenant_slug) {
    config.headers['X-Tenant-Slug'] = user.tenant_slug
  }
  return config
})

// Auto-refresh on 401
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true
      const { refreshToken, updateToken, logout } = useAuthStore.getState()
      if (refreshToken) {
        try {
          const { data } = await axios.post('/api/auth/refresh/', { refresh: refreshToken })
          updateToken(data.access)
          original.headers.Authorization = `Bearer ${data.access}`
          return api(original)
        } catch {
          logout()
          window.location.href = '/login'
        }
      } else {
        logout()
        window.location.href = '/login'
      }
    }
    return Promise.reject(error)
  }
)

export default api

// ── typed API helpers ──────────────────────────────────────────────────────

export const authAPI = {
  login: (username: string, password: string) =>
    api.post('/auth/login/', { username, password }),
}

export const tenantAPI = {
  getAll: () => api.get('/tenants/'),
  create: (data: object) => api.post('/tenants/', data),
  update: (id: string, data: object) => api.patch(`/tenants/${id}/`, data),
  delete: (id: string) => api.delete(`/tenants/${id}/`),
  bySlug: (slug: string) => api.get(`/tenants/by-slug/${slug}/`),
}

export const userAPI = {
  getAll: () => api.get('/auth/users/'),
  me: () => api.get('/auth/users/me/'),
  create: (data: object) => api.post('/auth/users/', data),
  update: (id: string, data: object) => api.patch(`/auth/users/${id}/`, data),
  delete: (id: string) => api.delete(`/auth/users/${id}/`),
  teachers: () => api.get('/auth/users/teachers/'),
}

export const studentAPI = {
  getAll: (params?: object) => api.get('/students/', { params }),
  get: (id: string) => api.get(`/students/${id}/`),
  create: (data: object) => api.post('/students/', data),
  update: (id: string, data: object) => api.patch(`/students/${id}/`, data),
  delete: (id: string) => api.delete(`/students/${id}/`),
  byGrade: (grade: string) => api.get(`/students/by-grade/${grade}/`),
  qrLookup: (id: string) => api.get(`/students/qr_lookup/?id=${id}`),
}

export const attendanceAPI = {
  getSessions: (params?: object) => api.get('/attendance/sessions/', { params }),
  createSession: (data: object) => api.post('/attendance/sessions/', data),
  qrScan: (sessionId: string, data: object) =>
    api.post(`/attendance/sessions/${sessionId}/qr-scan/`, data),
  bulkMark: (sessionId: string, data: object) =>
    api.post(`/attendance/sessions/${sessionId}/bulk-mark/`, data),
  studentSummary: (studentId: string) =>
    api.get(`/attendance/sessions/student-summary/${studentId}/`),
}

export const assessmentAPI = {
  getAll: (params?: object) => api.get('/assessments/', { params }),
  get: (id: string) => api.get(`/assessments/${id}/`),
  create: (data: object) => api.post('/assessments/', data),
  generateQuiz: (data: object) => api.post('/assessments/generate-quiz/', data),
  saveQuestions: (id: string, data: object) => api.post(`/assessments/${id}/save-questions/`, data),
  submitQuiz: (id: string, data: object) => api.post(`/assessments/${id}/submit-quiz/`, data),
  results: (id: string) => api.get(`/assessments/${id}/results/`),
}

export const portfolioAPI = {
  getEntries: (params?: object) => api.get('/portfolio/entries/', { params }),
  createEntry: (data: object) => api.post('/portfolio/entries/', data),
  updateEntry: (id: string, data: object) => api.patch(`/portfolio/entries/${id}/`, data),
  byStudent: (studentId: string) => api.get(`/portfolio/entries/by-student/${studentId}/`),
  getCSL: (params?: object) => api.get('/portfolio/csl/', { params }),
  createCSL: (data: object) => api.post('/portfolio/csl/', data),
  studentHours: (studentId: string) => api.get(`/portfolio/csl/student-hours/${studentId}/`),
  getCompetencies: () => api.get('/portfolio/competencies/'),
}

export const lessonAPI = {
  getAll: (params?: object) => api.get('/elearning/lessons/', { params }),
  get: (id: string) => api.get(`/elearning/lessons/${id}/`),
  create: (data: object) => api.post('/elearning/lessons/', data),
  update: (id: string, data: object) => api.patch(`/elearning/lessons/${id}/`, data),
  delete: (id: string) => api.delete(`/elearning/lessons/${id}/`),
  forStudent: (grade: string) => api.get(`/elearning/lessons/for-student/${grade}/`),
  updateProgress: (id: string, data: object) => api.post(`/elearning/lessons/${id}/update-progress/`, data),
}

export const feesAPI = {
  getStructures: (params?: object) => api.get('/fees/structures/', { params }),
  createStructure: (data: object) => api.post('/fees/structures/', data),
  getPayments: (params?: object) => api.get('/fees/payments/', { params }),
  createPayment: (data: object) => api.post('/fees/payments/', data),
  mpesaSTK: (data: object) => api.post('/fees/payments/mpesa-stk/', data),
  statement: (studentId: string) => api.get(`/fees/payments/statement/${studentId}/`),
}

export const notificationAPI = {
  getTemplates: () => api.get('/notifications/templates/'),
  createTemplate: (data: object) => api.post('/notifications/templates/', data),
  updateTemplate: (id: string, data: object) => api.patch(`/notifications/templates/${id}/`, data),
  sendBulk: (id: string, data: object) => api.post(`/notifications/templates/${id}/send-bulk/`, data),
  getLogs: () => api.get('/notifications/logs/'),
}
