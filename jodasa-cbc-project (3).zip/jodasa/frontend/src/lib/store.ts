import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import type { UserRole } from '../types'

export type { UserRole }

export interface AuthUser {
  id: string
  full_name: string
  email: string
  role: UserRole
  tenant_id: string | null
  tenant_slug: string | null
  avatar: string | null
}

interface AuthState {
  user: AuthUser | null
  accessToken: string | null
  refreshToken: string | null
  isAuthenticated: boolean
  setAuth: (user: AuthUser, access: string, refresh: string) => void
  logout: () => void
  updateToken: (access: string) => void
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      accessToken: null,
      refreshToken: null,
      isAuthenticated: false,
      setAuth: (user, accessToken, refreshToken) =>
        set({ user, accessToken, refreshToken, isAuthenticated: true }),
      logout: () =>
        set({ user: null, accessToken: null, refreshToken: null, isAuthenticated: false }),
      updateToken: (accessToken) => set({ accessToken }),
    }),
    { name: 'jodasa-auth' }
  )
)
