-- ============================================================
-- JODASA CBC — COMPLETE DATABASE SETUP SCRIPT
-- Run this in pgAdmin or psql BEFORE running Django migrations
-- ============================================================

-- Step 1: Create the database (run as postgres superuser)
CREATE DATABASE jodasa_db
    WITH
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'en_US.UTF-8'
    LC_CTYPE = 'en_US.UTF-8'
    TEMPLATE = template0;

-- Step 2: Create a dedicated app user (more secure than using postgres)
CREATE USER jodasa_user WITH PASSWORD 'JodasaSecure2026!';

-- Step 3: Grant privileges
GRANT ALL PRIVILEGES ON DATABASE jodasa_db TO jodasa_user;
GRANT ALL ON SCHEMA public TO jodasa_user;
ALTER USER jodasa_user CREATEDB;  -- needed for running tests

-- ============================================================
-- CONNECT TO jodasa_db BEFORE RUNNING THE REST
-- In pgAdmin: right-click jodasa_db > Query Tool
-- In psql: \c jodasa_db
-- ============================================================

-- Step 4: Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";   -- UUID generation
CREATE EXTENSION IF NOT EXISTS "pg_trgm";     -- Fuzzy text search

-- ============================================================
-- ROW-LEVEL SECURITY (RLS) — Run AFTER Django migrations
-- ============================================================

-- Helper function to get current tenant from session variable
CREATE OR REPLACE FUNCTION current_tenant_id()
RETURNS UUID AS $$
BEGIN
    RETURN current_setting('app.tenant_id', TRUE)::UUID;
EXCEPTION WHEN OTHERS THEN
    RETURN NULL;
END;
$$ LANGUAGE plpgsql STABLE SECURITY DEFINER;

-- Enable RLS on all tenant-scoped tables
ALTER TABLE students_student              ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_attendancesession  ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_attendancerecord   ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessments_assessment        ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessments_assessmentresult  ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessments_quizquestion      ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessments_quizattempt       ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolio_competency          ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolio_portfolioentry      ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolio_cslactivity         ENABLE ROW LEVEL SECURITY;
ALTER TABLE elearning_lesson              ENABLE ROW LEVEL SECURITY;
ALTER TABLE elearning_lessonprogress      ENABLE ROW LEVEL SECURITY;
ALTER TABLE fees_feestructure             ENABLE ROW LEVEL SECURITY;
ALTER TABLE fees_payment                  ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications_notificationtemplate ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications_notificationlog      ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY tenant_isolation ON students_student
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON attendance_attendancesession
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON attendance_attendancerecord
    USING (session_id IN (
        SELECT id FROM attendance_attendancesession
        WHERE tenant_id = current_tenant_id()
    ));

CREATE POLICY tenant_isolation ON assessments_assessment
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON assessments_assessmentresult
    USING (assessment_id IN (
        SELECT id FROM assessments_assessment
        WHERE tenant_id = current_tenant_id()
    ));

CREATE POLICY tenant_isolation ON assessments_quizquestion
    USING (assessment_id IN (
        SELECT id FROM assessments_assessment
        WHERE tenant_id = current_tenant_id()
    ));

CREATE POLICY tenant_isolation ON assessments_quizattempt
    USING (assessment_id IN (
        SELECT id FROM assessments_assessment
        WHERE tenant_id = current_tenant_id()
    ));

CREATE POLICY tenant_isolation ON portfolio_competency
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON portfolio_portfolioentry
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON portfolio_cslactivity
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON elearning_lesson
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON elearning_lessonprogress
    USING (lesson_id IN (
        SELECT id FROM elearning_lesson
        WHERE tenant_id = current_tenant_id()
    ));

CREATE POLICY tenant_isolation ON fees_feestructure
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON fees_payment
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON notifications_notificationtemplate
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON notifications_notificationlog
    USING (tenant_id = current_tenant_id());

-- Grant RLS bypass to superuser only
ALTER USER jodasa_user BYPASSRLS;  -- app user bypasses (Django handles tenant filtering)
-- Uncomment below if you want strict RLS (Django sets app.tenant_id per request):
-- ALTER USER jodasa_user NOBYPASSRLS;

-- ============================================================
-- USEFUL QUERIES FOR ADMINISTRATION
-- ============================================================

-- View all schools
-- SELECT id, name, slug, is_active, subscription_plan FROM tenants_tenant;

-- View all users by role
-- SELECT u.username, u.first_name, u.last_name, u.role, t.name as school
-- FROM users_user u LEFT JOIN tenants_tenant t ON u.tenant_id = t.id
-- ORDER BY u.role, u.last_name;

-- View student count per school per grade
-- SELECT t.name, s.grade, COUNT(*) as students
-- FROM students_student s JOIN tenants_tenant t ON s.tenant_id = t.id
-- GROUP BY t.name, s.grade ORDER BY t.name, s.grade;

-- View fee collection summary
-- SELECT t.name as school, SUM(p.amount) as total_collected,
--        COUNT(*) as transactions
-- FROM fees_payment p JOIN tenants_tenant t ON p.tenant_id = t.id
-- WHERE p.status = 'completed'
-- GROUP BY t.name;

-- View attendance rate per grade
-- SELECT s.grade,
--        COUNT(CASE WHEN ar.status IN ('present','late') THEN 1 END) as present,
--        COUNT(*) as total,
--        ROUND(COUNT(CASE WHEN ar.status IN ('present','late') THEN 1 END)::numeric / COUNT(*) * 100, 1) as rate
-- FROM attendance_attendancerecord ar
-- JOIN students_student s ON ar.student_id = s.id
-- GROUP BY s.grade ORDER BY s.grade;
