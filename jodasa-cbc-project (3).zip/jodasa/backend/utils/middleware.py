from django.http import JsonResponse
from apps.tenants.models import Tenant
import threading

_thread_locals = threading.local()

def get_current_tenant():
    return getattr(_thread_locals, 'tenant', None)

def set_current_tenant(tenant):
    _thread_locals.tenant = tenant


class TenantMiddleware:
    """
    Resolves tenant from subdomain or X-Tenant-Slug header.
    e.g. greenvalley.jodasa.co.ke → slug = 'greenvalley'
    """
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        tenant = None

        # 1. Try X-Tenant-Slug header (for API clients / frontend)
        slug = request.headers.get('X-Tenant-Slug')

        # 2. Try subdomain
        if not slug:
            host = request.get_host().split(':')[0]  # strip port
            parts = host.split('.')
            # greenvalley.jodasa.co.ke → parts[0] = 'greenvalley'
            if len(parts) >= 3 and parts[0] not in ('www', 'api', 'app'):
                slug = parts[0]

        if slug:
            try:
                tenant = Tenant.objects.get(slug=slug, is_active=True)
            except Tenant.DoesNotExist:
                pass

        set_current_tenant(tenant)
        request.tenant = tenant

        response = self.get_response(request)
        set_current_tenant(None)
        return response


class TenantQuerysetMixin:
    """
    Mixin for DRF ViewSets — automatically filters querysets by current tenant.
    """
    def get_queryset(self):
        qs = super().get_queryset()
        tenant = get_current_tenant()
        if tenant and hasattr(qs.model, 'tenant'):
            return qs.filter(tenant=tenant)
        return qs
