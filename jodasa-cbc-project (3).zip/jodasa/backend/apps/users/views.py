from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework_simplejwt.views import TokenObtainPairView
from .models import User
from .serializers import UserSerializer, UserCreateSerializer, ChangePasswordSerializer, JodasaTokenSerializer
from utils.permissions import IsSuperAdmin, IsSchoolAdmin, IsTenantMember
from utils.middleware import get_current_tenant


class JodasaLoginView(TokenObtainPairView):
    serializer_class = JodasaTokenSerializer
    permission_classes = [AllowAny]


class UserViewSet(viewsets.ModelViewSet):
    queryset = User.objects.select_related('tenant').all()
    permission_classes = [IsAuthenticated, IsTenantMember]
    filterset_fields = ['role', 'is_active']
    search_fields = ['first_name', 'last_name', 'email', 'username']

    def get_serializer_class(self):
        if self.action == 'create':
            return UserCreateSerializer
        return UserSerializer

    def get_queryset(self):
        user = self.request.user
        if user.role == 'superadmin':
            return User.objects.all()
        tenant = get_current_tenant()
        if tenant:
            return User.objects.filter(tenant=tenant)
        return User.objects.none()

    def perform_create(self, serializer):
        tenant = get_current_tenant()
        if self.request.user.role != 'superadmin' and tenant:
            serializer.save(tenant=tenant)
        else:
            serializer.save()

    @action(detail=False, methods=['get'], permission_classes=[IsAuthenticated])
    def me(self, request):
        return Response(UserSerializer(request.user).data)

    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated])
    def change_password(self, request, pk=None):
        user = self.get_object()
        if user != request.user and request.user.role not in ('superadmin', 'school_admin'):
            return Response({'detail': 'Not permitted.'}, status=status.HTTP_403_FORBIDDEN)
        serializer = ChangePasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        if not user.check_password(serializer.validated_data['old_password']):
            return Response({'detail': 'Old password is incorrect.'}, status=status.HTTP_400_BAD_REQUEST)
        user.set_password(serializer.validated_data['new_password'])
        user.save()
        return Response({'detail': 'Password changed successfully.'})

    @action(detail=False, methods=['get'])
    def teachers(self, request):
        qs = self.get_queryset().filter(role='teacher')
        return Response(UserSerializer(qs, many=True).data)
