from django.db import models
import uuid


class Lesson(models.Model):
    STATUS_CHOICES = [('draft', 'Draft'), ('published', 'Published'), ('archived', 'Archived')]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey('tenants.Tenant', on_delete=models.CASCADE)
    teacher = models.ForeignKey('users.User', on_delete=models.CASCADE, related_name='lessons')
    title = models.CharField(max_length=200)
    subject = models.CharField(max_length=100)
    grade = models.CharField(max_length=5)
    stream = models.CharField(max_length=5, blank=True)
    description = models.TextField(blank=True)
    content = models.TextField(help_text="Rich lesson content (HTML or Markdown)")
    objectives = models.TextField(blank=True, help_text="Learning objectives")
    resources = models.JSONField(default=list, blank=True)
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='draft')
    term = models.CharField(max_length=10, choices=[('1','Term 1'),('2','Term 2'),('3','Term 3')], default='1')
    year = models.IntegerField(default=2024)
    estimated_duration = models.IntegerField(default=40, help_text="Minutes")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title} – {self.grade} {self.subject}"


class LessonProgress(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE, related_name='progress')
    student = models.ForeignKey('students.Student', on_delete=models.CASCADE, related_name='lesson_progress')
    completed = models.BooleanField(default=False)
    progress_percent = models.IntegerField(default=0)
    last_accessed = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = [['lesson', 'student']]
