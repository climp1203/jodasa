from rest_framework import serializers, viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Lesson, LessonProgress
from utils.middleware import TenantQuerysetMixin, get_current_tenant
from utils.permissions import IsTenantMember


class LessonSerializer(serializers.ModelSerializer):
    teacher_name = serializers.CharField(source='teacher.full_name', read_only=True)

    class Meta:
        model = Lesson
        fields = '__all__'
        read_only_fields = ['id', 'created_at', 'updated_at', 'tenant']


class LessonProgressSerializer(serializers.ModelSerializer):
    class Meta:
        model = LessonProgress
        fields = '__all__'


class LessonViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = Lesson.objects.select_related('teacher').all()
    serializer_class = LessonSerializer
    permission_classes = [IsAuthenticated, IsTenantMember]
    filterset_fields = ['grade', 'subject', 'status', 'term', 'year']
    search_fields = ['title', 'subject', 'description']

    def perform_create(self, serializer):
        serializer.save(tenant=get_current_tenant(), teacher=self.request.user)

    @action(detail=False, methods=['get'], url_path='for-student/(?P<grade>[^/.]+)')
    def for_student(self, request, grade=None):
        lessons = self.get_queryset().filter(grade=grade, status='published')
        return Response(LessonSerializer(lessons, many=True).data)

    @action(detail=True, methods=['post'], url_path='update-progress')
    def update_progress(self, request, pk=None):
        lesson = self.get_object()
        student_id = request.data.get('student_id')
        progress, _ = LessonProgress.objects.update_or_create(
            lesson=lesson, student_id=student_id,
            defaults={
                'progress_percent': request.data.get('progress_percent', 0),
                'completed': request.data.get('completed', False),
            }
        )
        return Response(LessonProgressSerializer(progress).data)
