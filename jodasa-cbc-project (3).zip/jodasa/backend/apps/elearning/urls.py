from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .serializers import LessonViewSet

router = DefaultRouter()
router.register('lessons', LessonViewSet, basename='lesson')
urlpatterns = [path('', include(router.urls))]
