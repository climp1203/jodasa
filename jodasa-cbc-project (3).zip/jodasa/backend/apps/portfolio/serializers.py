from rest_framework import serializers, viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Competency, PortfolioEntry, CSLActivity
from utils.middleware import TenantQuerysetMixin, get_current_tenant
from utils.permissions import IsTenantMember


class CompetencySerializer(serializers.ModelSerializer):
    class Meta:
        model = Competency
        fields = '__all__'
        read_only_fields = ['id', 'tenant']


class PortfolioEntrySerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.full_name', read_only=True)
    teacher_name = serializers.CharField(source='teacher.full_name', read_only=True)
    competency_name = serializers.CharField(source='competency.name', read_only=True)

    class Meta:
        model = PortfolioEntry
        fields = '__all__'
        read_only_fields = ['id', 'created_at', 'tenant']


class CSLActivitySerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.full_name', read_only=True)
    teacher_name = serializers.CharField(source='teacher.full_name', read_only=True)

    class Meta:
        model = CSLActivity
        fields = '__all__'
        read_only_fields = ['id', 'created_at', 'tenant']


class CompetencyViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = Competency.objects.all()
    serializer_class = CompetencySerializer
    permission_classes = [IsAuthenticated, IsTenantMember]

    def perform_create(self, serializer):
        serializer.save(tenant=get_current_tenant())


class PortfolioEntryViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = PortfolioEntry.objects.select_related('student', 'teacher', 'competency').all()
    serializer_class = PortfolioEntrySerializer
    permission_classes = [IsAuthenticated, IsTenantMember]
    filterset_fields = ['student', 'performance_level', 'term', 'year', 'subject']

    def perform_create(self, serializer):
        serializer.save(tenant=get_current_tenant(), teacher=self.request.user)

    @action(detail=False, methods=['get'], url_path='by-student/(?P<student_id>[^/.]+)')
    def by_student(self, request, student_id=None):
        entries = self.get_queryset().filter(student_id=student_id)
        return Response(PortfolioEntrySerializer(entries, many=True).data)


class CSLActivityViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = CSLActivity.objects.select_related('student', 'teacher').all()
    serializer_class = CSLActivitySerializer
    permission_classes = [IsAuthenticated, IsTenantMember]
    filterset_fields = ['student', 'term', 'year']

    def perform_create(self, serializer):
        serializer.save(tenant=get_current_tenant(), teacher=self.request.user)

    @action(detail=False, methods=['get'], url_path='student-hours/(?P<student_id>[^/.]+)')
    def student_hours(self, request, student_id=None):
        activities = self.get_queryset().filter(student_id=student_id)
        total = sum(float(a.hours_spent) for a in activities)
        return Response({'student_id': student_id, 'total_csl_hours': total, 'activities': activities.count()})
