from .serializers import CompetencyViewSet, PortfolioEntryViewSet, CSLActivityViewSet
