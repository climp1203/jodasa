from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .serializers import CompetencyViewSet, PortfolioEntryViewSet, CSLActivityViewSet

router = DefaultRouter()
router.register('competencies', CompetencyViewSet, basename='competency')
router.register('entries', PortfolioEntryViewSet, basename='portfolio-entry')
router.register('csl', CSLActivityViewSet, basename='csl-activity')
urlpatterns = [path('', include(router.urls))]
