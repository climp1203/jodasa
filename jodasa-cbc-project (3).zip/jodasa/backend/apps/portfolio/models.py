from django.db import models
import uuid


class Competency(models.Model):
    CBC_STRANDS = [
        ('communication', 'Communication & Collaboration'),
        ('critical_thinking', 'Critical Thinking & Problem Solving'),
        ('creativity', 'Imagination & Creativity'),
        ('citizenship', 'Citizenship'),
        ('digital_literacy', 'Digital Literacy'),
        ('learning_to_learn', 'Learning to Learn'),
        ('self_efficacy', 'Self-Efficacy'),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey('tenants.Tenant', on_delete=models.CASCADE)
    strand = models.CharField(max_length=50, choices=CBC_STRANDS)
    name = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    grade_band = models.CharField(max_length=20, blank=True)

    class Meta:
        ordering = ['strand', 'name']

    def __str__(self):
        return f"{self.name} ({self.strand})"


class PortfolioEntry(models.Model):
    PERFORMANCE_CHOICES = [
        ('EE', 'Exceeds Expectation'),
        ('ME', 'Meets Expectation'),
        ('AE', 'Approaches Expectation'),
        ('BE', 'Below Expectation'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey('tenants.Tenant', on_delete=models.CASCADE)
    student = models.ForeignKey('students.Student', on_delete=models.CASCADE, related_name='portfolio_entries')
    teacher = models.ForeignKey('users.User', on_delete=models.CASCADE, related_name='portfolio_entries')
    competency = models.ForeignKey(Competency, on_delete=models.SET_NULL, null=True, blank=True)
    title = models.CharField(max_length=200)
    description = models.TextField()
    evidence = models.FileField(upload_to='portfolio_evidence/', blank=True, null=True)
    performance_level = models.CharField(max_length=2, choices=PERFORMANCE_CHOICES, blank=True)
    subject = models.CharField(max_length=100, blank=True)
    term = models.CharField(max_length=10, choices=[('1','Term 1'),('2','Term 2'),('3','Term 3')], default='1')
    year = models.IntegerField(default=2024)
    date = models.DateField()
    teacher_remarks = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date']


class CSLActivity(models.Model):
    """Community Service Learning activity for CBC."""
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey('tenants.Tenant', on_delete=models.CASCADE)
    student = models.ForeignKey('students.Student', on_delete=models.CASCADE, related_name='csl_activities')
    teacher = models.ForeignKey('users.User', on_delete=models.CASCADE, related_name='csl_activities')
    activity_name = models.CharField(max_length=200)
    description = models.TextField()
    location = models.CharField(max_length=200, blank=True)
    hours_spent = models.DecimalField(max_digits=5, decimal_places=1, default=0)
    date = models.DateField()
    impact = models.TextField(blank=True, help_text="Reflection on community impact")
    verified_by = models.CharField(max_length=200, blank=True)
    evidence_photo = models.ImageField(upload_to='csl_evidence/', blank=True, null=True)
    term = models.CharField(max_length=10, choices=[('1','Term 1'),('2','Term 2'),('3','Term 3')], default='1')
    year = models.IntegerField(default=2024)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date']

    def __str__(self):
        return f"{self.activity_name} – {self.student}"
