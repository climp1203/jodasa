from rest_framework import serializers
from .models import Student


class StudentSerializer(serializers.ModelSerializer):
    full_name = serializers.ReadOnlyField()

    class Meta:
        model = Student
        fields = '__all__'
        read_only_fields = ['id', 'qr_code', 'created_at', 'tenant']


class StudentListSerializer(serializers.ModelSerializer):
    full_name = serializers.ReadOnlyField()

    class Meta:
        model = Student
        fields = ['id', 'admission_number', 'full_name', 'first_name',
                  'last_name', 'grade', 'stream', 'photo', 'qr_code',
                  'parent_phone', 'is_active']
