from django.db import models
import uuid
import qrcode
import io
from django.core.files.base import ContentFile


class Student(models.Model):
    GRADE_CHOICES = [
        ('PP1', 'Pre-Primary 1'), ('PP2', 'Pre-Primary 2'),
        ('G1', 'Grade 1'), ('G2', 'Grade 2'), ('G3', 'Grade 3'),
        ('G4', 'Grade 4'), ('G5', 'Grade 5'), ('G6', 'Grade 6'),
        ('G7', 'Grade 7'), ('G8', 'Grade 8'), ('G9', 'Grade 9'),
    ]
    STREAM_CHOICES = [('A', 'A'), ('B', 'B'), ('C', 'C'), ('D', 'D'), ('E', 'E')]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey('tenants.Tenant', on_delete=models.CASCADE, related_name='students')
    admission_number = models.CharField(max_length=30)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    date_of_birth = models.DateField(null=True, blank=True)
    gender = models.CharField(max_length=10, choices=[('M', 'Male'), ('F', 'Female')], blank=True)
    grade = models.CharField(max_length=5, choices=GRADE_CHOICES)
    stream = models.CharField(max_length=5, choices=STREAM_CHOICES, blank=True)
    photo = models.ImageField(upload_to='student_photos/', blank=True, null=True)
    qr_code = models.ImageField(upload_to='qr_codes/', blank=True, null=True)
    parent_user = models.ForeignKey(
        'users.User', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='children', limit_choices_to={'role': 'parent'}
    )
    parent_name = models.CharField(max_length=200, blank=True)
    parent_phone = models.CharField(max_length=20, blank=True)
    parent_email = models.EmailField(blank=True)
    is_active = models.BooleanField(default=True)
    admission_date = models.DateField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [['tenant', 'admission_number']]
        ordering = ['grade', 'last_name', 'first_name']

    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.grade})"

    @property
    def full_name(self):
        return f"{self.first_name} {self.last_name}"

    def generate_qr_code(self):
        qr_data = str(self.id)
        qr = qrcode.QRCode(version=1, box_size=8, border=2)
        qr.add_data(qr_data)
        qr.make(fit=True)
        img = qr.make_image(fill='black', back_color='white')
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        filename = f"qr_{self.admission_number}.png"
        self.qr_code.save(filename, ContentFile(buffer.getvalue()), save=False)

    def save(self, *args, **kwargs):
        if not self.qr_code:
            self.generate_qr_code()
        super().save(*args, **kwargs)
