from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Student
from .serializers import StudentSerializer, StudentListSerializer
from utils.middleware import TenantQuerysetMixin, get_current_tenant
from utils.permissions import IsSchoolAdmin, IsTeacher, IsTenantMember


class StudentViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = Student.objects.select_related('tenant', 'parent_user').all()
    permission_classes = [IsAuthenticated, IsTenantMember]
    filterset_fields = ['grade', 'stream', 'is_active', 'gender']
    search_fields = ['first_name', 'last_name', 'admission_number', 'parent_name']

    def get_serializer_class(self):
        if self.action == 'list':
            return StudentListSerializer
        return StudentSerializer

    def perform_create(self, serializer):
        tenant = get_current_tenant()
        serializer.save(tenant=tenant)

    @action(detail=False, methods=['get'], url_path='by-grade/(?P<grade>[^/.]+)')
    def by_grade(self, request, grade=None):
        qs = self.get_queryset().filter(grade=grade)
        return Response(StudentListSerializer(qs, many=True).data)

    @action(detail=True, methods=['post'], permission_classes=[IsAuthenticated, IsSchoolAdmin])
    def regenerate_qr(self, request, pk=None):
        student = self.get_object()
        student.qr_code.delete(save=False)
        student.generate_qr_code()
        student.save()
        return Response({'qr_code': request.build_absolute_uri(student.qr_code.url)})

    @action(detail=False, methods=['get'])
    def qr_lookup(self, request):
        """Resolve a scanned QR UUID to student info for attendance."""
        student_id = request.query_params.get('id')
        if not student_id:
            return Response({'detail': 'id param required.'}, status=status.HTTP_400_BAD_REQUEST)
        try:
            student = Student.objects.get(id=student_id, tenant=get_current_tenant())
            return Response(StudentListSerializer(student).data)
        except Student.DoesNotExist:
            return Response({'detail': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)
