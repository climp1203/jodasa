from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import AssessmentViewSet, AssessmentResultViewSet

router = DefaultRouter()
router.register('', AssessmentViewSet, basename='assessment')

results_router = DefaultRouter()
results_router.register('', AssessmentResultViewSet, basename='assessment-result')

urlpatterns = [
    path('', include(router.urls)),
    path('results/', include(results_router.urls)),
]
