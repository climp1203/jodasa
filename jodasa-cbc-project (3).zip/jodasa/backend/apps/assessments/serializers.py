from rest_framework import serializers
from .models import Assessment, AssessmentResult, QuizQuestion, QuizAttempt


class QuizQuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuizQuestion
        fields = '__all__'


class QuizQuestionStudentSerializer(serializers.ModelSerializer):
    """Hides correct_answer from students."""
    class Meta:
        model = QuizQuestion
        exclude = ['correct_answer', 'explanation']


class AssessmentSerializer(serializers.ModelSerializer):
    teacher_name = serializers.CharField(source='teacher.full_name', read_only=True)
    questions = QuizQuestionSerializer(many=True, read_only=True)
    result_count = serializers.SerializerMethodField()

    class Meta:
        model = Assessment
        fields = '__all__'
        read_only_fields = ['id', 'created_at', 'tenant']

    def get_result_count(self, obj):
        return obj.results.count()


class AssessmentResultSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.full_name', read_only=True)
    admission_number = serializers.CharField(source='student.admission_number', read_only=True)

    class Meta:
        model = AssessmentResult
        fields = '__all__'


class QuizAttemptSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuizAttempt
        fields = '__all__'
        read_only_fields = ['id', 'score', 'total_questions', 'completed_at']


class QuizSubmitSerializer(serializers.Serializer):
    assessment_id = serializers.UUIDField()
    student_id = serializers.UUIDField()
    answers = serializers.DictField(child=serializers.CharField())
