from django.db import models
import uuid


class Assessment(models.Model):
    TYPE_CHOICES = [
        ('formative', 'Formative'),
        ('summative', 'Summative'),
        ('project', 'Project'),
        ('quiz', 'AI Quiz'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey('tenants.Tenant', on_delete=models.CASCADE)
    teacher = models.ForeignKey('users.User', on_delete=models.CASCADE, related_name='assessments')
    title = models.CharField(max_length=200)
    subject = models.CharField(max_length=100)
    grade = models.CharField(max_length=5)
    stream = models.CharField(max_length=5, blank=True)
    assessment_type = models.CharField(max_length=20, choices=TYPE_CHOICES, default='formative')
    description = models.TextField(blank=True)
    max_score = models.DecimalField(max_digits=6, decimal_places=2, default=100)
    date = models.DateField()
    term = models.CharField(max_length=10, choices=[('1','Term 1'),('2','Term 2'),('3','Term 3')], default='1')
    year = models.IntegerField(default=2024)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date']

    def __str__(self):
        return f"{self.title} – {self.grade} ({self.subject})"


class AssessmentResult(models.Model):
    CBC_PERFORMANCE_CHOICES = [
        ('EE', 'Exceeds Expectation'),
        ('ME', 'Meets Expectation'),
        ('AE', 'Approaches Expectation'),
        ('BE', 'Below Expectation'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    assessment = models.ForeignKey(Assessment, on_delete=models.CASCADE, related_name='results')
    student = models.ForeignKey('students.Student', on_delete=models.CASCADE, related_name='assessment_results')
    score = models.DecimalField(max_digits=6, decimal_places=2, null=True, blank=True)
    cbc_performance = models.CharField(max_length=2, choices=CBC_PERFORMANCE_CHOICES, blank=True)
    teacher_remarks = models.TextField(blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [['assessment', 'student']]
        ordering = ['student__last_name']


class QuizQuestion(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    assessment = models.ForeignKey(Assessment, on_delete=models.CASCADE, related_name='questions')
    question_text = models.TextField()
    option_a = models.CharField(max_length=300)
    option_b = models.CharField(max_length=300)
    option_c = models.CharField(max_length=300)
    option_d = models.CharField(max_length=300)
    correct_answer = models.CharField(max_length=1, choices=[('A','A'),('B','B'),('C','C'),('D','D')])
    explanation = models.TextField(blank=True)
    order = models.IntegerField(default=0)

    class Meta:
        ordering = ['order']


class QuizAttempt(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    assessment = models.ForeignKey(Assessment, on_delete=models.CASCADE, related_name='attempts')
    student = models.ForeignKey('students.Student', on_delete=models.CASCADE, related_name='quiz_attempts')
    answers = models.JSONField(default=dict)  # {question_id: chosen_answer}
    score = models.IntegerField(default=0)
    total_questions = models.IntegerField(default=0)
    completed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-completed_at']
