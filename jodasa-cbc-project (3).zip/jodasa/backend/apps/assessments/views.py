import json
import requests
from django.conf import settings
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Assessment, AssessmentResult, QuizQuestion, QuizAttempt
from .serializers import (AssessmentSerializer, AssessmentResultSerializer,
                           QuizQuestionSerializer, QuizAttemptSerializer, QuizSubmitSerializer)
from utils.middleware import TenantQuerysetMixin, get_current_tenant
from utils.permissions import IsTenantMember, IsTeacher


class AssessmentViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = Assessment.objects.select_related('teacher').prefetch_related('questions', 'results').all()
    serializer_class = AssessmentSerializer
    permission_classes = [IsAuthenticated, IsTenantMember]
    filterset_fields = ['grade', 'subject', 'assessment_type', 'term', 'year']
    search_fields = ['title', 'subject']

    def perform_create(self, serializer):
        serializer.save(tenant=get_current_tenant(), teacher=self.request.user)

    @action(detail=False, methods=['post'], url_path='generate-quiz')
    def generate_quiz(self, request):
        """Uses Claude API to generate CBC-aligned quiz questions."""
        subject = request.data.get('subject', '')
        grade = request.data.get('grade', '')
        topic = request.data.get('topic', '')
        num_questions = min(int(request.data.get('num_questions', 10)), 20)

        prompt = f"""Generate {num_questions} multiple choice questions for Kenyan CBC curriculum.
Grade: {grade}
Subject: {subject}
Topic: {topic}

Return ONLY valid JSON array (no markdown, no explanation) in this exact format:
[
  {{
    "question_text": "...",
    "option_a": "...",
    "option_b": "...",
    "option_c": "...",
    "option_d": "...",
    "correct_answer": "A",
    "explanation": "..."
  }}
]
Correct_answer must be exactly one of: A, B, C, D.
Make questions age-appropriate for {grade} and aligned to CBC competencies."""

        try:
            headers = {
                'x-api-key': settings.ANTHROPIC_API_KEY,
                'anthropic-version': '2023-06-01',
                'content-type': 'application/json',
            }
            payload = {
                'model': 'claude-sonnet-4-20250514',
                'max_tokens': 4096,
                'messages': [{'role': 'user', 'content': prompt}]
            }
            resp = requests.post('https://api.anthropic.com/v1/messages', json=payload, headers=headers, timeout=60)
            resp.raise_for_status()
            content = resp.json()['content'][0]['text']
            questions = json.loads(content)
            return Response({'questions': questions, 'count': len(questions)})
        except Exception as e:
            return Response({'detail': f'AI generation failed: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=True, methods=['post'], url_path='save-questions')
    def save_questions(self, request, pk=None):
        assessment = self.get_object()
        questions_data = request.data.get('questions', [])
        assessment.questions.all().delete()
        created = []
        for i, q in enumerate(questions_data):
            q['assessment'] = assessment.id
            q['order'] = i
            s = QuizQuestionSerializer(data=q)
            s.is_valid(raise_exception=True)
            created.append(s.save())
        return Response({'created': len(created)})

    @action(detail=True, methods=['post'], url_path='submit-quiz')
    def submit_quiz(self, request, pk=None):
        assessment = self.get_object()
        student_id = request.data.get('student_id')
        answers = request.data.get('answers', {})

        questions = assessment.questions.all()
        score = 0
        results_detail = []

        for q in questions:
            chosen = answers.get(str(q.id), '')
            correct = chosen.upper() == q.correct_answer.upper()
            if correct:
                score += 1
            results_detail.append({
                'question_id': str(q.id),
                'question_text': q.question_text,
                'chosen': chosen,
                'correct_answer': q.correct_answer,
                'is_correct': correct,
                'explanation': q.explanation,
            })

        attempt = QuizAttempt.objects.create(
            assessment=assessment,
            student_id=student_id,
            answers=answers,
            score=score,
            total_questions=questions.count(),
        )

        percentage = round((score / questions.count() * 100), 1) if questions.count() else 0
        cbc = 'EE' if percentage >= 80 else 'ME' if percentage >= 60 else 'AE' if percentage >= 40 else 'BE'

        AssessmentResult.objects.update_or_create(
            assessment=assessment,
            student_id=student_id,
            defaults={'score': percentage, 'cbc_performance': cbc}
        )

        return Response({
            'score': score,
            'total': questions.count(),
            'percentage': percentage,
            'cbc_performance': cbc,
            'results': results_detail,
        })

    @action(detail=True, methods=['get'], url_path='results')
    def results(self, request, pk=None):
        assessment = self.get_object()
        results = assessment.results.select_related('student').all()
        return Response(AssessmentResultSerializer(results, many=True).data)


class AssessmentResultViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = AssessmentResult.objects.select_related('assessment', 'student').all()
    serializer_class = AssessmentResultSerializer
    permission_classes = [IsAuthenticated, IsTenantMember]

    def get_queryset(self):
        return AssessmentResult.objects.filter(assessment__tenant=get_current_tenant())
