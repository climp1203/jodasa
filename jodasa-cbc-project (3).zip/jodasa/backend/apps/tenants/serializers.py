from rest_framework import serializers
from .models import Tenant


class TenantSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tenant
        fields = '__all__'
        read_only_fields = ['id', 'created_at', 'updated_at']


class TenantPublicSerializer(serializers.ModelSerializer):
    """Minimal info for login page branding."""
    class Meta:
        model = Tenant
        fields = ['id', 'name', 'slug', 'logo', 'county']
