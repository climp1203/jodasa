"""
Management command to seed Jodasa with demo data.
Run: python manage.py seed_demo

Creates:
  - 1 demo school (tenant)
  - 1 superadmin user
  - 1 school admin
  - 2 teachers
  - 3 parents
  - 20 demo students
  - Sample fee structure
  - Sample notification templates
  - Sample lessons
"""
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from apps.tenants.models import Tenant
from apps.students.models import Student
from apps.fees.models import FeeStructure
from apps.notifications.models import NotificationTemplate
from apps.elearning.models import Lesson
import random

User = get_user_model()

GRADES = ['G1', 'G2', 'G3', 'G4', 'G5', 'G6', 'G7']
FIRST_NAMES_M = ['James', 'John', 'Peter', 'David', 'Michael', 'Samuel', 'Daniel', 'Joseph', 'Paul', 'Mark']
FIRST_NAMES_F = ['Mary', 'Grace', 'Faith', 'Hope', 'Ruth', 'Esther', 'Lydia', 'Naomi', 'Sarah', 'Hannah']
LAST_NAMES = ['Otieno', 'Kamau', 'Wanjiku', 'Odhiambo', 'Mutua', 'Waweru', 'Mwangi', 'Kipchoge', 'Auma', 'Njoroge']


class Command(BaseCommand):
    help = 'Seeds the database with demo data for Jodasa CBC'

    def add_arguments(self, parser):
        parser.add_argument('--reset', action='store_true', help='Delete existing demo data first')

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('\n🌱 Seeding Jodasa demo data...\n'))

        if options['reset']:
            Tenant.objects.filter(slug='greenvalley').delete()
            User.objects.filter(username='superadmin').delete()
            self.stdout.write('  🗑️  Cleared existing demo data')

        # ── 1. Create Tenant (School) ─────────────────────────────────────────
        tenant, created = Tenant.objects.get_or_create(
            slug='greenvalley',
            defaults={
                'name': 'Green Valley Primary School',
                'email': 'info@greenvalley.sc.ke',
                'phone': '0712345678',
                'county': 'Nairobi',
                'address': 'Green Valley Road, Westlands, Nairobi',
                'subscription_plan': 'standard',
                'is_active': True,
            }
        )
        status = 'created' if created else 'already exists'
        self.stdout.write(f'  ✅ School: {tenant.name} ({status})')

        # ── 2. Superadmin ─────────────────────────────────────────────────────
        superadmin, created = User.objects.get_or_create(
            username='superadmin',
            defaults={
                'email': 'superadmin@jodasa.co.ke',
                'first_name': 'Super',
                'last_name': 'Admin',
                'role': 'superadmin',
                'is_staff': True,
                'is_superuser': True,
            }
        )
        if created:
            superadmin.set_password('Admin@1234')
            superadmin.save()
        self.stdout.write(f'  ✅ Superadmin: superadmin / Admin@1234')

        # ── 3. School Admin ───────────────────────────────────────────────────
        admin, created = User.objects.get_or_create(
            username='schooladmin',
            defaults={
                'email': 'admin@greenvalley.sc.ke',
                'first_name': 'Jane',
                'last_name': 'Waithera',
                'role': 'school_admin',
                'tenant': tenant,
                'phone': '0722000001',
            }
        )
        if created:
            admin.set_password('Admin@1234')
            admin.save()
        self.stdout.write(f'  ✅ School Admin: schooladmin / Admin@1234')

        # ── 4. Teachers ───────────────────────────────────────────────────────
        teachers_data = [
            ('teacher1', 'John', 'Otieno', '0722000002'),
            ('teacher2', 'Mary', 'Wanjiku', '0722000003'),
        ]
        teachers = []
        for uname, fname, lname, phone in teachers_data:
            t, created = User.objects.get_or_create(
                username=uname,
                defaults={
                    'email': f'{uname}@greenvalley.sc.ke',
                    'first_name': fname,
                    'last_name': lname,
                    'role': 'teacher',
                    'tenant': tenant,
                    'phone': phone,
                }
            )
            if created:
                t.set_password('Admin@1234')
                t.save()
            teachers.append(t)
        self.stdout.write(f'  ✅ Teachers: teacher1, teacher2 / Admin@1234')

        # ── 5. Parents ────────────────────────────────────────────────────────
        parents_data = [
            ('parent1', 'Peter', 'Kamau', '0733000001'),
            ('parent2', 'Grace', 'Mwangi', '0733000002'),
            ('parent3', 'David', 'Mutua', '0733000003'),
        ]
        parents = []
        for uname, fname, lname, phone in parents_data:
            p, created = User.objects.get_or_create(
                username=uname,
                defaults={
                    'email': f'{uname}@gmail.com',
                    'first_name': fname,
                    'last_name': lname,
                    'role': 'parent',
                    'tenant': tenant,
                    'phone': phone,
                }
            )
            if created:
                p.set_password('Admin@1234')
                p.save()
            parents.append(p)
        self.stdout.write(f'  ✅ Parents: parent1, parent2, parent3 / Admin@1234')

        # ── 6. Students ───────────────────────────────────────────────────────
        students_created = 0
        adm_counter = 1
        for grade in GRADES:
            for stream in ['A', 'B']:
                for i in range(3):
                    gender = 'M' if i % 2 == 0 else 'F'
                    fname = random.choice(FIRST_NAMES_M if gender == 'M' else FIRST_NAMES_F)
                    lname = random.choice(LAST_NAMES)
                    adm_no = f'GV{str(adm_counter).zfill(4)}'
                    parent = random.choice(parents)

                    _, created = Student.objects.get_or_create(
                        tenant=tenant,
                        admission_number=adm_no,
                        defaults={
                            'first_name': fname,
                            'last_name': lname,
                            'grade': grade,
                            'stream': stream,
                            'gender': gender,
                            'parent_user': parent,
                            'parent_name': parent.get_full_name(),
                            'parent_phone': parent.phone,
                            'parent_email': parent.email,
                            'is_active': True,
                        }
                    )
                    if created:
                        students_created += 1
                    adm_counter += 1

        self.stdout.write(f'  ✅ Students: {students_created} created across {len(GRADES)} grades')

        # ── 7. Fee Structures ─────────────────────────────────────────────────
        fee_data = [
            ('G1', 'Grade 1-3 Term 1 2025', 8000, 0, 500, 300, 200),
            ('G4', 'Grade 4-6 Term 1 2025', 9000, 0, 500, 400, 200),
            ('G7', 'Grade 7-9 Term 1 2025', 10000, 0, 600, 500, 300),
        ]
        for grade, name, tuition, boarding, activity, exam, other in fee_data:
            FeeStructure.objects.get_or_create(
                tenant=tenant, grade=grade, term='1', year=2025,
                defaults={'name': name, 'tuition': tuition, 'boarding': boarding,
                          'activity': activity, 'exam': exam, 'other': other}
            )
        self.stdout.write(f'  ✅ Fee structures: 3 created')

        # ── 8. Notification Templates ─────────────────────────────────────────
        templates = [
            ('Fee Reminder', 'fees', 'Fees Due Reminder',
             'Dear Parent, this is a reminder that school fees for {student_name} (Grade {grade}) are due. Please pay KES {amount} to avoid any inconvenience. Thank you. {school_name}',
             'sms'),
            ('Attendance Alert', 'attendance',  'Attendance Alert',
             'Dear Parent, {student_name} was marked ABSENT today. Please contact the school if this is an error. {school_name}',
             'sms'),
            ('End of Term Results', 'results', 'End of Term Results Ready',
             'Dear Parent, the end of term results for {student_name} are now ready. Please visit the school to collect the report card. {school_name}',
             'both'),
            ('School Event', 'event', 'Upcoming School Event',
             'Dear Parent, {school_name} will be hosting a special event. Please ensure {student_name} is in attendance. More details to follow.',
             'sms'),
        ]
        for name, category, subject, body, channel in templates:
            NotificationTemplate.objects.get_or_create(
                tenant=tenant, name=name,
                defaults={'category': category, 'subject': subject, 'body': body, 'channel': channel}
            )
        self.stdout.write(f'  ✅ Notification templates: {len(templates)} created')

        # ── 9. Sample Lessons ─────────────────────────────────────────────────
        lessons_data = [
            ('Introduction to Fractions', 'Mathematics', 'G4', 'Understanding halves, quarters and thirds using real-world examples like cutting fruits and sharing food equally among friends.', 'By end of lesson, students will: identify fractions in daily life, compare simple fractions, solve basic fraction problems.'),
            ('Our Environment', 'Science', 'G3', 'Exploring the natural environment around us — plants, animals, soil, water and air. Students learn how to protect and conserve nature.', 'Students will: name components of the environment, explain importance of conservation, identify ways to protect the environment.'),
            ('Kenya\'s Communities', 'Social Studies', 'G5', 'Studying the diverse communities in Kenya, their cultures, traditions, food, clothing and contribution to national unity.', 'Students will: identify at least 5 Kenyan communities, describe cultural practices, explain how diversity strengthens Kenya.'),
            ('Creative Writing', 'English', 'G6', 'Learning to write short stories with a beginning, middle and end. Focus on descriptive language, dialogue and character development.', 'Students will: write a 3-paragraph story, use descriptive adjectives, include dialogue between characters.'),
        ]
        teacher = teachers[0]
        for title, subject, grade, content, objectives in lessons_data:
            Lesson.objects.get_or_create(
                tenant=tenant, title=title,
                defaults={
                    'teacher': teacher,
                    'subject': subject,
                    'grade': grade,
                    'content': content,
                    'objectives': objectives,
                    'status': 'published',
                    'term': '1',
                    'year': 2025,
                    'estimated_duration': 40,
                }
            )
        self.stdout.write(f'  ✅ Sample lessons: {len(lessons_data)} created')

        # ── Summary ───────────────────────────────────────────────────────────
        self.stdout.write(self.style.SUCCESS('\n✨ Demo data seeded successfully!\n'))
        self.stdout.write('=' * 55)
        self.stdout.write('  LOGIN CREDENTIALS')
        self.stdout.write('=' * 55)
        self.stdout.write(f'  Superadmin:   superadmin   / Admin@1234')
        self.stdout.write(f'  School Admin: schooladmin  / Admin@1234')
        self.stdout.write(f'  Teacher 1:    teacher1     / Admin@1234')
        self.stdout.write(f'  Teacher 2:    teacher2     / Admin@1234')
        self.stdout.write(f'  Parent 1:     parent1      / Admin@1234')
        self.stdout.write('=' * 55)
        self.stdout.write(f'  School slug:  greenvalley')
        self.stdout.write(f'  Frontend URL: http://localhost:5173')
        self.stdout.write(f'  Backend URL:  http://localhost:8000')
        self.stdout.write(f'  API Docs:     http://localhost:8000/api/docs/')
        self.stdout.write('=' * 55 + '\n')
