from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Tenant
from .serializers import TenantSerializer, TenantPublicSerializer
from utils.permissions import IsSuperAdmin


class TenantViewSet(viewsets.ModelViewSet):
    queryset = Tenant.objects.all()
    serializer_class = TenantSerializer
    permission_classes = [IsSuperAdmin]
    search_fields = ['name', 'slug', 'county']
    filterset_fields = ['is_active', 'subscription_plan']

    @action(detail=False, methods=['get'], permission_classes=[], url_path='by-slug/(?P<slug>[^/.]+)')
    def by_slug(self, request, slug=None):
        """Public endpoint — returns branding info for login page."""
        try:
            tenant = Tenant.objects.get(slug=slug, is_active=True)
            return Response(TenantPublicSerializer(tenant).data)
        except Tenant.DoesNotExist:
            return Response({'detail': 'School not found.'}, status=status.HTTP_404_NOT_FOUND)

    @action(detail=False, methods=['get'], permission_classes=[])
    def current(self, request):
        """Returns the tenant resolved from subdomain/header."""
        tenant = getattr(request, 'tenant', None)
        if not tenant:
            return Response({'detail': 'No tenant context.'}, status=status.HTTP_404_NOT_FOUND)
        return Response(TenantPublicSerializer(tenant).data)
