import base64
import requests
from datetime import datetime
from django.conf import settings
from django.utils import timezone
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import serializers
from .models import FeeStructure, Payment
from utils.middleware import TenantQuerysetMixin, get_current_tenant
from utils.permissions import IsTenantMember


class FeeStructureSerializer(serializers.ModelSerializer):
    total = serializers.ReadOnlyField()

    class Meta:
        model = FeeStructure
        fields = '__all__'
        read_only_fields = ['id', 'created_at', 'tenant']


class PaymentSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.full_name', read_only=True)
    admission_number = serializers.CharField(source='student.admission_number', read_only=True)

    class Meta:
        model = Payment
        fields = '__all__'
        read_only_fields = ['id', 'created_at', 'tenant', 'mpesa_receipt', 'mpesa_transaction_id']


def get_mpesa_token():
    key = settings.MPESA_CONSUMER_KEY
    secret = settings.MPESA_CONSUMER_SECRET
    credentials = base64.b64encode(f"{key}:{secret}".encode()).decode()
    base = "https://sandbox.safaricom.co.ke" if settings.MPESA_ENV == "sandbox" else "https://api.safaricom.co.ke"
    resp = requests.get(
        f"{base}/oauth/v1/generate?grant_type=client_credentials",
        headers={"Authorization": f"Basic {credentials}"},
        timeout=10
    )
    return resp.json().get('access_token')


class FeeStructureViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = FeeStructure.objects.all()
    serializer_class = FeeStructureSerializer
    permission_classes = [IsAuthenticated, IsTenantMember]
    filterset_fields = ['grade', 'term', 'year']

    def perform_create(self, serializer):
        serializer.save(tenant=get_current_tenant())


class PaymentViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = Payment.objects.select_related('student', 'fee_structure', 'recorded_by').all()
    serializer_class = PaymentSerializer
    permission_classes = [IsAuthenticated, IsTenantMember]
    filterset_fields = ['student', 'method', 'status', 'term', 'year']

    def perform_create(self, serializer):
        serializer.save(tenant=get_current_tenant(), recorded_by=self.request.user)

    @action(detail=False, methods=['post'], url_path='mpesa-stk')
    def mpesa_stk(self, request):
        """Initiate M-Pesa STK push to parent's phone."""
        phone = request.data.get('phone', '').strip()
        amount = int(request.data.get('amount', 0))
        student_id = request.data.get('student_id')

        if not phone or not amount:
            return Response({'detail': 'phone and amount required.'}, status=status.HTTP_400_BAD_REQUEST)

        # Normalize phone to 254XXXXXXXXX
        if phone.startswith('0'):
            phone = '254' + phone[1:]
        elif phone.startswith('+'):
            phone = phone[1:]

        try:
            token = get_mpesa_token()
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            shortcode = settings.MPESA_SHORTCODE
            passkey = settings.MPESA_PASSKEY
            password = base64.b64encode(f"{shortcode}{passkey}{timestamp}".encode()).decode()

            base = "https://sandbox.safaricom.co.ke" if settings.MPESA_ENV == "sandbox" else "https://api.safaricom.co.ke"
            payload = {
                "BusinessShortCode": shortcode,
                "Password": password,
                "Timestamp": timestamp,
                "TransactionType": "CustomerPayBillOnline",
                "Amount": amount,
                "PartyA": phone,
                "PartyB": shortcode,
                "PhoneNumber": phone,
                "CallBackURL": settings.MPESA_CALLBACK_URL,
                "AccountReference": f"JODASA-{student_id[:8].upper() if student_id else 'FEES'}",
                "TransactionDesc": "School Fees Payment",
            }

            resp = requests.post(
                f"{base}/mpesa/stkpush/v1/processrequest",
                json=payload,
                headers={"Authorization": f"Bearer {token}"},
                timeout=15
            )
            data = resp.json()

            # Create pending payment record
            Payment.objects.create(
                tenant=get_current_tenant(),
                student_id=student_id,
                amount=amount,
                method='mpesa',
                status='pending',
                phone_number=phone,
                term=request.data.get('term', '1'),
                year=request.data.get('year', datetime.now().year),
                mpesa_transaction_id=data.get('CheckoutRequestID', ''),
                recorded_by=request.user,
            )

            return Response({'detail': 'STK push sent. Ask parent to enter PIN.', 'checkout_id': data.get('CheckoutRequestID')})
        except Exception as e:
            return Response({'detail': f'M-Pesa error: {str(e)}'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

    @action(detail=False, methods=['post'], url_path='mpesa/callback', permission_classes=[])
    def mpesa_callback(self, request):
        """M-Pesa callback — updates payment status."""
        try:
            body = request.data.get('Body', {})
            stk_callback = body.get('stkCallback', {})
            result_code = stk_callback.get('ResultCode')
            checkout_id = stk_callback.get('CheckoutRequestID')

            payment = Payment.objects.filter(mpesa_transaction_id=checkout_id).first()
            if payment:
                if result_code == 0:
                    items = {item['Name']: item.get('Value') for item in stk_callback.get('CallbackMetadata', {}).get('Item', [])}
                    payment.status = 'completed'
                    payment.mpesa_receipt = items.get('MpesaReceiptNumber', '')
                    payment.paid_at = timezone.now()
                else:
                    payment.status = 'failed'
                payment.save()
        except Exception:
            pass
        return Response({'ResultCode': 0, 'ResultDesc': 'Accepted'})

    @action(detail=False, methods=['get'], url_path='statement/(?P<student_id>[^/.]+)')
    def statement(self, request, student_id=None):
        tenant = get_current_tenant()
        payments = Payment.objects.filter(student_id=student_id, tenant=tenant, status='completed')
        total_paid = sum(float(p.amount) for p in payments)
        return Response({
            'student_id': student_id,
            'payments': PaymentSerializer(payments, many=True).data,
            'total_paid': total_paid,
        })
