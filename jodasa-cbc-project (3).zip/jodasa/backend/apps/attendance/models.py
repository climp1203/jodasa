from django.db import models
import uuid


class AttendanceSession(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey('tenants.Tenant', on_delete=models.CASCADE)
    teacher = models.ForeignKey('users.User', on_delete=models.CASCADE, related_name='sessions')
    grade = models.CharField(max_length=5)
    stream = models.CharField(max_length=5, blank=True)
    date = models.DateField()
    subject = models.CharField(max_length=100, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [['tenant', 'grade', 'stream', 'date', 'subject']]
        ordering = ['-date']

    def __str__(self):
        return f"{self.grade}{self.stream} – {self.date}"


class AttendanceRecord(models.Model):
    STATUS_CHOICES = [
        ('present', 'Present'),
        ('absent', 'Absent'),
        ('late', 'Late'),
        ('excused', 'Excused'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    session = models.ForeignKey(AttendanceSession, on_delete=models.CASCADE, related_name='records')
    student = models.ForeignKey('students.Student', on_delete=models.CASCADE, related_name='attendance_records')
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='absent')
    scan_method = models.CharField(
        max_length=10,
        choices=[('qr', 'QR Scan'), ('manual', 'Manual')],
        default='manual'
    )
    scanned_at = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)

    class Meta:
        unique_together = [['session', 'student']]
        ordering = ['student__last_name']

    def __str__(self):
        return f"{self.student} – {self.status}"
