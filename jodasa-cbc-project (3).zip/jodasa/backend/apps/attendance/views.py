from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django.utils import timezone
from .models import AttendanceSession, AttendanceRecord
from .serializers import AttendanceSessionSerializer, AttendanceRecordSerializer, QRScanSerializer
from apps.students.models import Student
from utils.middleware import TenantQuerysetMixin, get_current_tenant
from utils.permissions import IsTeacher, IsTenantMember


class AttendanceSessionViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = AttendanceSession.objects.prefetch_related('records__student').select_related('teacher').all()
    serializer_class = AttendanceSessionSerializer
    permission_classes = [IsAuthenticated, IsTenantMember]
    filterset_fields = ['grade', 'stream', 'date']

    def perform_create(self, serializer):
        serializer.save(tenant=get_current_tenant(), teacher=self.request.user)

    @action(detail=True, methods=['post'], url_path='qr-scan')
    def qr_scan(self, request, pk=None):
        session = self.get_object()
        serializer = QRScanSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        try:
            student = Student.objects.get(
                id=serializer.validated_data['student_id'],
                tenant=session.tenant
            )
        except Student.DoesNotExist:
            return Response({'detail': 'Student not found.'}, status=status.HTTP_404_NOT_FOUND)

        record, created = AttendanceRecord.objects.update_or_create(
            session=session,
            student=student,
            defaults={
                'status': 'present',
                'scan_method': 'qr',
                'scanned_at': timezone.now(),
            }
        )
        return Response({
            'student': student.full_name,
            'status': 'marked present',
            'created': created
        })

    @action(detail=True, methods=['post'], url_path='bulk-mark')
    def bulk_mark(self, request, pk=None):
        """Mark all students in grade/stream at once (manual mode)."""
        session = self.get_object()
        records_data = request.data.get('records', [])
        updated = 0
        for item in records_data:
            AttendanceRecord.objects.update_or_create(
                session=session,
                student_id=item['student_id'],
                defaults={
                    'status': item.get('status', 'absent'),
                    'scan_method': 'manual',
                    'notes': item.get('notes', ''),
                }
            )
            updated += 1
        return Response({'updated': updated})

    @action(detail=False, methods=['get'], url_path='student-summary/(?P<student_id>[^/.]+)')
    def student_summary(self, request, student_id=None):
        tenant = get_current_tenant()
        records = AttendanceRecord.objects.filter(
            student_id=student_id,
            session__tenant=tenant
        ).select_related('session')
        total = records.count()
        present = records.filter(status__in=['present', 'late']).count()
        return Response({
            'total_sessions': total,
            'present': present,
            'absent': total - present,
            'attendance_rate': round((present / total * 100), 1) if total else 0,
        })


class AttendanceRecordViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = AttendanceRecord.objects.select_related('student', 'session').all()
    serializer_class = AttendanceRecordSerializer
    permission_classes = [IsAuthenticated, IsTenantMember]
    filterset_fields = ['status', 'scan_method']

    def get_queryset(self):
        return AttendanceRecord.objects.filter(session__tenant=get_current_tenant())
