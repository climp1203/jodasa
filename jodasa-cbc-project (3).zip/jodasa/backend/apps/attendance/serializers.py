from rest_framework import serializers
from .models import AttendanceSession, AttendanceRecord


class AttendanceRecordSerializer(serializers.ModelSerializer):
    student_name = serializers.CharField(source='student.full_name', read_only=True)
    admission_number = serializers.CharField(source='student.admission_number', read_only=True)

    class Meta:
        model = AttendanceRecord
        fields = '__all__'


class AttendanceSessionSerializer(serializers.ModelSerializer):
    records = AttendanceRecordSerializer(many=True, read_only=True)
    teacher_name = serializers.CharField(source='teacher.full_name', read_only=True)
    total_present = serializers.SerializerMethodField()
    total_absent = serializers.SerializerMethodField()

    class Meta:
        model = AttendanceSession
        fields = '__all__'
        read_only_fields = ['id', 'created_at', 'tenant']

    def get_total_present(self, obj):
        return obj.records.filter(status__in=['present', 'late']).count()

    def get_total_absent(self, obj):
        return obj.records.filter(status='absent').count()


class QRScanSerializer(serializers.Serializer):
    student_id = serializers.UUIDField()
    session_id = serializers.UUIDField()
