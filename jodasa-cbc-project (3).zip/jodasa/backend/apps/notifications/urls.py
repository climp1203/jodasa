from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import NotificationTemplateViewSet, NotificationLogViewSet

router = DefaultRouter()
router.register('templates', NotificationTemplateViewSet, basename='notification-template')
router.register('logs', NotificationLogViewSet, basename='notification-log')
urlpatterns = [path('', include(router.urls))]
