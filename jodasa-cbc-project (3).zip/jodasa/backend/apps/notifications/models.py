from django.db import models
import uuid


class NotificationTemplate(models.Model):
    CATEGORY_CHOICES = [
        ('fees', 'Fee Reminder'),
        ('attendance', 'Attendance Alert'),
        ('results', 'Results Notification'),
        ('general', 'General Announcement'),
        ('event', 'School Event'),
    ]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey('tenants.Tenant', on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES, default='general')
    subject = models.CharField(max_length=300, blank=True, help_text="Email subject")
    body = models.TextField(help_text="Use {student_name}, {grade}, {amount}, {school_name} as placeholders")
    channel = models.CharField(max_length=10, choices=[('sms','SMS'),('email','Email'),('both','Both')], default='sms')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} ({self.category})"


class NotificationLog(models.Model):
    STATUS_CHOICES = [('sent','Sent'),('failed','Failed'),('pending','Pending')]
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    tenant = models.ForeignKey('tenants.Tenant', on_delete=models.CASCADE)
    template = models.ForeignKey(NotificationTemplate, on_delete=models.SET_NULL, null=True, blank=True)
    recipient_name = models.CharField(max_length=200)
    recipient_phone = models.CharField(max_length=20, blank=True)
    recipient_email = models.EmailField(blank=True)
    message = models.TextField()
    channel = models.CharField(max_length=10, choices=[('sms','SMS'),('email','Email')])
    status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='pending')
    sent_by = models.ForeignKey('users.User', on_delete=models.SET_NULL, null=True)
    sent_at = models.DateTimeField(auto_now_add=True)
    error_message = models.TextField(blank=True)

    class Meta:
        ordering = ['-sent_at']
