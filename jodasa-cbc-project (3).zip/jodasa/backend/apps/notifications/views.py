import requests
from django.conf import settings
from django.core.mail import send_mail
from rest_framework import viewsets, status
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import serializers
from .models import NotificationTemplate, NotificationLog
from apps.students.models import Student
from utils.middleware import TenantQuerysetMixin, get_current_tenant
from utils.permissions import IsTenantMember, IsTeacher


class NotificationTemplateSerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationTemplate
        fields = '__all__'
        read_only_fields = ['id', 'created_at', 'tenant']


class NotificationLogSerializer(serializers.ModelSerializer):
    class Meta:
        model = NotificationLog
        fields = '__all__'


def send_sms_africas_talking(phone, message):
    """Send SMS via Africa's Talking."""
    try:
        resp = requests.post(
            'https://api.africastalking.com/version1/messaging',
            headers={'apiKey': settings.AT_API_KEY, 'Accept': 'application/json'},
            data={
                'username': settings.AT_USERNAME,
                'to': phone,
                'message': message,
                'from': settings.AT_SENDER_ID,
            },
            timeout=10
        )
        return resp.status_code == 201
    except Exception:
        return False


class NotificationTemplateViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = NotificationTemplate.objects.all()
    serializer_class = NotificationTemplateSerializer
    permission_classes = [IsAuthenticated, IsTenantMember]

    def perform_create(self, serializer):
        serializer.save(tenant=get_current_tenant())

    @action(detail=True, methods=['post'], url_path='send-bulk')
    def send_bulk(self, request, pk=None):
        template = self.get_object()
        tenant = get_current_tenant()
        grade = request.data.get('grade', '')
        custom_vars = request.data.get('vars', {})

        students = Student.objects.filter(tenant=tenant, is_active=True)
        if grade:
            students = students.filter(grade=grade)

        sent = 0
        failed = 0

        for student in students:
            message = template.body.replace('{student_name}', student.full_name)
            message = message.replace('{grade}', student.grade)
            message = message.replace('{school_name}', tenant.name if tenant else 'School')
            for k, v in custom_vars.items():
                message = message.replace(f'{{{k}}}', str(v))

            if template.channel in ('sms', 'both') and student.parent_phone:
                success = send_sms_africas_talking(student.parent_phone, message)
                NotificationLog.objects.create(
                    tenant=tenant,
                    template=template,
                    recipient_name=student.parent_name or student.full_name,
                    recipient_phone=student.parent_phone,
                    message=message,
                    channel='sms',
                    status='sent' if success else 'failed',
                    sent_by=request.user,
                )
                if success:
                    sent += 1
                else:
                    failed += 1

            if template.channel in ('email', 'both') and student.parent_email:
                try:
                    send_mail(
                        subject=template.subject or f"Message from {tenant.name if tenant else 'School'}",
                        message=message,
                        from_email=settings.DEFAULT_FROM_EMAIL,
                        recipient_list=[student.parent_email],
                        fail_silently=False,
                    )
                    NotificationLog.objects.create(
                        tenant=tenant, template=template,
                        recipient_name=student.parent_name or student.full_name,
                        recipient_email=student.parent_email,
                        message=message, channel='email', status='sent', sent_by=request.user
                    )
                    sent += 1
                except Exception as e:
                    NotificationLog.objects.create(
                        tenant=tenant, template=template,
                        recipient_name=student.parent_name or student.full_name,
                        recipient_email=student.parent_email,
                        message=message, channel='email', status='failed',
                        sent_by=request.user, error_message=str(e)
                    )
                    failed += 1

        return Response({'sent': sent, 'failed': failed, 'total': students.count()})


class NotificationLogViewSet(TenantQuerysetMixin, viewsets.ModelViewSet):
    queryset = NotificationLog.objects.select_related('template', 'sent_by').all()
    serializer_class = NotificationLogSerializer
    permission_classes = [IsAuthenticated, IsTenantMember]
    filterset_fields = ['channel', 'status']
    http_method_names = ['get', 'head', 'options']
