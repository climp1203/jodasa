-- ============================================================
-- Jodasa CBC — PostgreSQL Row-Level Security (RLS)
-- Run this AFTER running Django migrations
-- ============================================================

-- Enable RLS on all tenant-scoped tables
ALTER TABLE students_student ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_attendancesession ENABLE ROW LEVEL SECURITY;
ALTER TABLE attendance_attendancerecord ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessments_assessment ENABLE ROW LEVEL SECURITY;
ALTER TABLE assessments_assessmentresult ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolio_portfolioentry ENABLE ROW LEVEL SECURITY;
ALTER TABLE portfolio_cslactivity ENABLE ROW LEVEL SECURITY;
ALTER TABLE elearning_lesson ENABLE ROW LEVEL SECURITY;
ALTER TABLE fees_feestructure ENABLE ROW LEVEL SECURITY;
ALTER TABLE fees_payment ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications_notificationtemplate ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications_notificationlog ENABLE ROW LEVEL SECURITY;

-- Create a PostgreSQL function to get current tenant ID from session variable
CREATE OR REPLACE FUNCTION current_tenant_id()
RETURNS UUID AS $$
BEGIN
    RETURN current_setting('app.tenant_id', TRUE)::UUID;
EXCEPTION WHEN OTHERS THEN
    RETURN NULL;
END;
$$ LANGUAGE plpgsql STABLE;

-- Create policies for each table
-- Students
CREATE POLICY tenant_isolation ON students_student
    USING (tenant_id = current_tenant_id());

-- Attendance
CREATE POLICY tenant_isolation ON attendance_attendancesession
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON attendance_attendancerecord
    USING (session_id IN (SELECT id FROM attendance_attendancesession WHERE tenant_id = current_tenant_id()));

-- Assessments
CREATE POLICY tenant_isolation ON assessments_assessment
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON assessments_assessmentresult
    USING (assessment_id IN (SELECT id FROM assessments_assessment WHERE tenant_id = current_tenant_id()));

-- Portfolio
CREATE POLICY tenant_isolation ON portfolio_portfolioentry
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON portfolio_cslactivity
    USING (tenant_id = current_tenant_id());

-- eLearning
CREATE POLICY tenant_isolation ON elearning_lesson
    USING (tenant_id = current_tenant_id());

-- Fees
CREATE POLICY tenant_isolation ON fees_feestructure
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON fees_payment
    USING (tenant_id = current_tenant_id());

-- Notifications
CREATE POLICY tenant_isolation ON notifications_notificationtemplate
    USING (tenant_id = current_tenant_id());

CREATE POLICY tenant_isolation ON notifications_notificationlog
    USING (tenant_id = current_tenant_id());

-- ============================================================
-- In your Django views, set the session variable like this:
-- from django.db import connection
-- with connection.cursor() as cursor:
--     cursor.execute("SET app.tenant_id = %s", [str(tenant_id)])
-- ============================================================
